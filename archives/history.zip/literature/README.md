# 文献目录（literature/）

当前入口：[真实周期与整模型文献地图](period_holonomy_reading_map_20261005.md)及[研究总览](../research/period_holonomy_progress_20261005.md)。本轮新增 Maximon/NIST 二重对数原始论文与 CDT 作者站单独 220 页快照，两份 PDF 共 234 页；另存 DLMF 5.15、25.12 与 Stacks 01OF 三份原始 HTML。原 218 页 arXiv v2 仍为证明与编号参考，未替换。[PDF 清单](manifest_period_holonomy_20261005.json)与[网页清单](manifest_period_holonomy_web_20261005.json)记载固定版本、SHA-256 及视觉身份；既有 64 份原始 PDF 保持原字节。

上一轮入口：[本原分母与路线去重地图](primitive_routes_reading_map_20261005.md)及[本轮进展](../research/odd_zeta_primitive_routes_progress_20261005.md)。本轮新增5份原始PDF、97页，含Greene、Straub、Samol–van Straten、Sorokin，以及只用于历史审计的Ghosh–Ward v2；后者2020年的后续撤稿已另存原始metadata，未采用其任何定理。另存DLMF两份标准渐近HTML。来源、版本、SHA-256及适用范围见[PDF清单](manifest_primitive_routes_20261005.json)与[网页清单](manifest_primitive_routes_web_20261005.json)。既有原始文件与研究报告保持冻结。

上一轮入口：[对数矩、多重正交与真实端点渐近地图](log_moment_reading_map_20261005.md)及[本轮进展](../research/odd_zeta_log_moment_progress_20261005.md)。该轮新增6份原始PDF，含Smet–Van Assche合流Mellin定理、Lysov的second-kind函数、Neuschel–Van Assche零点分布、Kalmykov–Lysov–Shukla强渐近、Wolfs的hypergeometric Padé及Fidalgo Prieto–López Lagomasino的Nikishin条件。固定版本、191页及SHA-256见[清单](manifest_log_moment_20261005.json)。适用假设逐条核过；本项目实际目标的振荡强渐近、统一非零接口和算术缺口另在技术报告中证明。

上一轮[显式端点与Padé地图](explicit_relative_reading_map_20261004.md)及[进展](../research/odd_zeta_explicit_relative_progress_20261004.md)保留5份原始PDF：Fischler–Rivoal的两篇Padé论文、Zudilin的polylog逼近、Krattenthaler–Rivoal的Catalan整性及Prévost–Sorokin的循环Hermite–Padé。[清单](manifest_explicit_relative_20261004.json)保持冻结；没有把这些论文当作ζ(7)或Catalan的新无理性定理。

上一轮[K₂缺口地图](k2_gap_reading_map_20261004.md)及[进展](../research/odd_zeta_k2_gap_progress_20261004.md)保留8份原始来源PDF，包括Rost、Weibel、Suslin、Neumann–Yang、Zagier–Gangl、Dokchitser–de Jeu–Zagier，以及整数环讲义和Stacks参考快照。[清单](manifest_k2_gap_20261004.json)保持原样。本轮的四项显式链与整系数 \(T=0\) 加强该阶段的固定身份；此前原件与证明文件不变。

前一轮另存7份原始PDF，见[新周期、覆盖与整数滤波地图](next_route_reading_map_20261004.md)及[清单](manifest_next_route_20261004.json)。包括Borwein–Bradley原稿及Almkvist–Granville证明、Catalan精确整性与滤波预印本、四次单位根均匀化半径，以及Goncharov–Levin椭圆K₂最终v4。原件保持不变。

[全部奇数ζ与Catalan的阅读地图](reading_map_20261004.md)与[总体研究报告](../research/odd_zeta_global_strategy_20261004.md)保留统一背景。该阶段新增28份开放原始PDF，补充动机/周期、算术holonomy、模形式、Catalan及G函数适用边界；30条归档记录包含两份复用文件。

后续桥梁研究另存3份原始PDF，见[补充阅读地图](bridge_reading_map_20261004.md)与[manifest](manifest_bridge_20261004.json)：多元整Chebyshev、算术曲面、polylog真实动机构造。相应的已证中间结果见[桥梁进展报告](../research/odd_zeta_bridge_progress_20261004.md)。

[完整归档清单](manifest_global_20261004.json)记录作者、固定版本、来源、页数与SHA-256。证明声称和批评稿成对保存；归档检查不等同于数学证明审定。下列经典资料和项目原件继续保留。

## 论文原件与形式化

| 文件 | 说明 |
| --- | --- |
| `fauzan_zeta5.pdf` | A. Fauzan, *ZETA5 IS IRRATIONAL*（2026-09-17 预印本，Zenodo 22826419）——本项目形式化对象 |
| `Zeta5-mo271/`（上级目录） | mo271 对 Fauzan 论文的**完整 Lean 形式化**（Apache-2.0），`zeta5_irrational_absolute` 经其机器验证 |

## 奠基性结果

| 文件 | 说明 |
| --- | --- |
| `apery1979_asterisque.pdf` | Apéry 1978：ζ(2), ζ(3) 无理（Astérisque 61） |
| `rivoal2000_cracadsci.pdf` | Rivoal 2000：无穷多个奇数 zeta 值无理（C. R. Acad. Sci. 331） |
| `rivoal2001_thesis_ballrivoal_method.pdf` | Rivoal 博士论文（含 Ball–Rivoal 方法全文；Inventiones 146 原文付费墙） |
| Ball–Rivoal 2001原文未取得 | Invent. Math.146(2001)；本库没有名为ball_rivoal2001.pdf的原件，不能引用占位文件。 |

## Zudilin 系列（窗口定理）

| 文件 | 说明 |
| --- | --- |
| `zudilin2001_one_of_5_7_9_11.pdf` | ζ(5),ζ(7),ζ(9),ζ(11) 中至少一个无理（Uspekhi 56:4, 2001） |
| `zudilin2001_zeta_values_0104249.pdf` | Zudilin, *Irrationality of values of zeta-function*，arXiv math.NT/0104249，16 页作者公开稿；§3 式 (3) 含有理函数的正弦/Gamma 表示，§4 式 (12) 为余切导数围道积分。2026-09-29 按原文核对。 |
| `zudilin2002_irrationality_values.pdf` | **2026-09-29 核对：文件名与旧说明不符。** 实际为 Zudilin, *Multiple-integral representations of very-well-poised hypergeometric series*，arXiv math/0206177v1，8 页；不能作为旧说明中窗口定理的原文引用。 |
| `zudilin2004_jtnb_linear_forms.pdf` | 涉及奇数 zeta 值的线性型的算术（JTNB 16, 2004） |
| `zudilin2018_sigma_elementary.pdf` | ζ(5)…ζ(25) 中至少一个无理（初等手段，SIGMA 14, 2018） |

## 量化与改进

| 文件 | 说明 |
| --- | --- |
| `fsz2019_many_odd_zeta.pdf` | Fischler–Sprang–Zudilin：对每个ε>0及充分大的s，≥ 2^{(1−ε)log s/log log s} 个无理（Compositio 155, 2019） |
| `sprang2018_elementary.pdf` | Sprang：无穷多奇数 zeta 值无理的初等证明（arXiv 1802.09410） |
| `lai2021_at_least_two.pdf` | Li Lai–Li Zhou：ζ(5),…,ζ(35)中至少两个无理；同文β(2),…,β(10)中至少一个无理（arXiv2103.00904v2；发表于2022）。均不能指定ζ(7)或Catalan。 |
| `lai2025_note_ii.pdf` | Li Lai：正文Theorem1.1给≥1.284579·√(s/log s)个无理，摘要取较粗1.284（arXiv2501.05321v2）；是个数，不是维数。 |
| `at_least_one_5_7_9_2026.pdf` | 预印本（旧记录日期 2026-09-15）：声称 ζ(5),ζ(7),ζ(9) 至少一个无理。**逻辑更正：即使 ζ(5) 无理已知，也不能从“至少一个”推出 ζ(7)、ζ(9) 中有无理数。** 本条不代表已独立审定该预印本。 |

## 综述与工具

| 文件 | 说明 |
| --- | --- |
| `fischler_zudilin_distribution.pdf` | Fischler–Zudilin：无理 zeta 值的分布（综述，arXiv 1310.1685） |
| `fischler_siegel_odd_zeta.pdf` | Fischler：dim_Q Span{1,ζ(3),…,ζ(s)}≥0.21√(s/log s)，充分大的奇s（JLMS113,2026）；本地v3与网页正文日期差异见新清单。 |
| `brown_zudilin_cellular.pdf` | Brown–Zudilin：ζ(5) 的胞腔有理逼近（Fauzan 论文的重要前置） |

## p-adic 方向（对照：p-adic 界已达线性 s/log s）

| 文件 | 说明 |
| --- | --- |
| `lai_lupu_sprang_padic.pdf` | Lai–Lupu–Sprang：某些 p-adic zeta 值的无理性（Res. Math. Sci. 12, 2025） |
| `lai_sprang_zudilin_padic_many.pdf` | 许多 p-adic 奇数 zeta 值无理（Michigan Math. J.；≥ (c_p−ε)s/log s） |
