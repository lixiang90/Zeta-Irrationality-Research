"""One-shot documentary archive for round229; no mathematical producer calls."""
from pathlib import Path
import hashlib
import json
import re

root = Path(__file__).resolve().parent.parent
main = root / "research/cdt_odd_background_progress_20261006.md"
report = root / "research/research_uniform_projection_progress_round229_20261008.md"
previous = root / "literature/manifest_global_review_round228_20261008.json"
dest = root / "literature/manifest_uniform_projection_round229_20261008.json"
old_size = 565457
old_sha = "355e0643cb75d7c4e88d6d36b251d1b5853d587ba257248508e7ca269f226d86"
prev_sha = "a2735d734da087b512d71f98e2239a2a0648101e06a778db6e555d0f409b7ec3"
report_sha = "f551ab96ddc2565c606855dce87fcd938c68e991f1c0333ec0fec27161276020"

def sha(data):
    return hashlib.sha256(data).hexdigest()

old = main.read_bytes()
body = report.read_bytes()
assert len(old) == old_size and sha(old) == old_sha, "Main prefix changed"
assert sha(previous.read_bytes()) == prev_sha, "Predecessor changed"
assert sha(body) == report_sha, "Report changed"
assert not dest.exists(), "Do not rerun a completed archive"

files = sorted({*root.joinpath("research").glob("*round229*20261008.*"),
                *root.joinpath("literature/global_projection_sources_round229_20261008").glob("*")})
pins = []
for path in files:
    if not path.is_file():
        continue
    data = path.read_bytes()
    if path.suffix == ".md":
        text = data.decode("utf-8-sig")
        assert not any(ord(c) < 32 and c not in "\r\n\t" for c in text), path
    pins.append({"path": path.relative_to(root).as_posix(),
                 "bytes": len(data), "sha256": sha(data)})
links = []
for target in re.findall(r"\]\(([^)]+)\)", body.decode("utf-8-sig")):
    if target.startswith(("http:", "https:", "#")):
        continue
    assert (report.parent / target.split("#", 1)[0]).resolve().is_file(), target
    links.append(target)

combined = old + b"\n\n" + body
manifest = {
    "round": 229, "date": "2026-10-08",
    "mathematical_program_runs": 0, "git_mutations": 0, "lean_builds": 0,
    "mathematical_status": "All-weight complete period projection and same-object bounds proved on paper; no numerical irrationality theorem",
    "global_review_cadence": {"last_formal": 228, "next_default": 234, "window": [232, 236]},
    "next_interface": "Rank of the full p-residue block [B mod p; p a^T mod p] on unbounded scales; primitive complete coefficient cost and target-value nonzero",
    "verification_scope": "New document identities, report local links, predecessor identity and main preserved prefix only; no old producers or historical pins rerun",
    "predecessor": {"path": previous.relative_to(root).as_posix(), "bytes": previous.stat().st_size, "sha256": prev_sha},
    "main_preserved_prefix": {"bytes": old_size, "sha256": old_sha},
    "appended_report": {"path": report.relative_to(root).as_posix(), "bytes": len(body), "sha256": report_sha},
    "main_after_append": {"path": main.relative_to(root).as_posix(), "bytes": len(combined), "sha256": sha(combined)},
    "source_scope": "Three primary PDFs with selected text; author and Root reading boundaries are in the new records, not full-paper certification",
    "report_links_checked": links,
    "new_pins": pins,
}
dest.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
main.write_bytes(combined)
assert main.read_bytes() == combined
print(json.dumps({"status": "PASS", "round": 229, "pins": len(pins),
                  "report_links": len(links), "mathematical_runs": 0,
                  "main_bytes": len(combined), "main_sha256": sha(combined),
                  "manifest_bytes": dest.stat().st_size, "manifest_sha256": sha(dest.read_bytes())}, ensure_ascii=False))
