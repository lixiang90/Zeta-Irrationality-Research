"""One-shot documentary archive261. Run only after the independent review freezes."""
from pathlib import Path
import hashlib
import json

ROOT = Path(__file__).resolve().parents[1]
assert ROOT == Path(r"E:\kimi-build\zeta5").resolve()
PREVIOUS = ROOT / "literature/manifest_global_review_round260_20261010.json"
MANIFEST = ROOT / "literature/manifest_refined_budget_round261_20261010.json"
MAIN = ROOT / "research/cdt_odd_background_progress_20261006.md"
POLICY = ROOT / "research/research_global_review_policy.md"
REPORT = ROOT / "research/refined_budget_progress_round261_20261010.md"
REVIEW = ROOT / "research/research_round261_refined_budget_review_20261010.md"
SOURCES = ROOT / "literature/refined_budget_round261_20261010"
REVIEW_SHA = "28b4d3a9ac53172293693aacb24f67866b81911a99aab4cd16ef0a569ae937f0"
MATH = [ROOT / "research" / name for name in [
    "refined_budget_gate_round261_20261010.md",
    "refined_budget_characteristic_round261_20261010.md",
    "refined_budget_punctures_round261_20261010.md",
    "refined_budget_arithmetic_round261_20261010.md",
]]
SCOPES = [SOURCES / f"{name}_reading_scope.md" for name in [
    "root", "characteristic", "punctures", "arithmetic"]]


def digest(data):
    return hashlib.sha256(data).hexdigest()


def pin(path):
    data = path.read_bytes()
    return {"path": path.relative_to(ROOT).as_posix(), "bytes": len(data), "sha256": digest(data)}


def verify(path, size, sha):
    data = path.read_bytes()
    assert len(data) == size and digest(data) == sha, str(path)
    return data


assert not MANIFEST.exists(), "261 already archived; never rerun"
previous_data = verify(PREVIOUS, 54556, "740d28c910f7b66f622986bf00e5bede44f341635fcd8c67d60339dadaad90df")
previous = json.loads(previous_data)
assert previous["round"] == 260 and len(previous["files"]) == 232
assert previous["formal_global_review"]["last"] == 260
assert previous["formal_global_review"]["completed_rounds_since_last"] == 0
for item in previous["files"]:
    verify(ROOT / item["path"], item["bytes"], item["sha256"])
old_main = verify(MAIN, 771576, "9640711612cda2a806757e9cfb597c1ce6c07f7e4dbbb6178b3cf8c4db1ba73d")
old_policy = verify(POLICY, 44247, "746592ab91de902c40b8554021fea9ff26db8a654949d3bc21c61d84e3fa7cbe")
review_data = REVIEW.read_bytes()
assert REVIEW_SHA != "PENDING" and digest(review_data) == REVIEW_SHA
review_text = review_data.decode("utf-8-sig").lower()
assert "pass" in review_text
for path in MATH + SCOPES + [REPORT]:
    assert path.is_file() and pin(path)["sha256"] in review_text, str(path)
root_scope = SCOPES[0].read_text(encoding="utf-8-sig").lower()
assert "独立数学复核" in root_scope
for path in MATH[1:]:
    assert pin(path)["sha256"] in root_scope, str(path)
report_data = REPORT.read_bytes()
assert report_data not in old_main
assert "## 第261轮".encode("utf-8") not in old_policy
paths = {ROOT / item["path"] for item in previous["files"]
         if item["path"] != "research/research_global_review_policy.md"}
paths.update([PREVIOUS, POLICY, REPORT, REVIEW, Path(__file__)])
paths.update(MATH)
paths.update(SOURCES.iterdir())
assert all(path.is_file() for path in paths)

policy_append = """

## 第261轮：联合障碍、停止标准入口与全局方向纪律

用户每4–8完成轮全局复盘持续执行：默认4，最多8，连续2轮核心准入或同对象净可行性未推进则提前。文档、归档、局部引理及坐标改名不抵消停滞。261不属正式复盘，不reset：last260、previous256、count1、next264、latest268。总目标active，没有新数值ζ/L定理。

固定bare rank3的t∞实两fiber，forcing常数b±9√3d/16因有理系数且d≠0不能消失。每个到达叶含非零zlog²z，有限ramification不修复；同一合法holomorphic图λ<log(11/2)<7/4。换可逆Q(s)基底不逃掉H的meromorphic pullback条件。

对每条非有理rational Laurent row，活跃AP无穷prime在固定p+k给exact平方分母且p∤p+k；n^e不清该prime。任何有效standard literal有限lcm-factor type，每非有理row至少两entry≥1；任意rank3 basis至少两非有理rows。Definition8逐row计数单调给τflatflat≥16/9，τsharp≥0。fixed shifts不降低leading。故λ−τ<−1/36，所选已发表§7–8 numerator精化、同s换基与standard type均无法准入，结束该实现默认投入；不是全部CDT、换坐标/扩充族或数值目标的no-go。

另保留全N、全部prime-power AP-filtered整模型与actual prefix最小分母leading分类：generic2，special7/4、3/2、4/3。它不是CDT τ，未给matched balanced-height theorem，special不覆盖全部四项反证空间；不免费按比例降费用，不自动开prime/map/参数/Padé。Jensen及原合法slopes/probability条件另证两种selected convexity扣后分子≥λ，rank3矛盾必要τ<7/6；若将来仅付32/27，连这两精化都无strict。该下界不扩给binomial、多图或其它接口。

下一262仅作有界数值出口选择，比较AP-filtered模型需要的新holonomy定理与真正不同完整period carrier的关系敏感机制。AP优先核ζ2±2G已知结果及新颖性；其完整反证类b=0、c=±d对应实际prefix leading4/3，但尚非τ，正分母也不足以产生rank3严格矛盾。先固定数值出口、全部关系范围、可望改变严格净余量的机制、必要新定理及停止条件，再按机会成本选择至多一个第一证书。无明确新机制即报告未准入，不硬开搜索或改名重开旧窗口。下一正式264仍比较全部架构与目标差距，最迟268。

四数学稿、report、四actual scopes及唯一独审后单次归档。Root独审三个分支数学；characteristic reviewer独审Root/punctures/arithmetic/report而不自审自己的数学。260全部232pins先核，231非policy旧文件及main/policy旧bytes前缀保留。数学程序、CAS、finite-n/interval、prime/参数/map/word扫描、Padé、Lean、外Git写与旧producer0；文献实际访问/失败GET按scope结算，不称全网络0或整篇primary/full Lean/全球novelty。
""".encode("utf-8")

POLICY.write_bytes(old_policy + policy_append)
MAIN.write_bytes(old_main + b"\n\n" + report_data)
assert MAIN.read_bytes()[:len(old_main)] == old_main
assert POLICY.read_bytes()[:len(old_policy)] == old_policy
assert MAIN.read_bytes().count(report_data) == 1
for item in previous["files"]:
    if item["path"] != "research/research_global_review_policy.md":
        verify(ROOT / item["path"], item["bytes"], item["sha256"])

manifest = {
    "round": 261, "date_started": "2026-10-10", "date_completed": "2026-10-11", "classification": "progress",
    "goal_status": "active", "new_numerical_irrationality_or_independence_theorem": False,
    "global_novelty_or_full_lean_audit": False,
    "formal_global_review": {"last": 260, "previous_formal": 256,
        "this_round_is_formal": False, "counter_reset_this_round": False,
        "completed_rounds_since_last": 1, "next_scheduled": 264, "latest_required": 268,
        "default_interval": 4, "maximum_interval": 8, "early_core_stagnation_rounds": 2},
    "paid_this_round": ["Bare relation all-leaf real-fiber log-square obstruction",
        "Same-module holomorphic derivative cap11/2 invariant under rational rebasing",
        "Whole-prefix AP-filtered arithmetic model and exact leading classification",
        "Standard literal rational-basis type fee lower bound16/9",
        "Joint positive-denominator exclusion for selected published refined interfaces",
        "Jensen lower bound for both selected legal corrected numerators and necessary fee below7/6"],
    "admission": {"standard_literal_same_module": "stopped by joint strict exclusion",
        "ap_filtered_extension": "not admitted; matched balanced-height theorem absent",
        "implementation_admitted": False, "strict_same_object_budget_paid": False,
        "general_method_impossibility": False},
    "stopped_default_windows": previous["stopped_default_windows"] + [
        "Fixed mixed bare rank3 same-s standard literal rational-rebasing refined holomorphic entry"],
    "next_unique_work": {"round": 262,
        "scope": "Bounded numerical-exit choice between a matched AP-filtered holonomy theorem and a genuinely different relation-sensitive period carrier",
        "priority_ap_targets": "Verify existing results and numerical feasibility for zeta(2) plus or minus2G; special classes cover these targets but not general four-term independence",
        "admission": "Specific new numerical exit, complete relation class, mechanism affecting strict net budget, missing theorem and stop condition before implementation",
        "automatic_implementation_or_scan": False},
    "runs": {"team_math_programs": 0, "cas": 0, "finite_n_numerical_or_interval": 0,
        "prime_parameter_map_word_scans": 0, "pade_matrix_implementation": 0, "lean": 0,
        "external_git_mutations": 0, "old_archive_producers": 0, "this_documentary_archive": 1},
    "sources": {"precise_scopes": [pin(path) for path in SCOPES],
        "whole_primary_paper_reading_claim": False, "fresh_cloud_repository_equality_claim": False,
        "mathematics_not_inferred_from_hashes": True},
    "previous_manifest": pin(PREVIOUS), "previous_manifest_nonpolicy_files_preserved": 231,
    "report": pin(REPORT), "independent_math_and_report_review": pin(REVIEW),
    "previous_policy": {"bytes": len(old_policy), "sha256": digest(old_policy)},
    "new_policy": pin(POLICY),
    "previous_main": {"bytes": len(old_main), "sha256": digest(old_main)}, "new_main": pin(MAIN),
    "files": [pin(path) for path in sorted(paths)],
}
MANIFEST.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
assert PREVIOUS.read_bytes() == previous_data and REVIEW.read_bytes() == review_data
print(json.dumps({"status": "PASS", "files": len(paths), "old_nonpolicy_preserved": 231,
    "numeric_theorem": False, "count": 1, "next_formal": 264, "latest_formal": 268,
    "manifest": pin(MANIFEST), "main": pin(MAIN), "policy": pin(POLICY)}, ensure_ascii=False))
