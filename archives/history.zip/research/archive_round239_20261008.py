"""One-shot documentary archive; no mathematical computation or Git mutation."""
from pathlib import Path
import hashlib
import json

root = Path(__file__).resolve().parent.parent
assert root == Path('E:/kimi-build/zeta5').resolve()
main = root / 'research/cdt_odd_background_progress_20261006.md'
report = root / 'research/research_actual_cofactor_arithmetic_round239_20261008.md'
policy = root / 'research/research_global_review_policy.md'
previous = root / 'literature/manifest_actual_flag_round238_20261008.json'
dest = root / 'literature/manifest_actual_cofactor_arithmetic_round239_20261008.json'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def pin(path):
    data = path.read_bytes()
    return {'path': path.relative_to(root).as_posix(),
            'bytes': len(data), 'sha256': sha(data)}


old, body = main.read_bytes(), report.read_bytes()
assert len(old) == 633713
assert sha(old) == 'e7d3ef52ee78cb08fd828420fafcbe4ba6bed7e0e4aedf553c329870b74cd1cd'
assert len(body) == 7887
assert sha(body) == '0adb3f6ffef25da33fc42b4d4528bf93f84d07ad1e4927f19cab9ca96bc7a2aa'
assert sha(policy.read_bytes()) == 'd18c279ce3f67c345d8a5a40108c69272b057fae28e6dfa6f70795b6389660e8'
assert sha(previous.read_bytes()) == '4d36a4508838681391b644f227205540c67c8c016c7cb879da152d212f9a997a'
assert not dest.exists(), 'Archive exists; never rerun a completed producer'

frozen = {
    'actual_cofactor_arithmetic_round239_20261008.md':
        (9483, '25ec2e97a75e477e305d37aa1c59044155c41499e2a00240cddfb31561151262'),
    'actual_cofactor_arithmetic_independent_round239_20261008.md':
        (11139, '04f3b1e8d93143a273bf93626e8fd598161521cb32ca2838210668f01eff4557'),
    'actual_cofactor_budget_gate_round239_20261008.md':
        (10804, '8c0db240d561764395d958332fd144efb0d1ad6f08ef889c1488805830e31909'),
}
for name, (size, digest) in frozen.items():
    data = (root / 'research' / name).read_bytes()
    assert len(data) == size and sha(data) == digest, name

receipts = {
    'research_round239_report_review_20261008.md': sha(body),
    'research_round239_independent_check_20261008.md':
        frozen['actual_cofactor_arithmetic_independent_round239_20261008.md'][1],
    'research_round239_packet_check_20261008.md':
        frozen['actual_cofactor_arithmetic_round239_20261008.md'][1],
}
for name, digest in receipts.items():
    review = (root / 'research' / name).read_text(encoding='utf-8-sig')
    assert 'PASS' in review and digest in review, name

files = set((root / 'research').glob('*round239*20261008.*'))
files.update((root / 'literature/actual_cofactor_arithmetic_sources_round239_20261008').glob('*'))
files.add(policy)
records = [pin(p) for p in sorted(files) if p.is_file()]
primaries = [pin(root / p) for p in [
    'literature/global_review_sources_round228_20261008/packet_cdt_L2chi_current_author.pdf',
    'literature/brown2012_mixed_tate_motives.pdf',
]]
assert primaries[0]['sha256'] == '9d778fc22f82fb064371722ff457d54a2fc787608b8493ed9893a8fd39929a1c'
assert primaries[1]['sha256'] == 'ed36eadb1cdf8150405e9cfa9437caa8a8d88841258d936c6347d1e5877f1085'

combined = old + b'\n\n' + body
manifest = {
    'round': 239, 'date': '2026-10-08', 'classification': 'progress',
    'goal_status': 'active', 'previous_goal_turn_classification': 'progress',
    'numerical_irrationality_or_independence_theorem': False,
    'paid': [
        'Exact saturated full two-layer local prefix index for 2m<p<=3m: p^(2N-3k).',
        'All-prime-power-safe CRT integer-jet source index log Q=(21/2)m^2+o(m^2).',
        'Uniform same-cofactor Cauchy/binomial integer content: v2>=2m^2-O(m log m), v3>=m^2-O(m log m).',
        'Explicit Q_m b_g^m delta_h in C_m Z for every candidate hole, log C=(log12)m^2+O(m log m).',
        'Actual selected cofactor arithmetic defect upper a<=21/2-log12; no replacement of selector or Gram sum.',
        'All legal retained E-frame map derivative bound tightened to pi^3/2^(7/4) by Cauchy-Schwarz.',
        'Fixed common-BC metric, paid HS/uniform heights, finite-map calibration Q_s>=Q_1>=lambda_max; same class retains necessary cap.',
        'Concrete motivic D3 three-forbidden-coordinate equivalence for cellular ambient; original uniform relative-cut certificate remains unpaid.',
    ],
    'not_paid': [
        'Optimal actual arithmetic defect, an actual lower equalling this safe upper, or strict numerical holonomy contradiction.',
        'All-CDT no-go, different species or D-dependent metrics, balanced tensor or new-source certificate.',
        'Uniform original cellular D3 restriction/six-channel projection, target-selective infinite nonzero forms or a new numerical theorem.',
        'Global novelty or full-repository proof certification.',
    ],
    'safe_arithmetic_upper': '21/2-log12',
    'legal_same_class_necessary_threshold_upper': '3 log(pi^3/2^(7/4))',
    'strict_comparison': 'safe upper > threshold upper; this is not a lower for the actual defect',
    'next_action': 'Round240 early formal global review: stop blind same-source prime/map optimization, compare concrete real-period projection, mixed determinants and paid new-mechanism interfaces.',
    'formal_global_review': {'last': 236, 'next_default': 240,
                             'original_default': 242, 'window': [240, 244],
                             'this_round_resets_counter': False,
                             'reason': 'Tight all-map bound changes investment decision.'},
    'mathematical_program_runs': 0, 'parameter_scans': 0,
    'new_saved_pdf_downloads': 0, 'git_mutations': 0, 'lean_builds': 0,
    'documentary_archive_attempts': 1,
    'corrections': 'B top window was clarified for nonpositive Hankel gap; A author corrected missing plus signs before final freeze. Root withdrew continuing inference based only on old loose capacity after deriving tight bound. No approval rejection.',
    'previous_manifest': pin(previous), 'previous_main': pin(main),
    'report': pin(report), 'policy': pin(policy), 'files': records,
    'reused_primary_files': primaries,
    'main_after': {'path': main.relative_to(root).as_posix(),
                   'bytes': len(combined), 'sha256': sha(combined)},
}
serialized = (json.dumps(manifest, ensure_ascii=False, indent=2) + '\n').encode('utf-8')
main.write_bytes(combined)
dest.write_bytes(serialized)
assert main.read_bytes()[:len(old)] == old
assert sha(main.read_bytes()) == manifest['main_after']['sha256']
assert json.loads(dest.read_text(encoding='utf-8'))['main_after'] == manifest['main_after']
print(json.dumps({'status': 'PASS', 'round': 239, 'file_pins': len(records),
                  'main_after': manifest['main_after'], 'manifest': pin(dest)}, ensure_ascii=False))
