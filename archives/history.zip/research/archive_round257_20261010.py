"""One-shot documentary archive257; no mathematical computation or external Git writes."""
from pathlib import Path
import hashlib
import json

ROOT = Path(__file__).resolve().parents[1]
assert ROOT == Path(r"E:\kimi-build\zeta5").resolve()
MANIFEST = ROOT / "literature/manifest_native_chi8_feasibility_round257_20261010.json"
assert not MANIFEST.exists(), "Completed257 archive must not be rerun"
PREVIOUS = ROOT / "literature/manifest_native_chi8_round256_20261010.json"
MAIN = ROOT / "research/cdt_odd_background_progress_20261006.md"
POLICY = ROOT / "research/research_global_review_policy.md"
REPORT = ROOT / "research/research_native_chi8_progress_round257_20261010.md"
REVIEW = ROOT / "research/research_round257_net_feasibility_review_20261010.md"
SOURCES = ROOT / "literature/native_chi8_sources_round257_20261010"
REVIEW_SIZE = 10535  # Root actually read the frozen unique review before setting these pins.
REVIEW_SHA = "7cf4076d6244197deebe372f0acf8070324f2988b42b3353f8188e397f64499d"


def digest(data):
    return hashlib.sha256(data).hexdigest()


def pin(path):
    data = path.read_bytes()
    return {"path": path.relative_to(ROOT).as_posix(), "bytes": len(data), "sha256": digest(data)}


def verify(path, size, sha):
    data = path.read_bytes()
    assert len(data) == size and digest(data) == sha, str(path)
    return data


previous_data = verify(PREVIOUS, 26959, "71d837ff7d530ba24359761ae0174f48b449314ae780523ba3a11e750f996e28")
previous = json.loads(previous_data)
assert previous["round"] == 256 and len(previous["files"]) == 100
assert previous["formal_global_review"]["last"] == 256
assert previous["formal_global_review"]["completed_rounds_since_last"] == 0
assert previous["formal_global_review"]["next_scheduled"] == 260
for item in previous["files"]:
    verify(ROOT / item["path"], item["bytes"], item["sha256"])
old_main = verify(MAIN, 750262, "b0419b21c73cff4ecc0935f1edd9b60dc018189fa57e1c6932895921588b3c5b")
old_policy = verify(POLICY, 31565, "5c01097c1e975d717b5e90c935f4f9935ccc8143b36c67f925344aee73734930")
report_data = verify(REPORT, 6272, "03f510d7cee51b40807afd1f3950ffbecc4719ae25e9196248c95dea827cd27e")
review_data = verify(REVIEW, REVIEW_SIZE, REVIEW_SHA)
review_text = review_data.decode("utf-8-sig")
review_lower = review_text.lower()
assert "PASS" in review_text and "260" in review_text and "264" in review_text
authors = [
    ("chi8_native_net_settlement_round257_20261010.md", 7380, "f1df999f649203059585c429bc14e99837de1158c0cb952cca80b0c2818cdc5a"),
    ("chi8_native_actual_energy_round257_20261010.md", 9441, "e3046b5a27631809923c05c4c9d72df832e918b1293bc023930f303ab181dace"),
    ("chi8_native_primitive_feasibility_round257_20261010.md", 12010, "14650a9261a6940ced84e2a7ac847617e6cf18d18f463a1dc01c9f50c2a9317e"),
    ("chi8_native_spectral_feasibility_round257_20261010.md", 12889, "b6375dc5f2d4bd33f08f4e5fc6083425c44ea49cc2f34f3cbd2f5f182861ed75"),
]
for name, size, sha in authors:
    verify(ROOT / "research" / name, size, sha)
    assert sha in review_lower
assert digest(report_data) in review_lower
scopes = [
    ("root", 5359, "6e119e199a0c1ee58c412f9cf4def6e258953e9fa5971bd40367962905a8cef8"),
    ("contour", 3370, "1d87451045a759d79e7a2cda99168a33ba1e4ff7edcc1ab8dcf0b136ab758e96"),
    ("integer", 2810, "71d142b03b4e81f2a339c2bdb017ff943da970d82b1bc9e25701525cd97f45fc"),
    ("spectral", 4558, "3c4f94a4ebda677a71f150ba2f713132d0af65e69254ff7d2d624f9e4b4a8252"),
]
for name, size, sha in scopes:
    verify(SOURCES / f"{name}_reading_scope.md", size, sha)
    assert sha in review_lower
root_scope = (SOURCES / "root_reading_scope.md").read_text(encoding="utf-8")
assert authors[3][2] in root_scope and "独立数学复核" in root_scope
copies = [
    ("contour_input256_A.md", "chi8_native_contour_gate_round256_20261010.md"),
    ("contour_input256_C.md", "chi8_native_integer_gate_round256_20261010.md"),
    ("contour_input256_root.md", "research_global_review_round256_20261010.md"),
    ("contour_input256_progress.md", "research_native_chi8_progress_round256_20261010.md"),
    ("contour_input256_sensitivity.md", "chi8_native_sensitivity_gate_round256_20261010.md"),
]
for source_name, original_name in copies:
    assert (SOURCES / source_name).read_bytes() == (ROOT / "research" / original_name).read_bytes()
assert len(list(SOURCES.iterdir())) == 9
assert "## 第257轮".encode("utf-8") not in old_policy
assert report_data not in old_main

policy_append = """

## 第257轮：净结算与全局方向纪律

每4–8轮俯瞰全局的用户要求持续执行：默认每4个完成轮正式复盘，最长8轮，连续2轮核心数值出口未推进则提前。复盘须回答：原目标与已证结果差在哪；当前路线是否改变关键缺口；是否已支付同一完整对象的真实period、整模型、实际非零及净能量；其它架构是否有更直接机制；下一有界投入的准入及停止条件是什么。比较机会成本，以可验证的数值出口推进程度决策，不以局部引理数量或工作量延长路线。

每轮用同一组指标记录已证、未证及条件性部分：完整关系跳变是否消失、共同解析域增益、同对象净预算、实际无界非零。连续两轮未推进所选准入门槛、未改变净可行性，就提前复盘；文档补齐、归档与局部引理不抵消停滞，也不重置时钟。257的完整减费记为全尺度结构进展，同时维持新数值结果未取得的状态。

本轮不是新的正式复盘，也不重置clock。last256，257完成后计数1，下一正式260，最迟264；原总目标active，没有新数值ζ/L无理性或线性无关性定理。上一轮已完成四接口宏观比较；本轮结算其唯一准入的固定native χ−8 prototype actualY净可行性检验。

已付全indices实际monodromy实折叠、O/J/Z三标签共同实测度及完整Andreief；全部n的actual |2^(−n²)Δ_n(Y)|≤M^n n^(n/2)2^(2n−1)。完整前缀的新清整因子qtilde_H=2^(3floor(H/2)+1)d_(H+1)^2覆盖全部heads、period系数、所有prime powers；旧全poly共同内容[2^(n+1)d_(2n)]^n得到严格证明。primitive leading安全费二次阶由6+(9/2)log2降至4+(7/2)log2，真实改善不是单位转换，也未声称最大primitive内容。

同一primitive尺度精确合账后actual安全upper仍无负二次项足以抵消完整算术费用，也没有无界actual非零。mixed O/Z行在相同node不成比例，完整mixed alternant不含免费全Vandermonde；相邻尺寸旧block发生有理rank-one更新，正确bordered-adjugate恒等式不等于正Gram非零链。正的upper不作为actual lower，不宣判所有χ−8方法不可能。

依256边界，本轮结束当前default monomial contact prototype的投入，保留完整carrier、表示、分母和内容资产。新增局部结构和真实减费仍不能自动领取新的prime/Frobenius/参数/maps/sheetwords/换向量窗口。未来若重访，必须先给独立的新机制及足以改变完整净预算的证据，而非改名重开。

下一唯一258转向跨架构的来源准入判断：假设数值关系是否在完整最小函数族中消掉整个非meromorphic local monodromy，并给可量化的共同解析域增益，同时支付真实period投影、函数独立性及完整前缀费用。优先比较真实不同cyclotomic通道的多源机制与联合域代价；只消掉本已允许的meromorphic极点、增加jets、函数代数独立或“至少一个已知无理值”均不足。若不能交付关系敏感机制和域增益，否决来源选择，不继续局部搜索。原成功标准仍是新的数值定理。

新构造前须固定一个候选、目标数值关系、完整最小函数族和待补入域。准入证书覆盖该域全部非meromorphic跳变，而非一个通道或有限jets；共同pullback、函数独立性、完整算术费与几何收益须在同一holonomy不等式内结算。只有严格余量，或足以改变完整净可行性且剩余条件明确有限的全尺度证书，才开启实现；“多源机制可能有效”本身不能开启下一局部窗口。

四数学最终稿、进展报告、四实际阅读scope与唯一独审齐全后才单次归档；Root独核B，B独审Root/A/C/report，不以作者自审代替独立核验。旧256全部100pins先核，99非policy旧文件不变，main/policy旧bytes前缀全部保留。数学程序、finite-n/CAS/interval/prime/参数/map/word扫描、Lean、外Git写、旧producer、新web/primary GET/PDF/HTML下载均0；本轮documentary归档1，不以文档数量计数学进展。
""".encode("utf-8")

paths = {ROOT / item["path"] for item in previous["files"] if item["path"] != "research/research_global_review_policy.md"}
paths.add(PREVIOUS)
paths.update(ROOT / "research" / name for name, _, _ in authors)
paths.update([REPORT, REVIEW, Path(__file__), POLICY])
paths.update(SOURCES.iterdir())
assert len(paths) == 117 and all(path.is_file() for path in paths)

# All mutations follow identity verification and the frozen unique review.
POLICY.write_bytes(old_policy + policy_append)
MAIN.write_bytes(old_main + b"\n\n" + report_data)
assert POLICY.read_bytes()[:len(old_policy)] == old_policy
assert MAIN.read_bytes()[:len(old_main)] == old_main
assert MAIN.read_bytes().count(report_data) == 1
for item in previous["files"]:
    if item["path"] != "research/research_global_review_policy.md":
        verify(ROOT / item["path"], item["bytes"], item["sha256"])

stopped = previous["stopped_default_windows"] + ["Fixed native chi_-8 monomial contact prototype with selected-even determinant after matched actualY and complete primitive-cost feasibility settlement"]
manifest = {
    "round": 257,
    "date_completed": "2026-10-10",
    "classification": "progress",
    "goal_status": "active",
    "progress_kind": "Full actual real representation and all-n upper; stronger complete prefix integer model and whole-polynomial content; mixed-row and border structure; matched primitive-cost settlement and prototype stop",
    "new_numerical_irrationality_or_independence_theorem": False,
    "global_novelty_or_full_lean_audit": False,
    "formal_global_review": {"last": 256, "previous_formal": 252, "this_round_is_formal": False, "counter_reset_this_round": False, "completed_rounds_since_last": 1, "next_scheduled": 260, "latest_required": 264, "default_interval": 4, "early_core_stagnation_rounds": 2, "maximum_interval": 8},
    "paid_this_round": ["All-index actual monodromy folding with complete heads", "O/J/Z tagged real measure and full Andreief determinant at actual Y", "All-n |2^(-n^2) Delta_n(Y)| upper on the complete matrix", "Complete qtilde_H=2^(3floor(H/2)+1)d_(H+1)^2 for full prefix and all prime powers", "All-coefficient content [2^(n+1)d_(2n)]^n in the old integer polynomial for all integer filters", "Primitive leading safety cost improvement 2+log2 on the quadratic comparison scale", "All-n cross-label confluent counterexample to a free complete Vandermonde row factor", "Exact rational rank-one size update and singular-safe bordered-adjugate identities", "Same-object actual upper, spectral product and primitive cost settlement; stop of this concrete default prototype"],
    "strict_status": {"actual_common_germ_and_contour_paid": True, "actual_tagged_integral_and_full_determinant_upper_paid": True, "complete_prefix_integer_budget_paid_for_new_source": True, "whole_polynomial_content_improvement_paid": True, "optimal_primitive_content_paid": False, "actual_numeric_nonzero_paid_for_new_source": False, "complete_net_energy_paid_for_new_source": False, "target_coefficient_rank_is_numeric_nonzero": False, "safe_upper_is_actual_energy_lower": False},
    "stopped_default_windows": stopped,
    "prototype_stop": {"object": "Same a=1/sqrt2, Y=L(2,chi_-8), actual +1 loop, 3+T, complete native N and ordinary Z, fixed integer P/D and selected-even columns", "reason": "Improved full arithmetic cost and actual energy upper still do not give strict net quadratic decay or actual unbounded nonzero", "general_chi8_impossibility_claim": False, "assets_preserved": True},
    "next_unique_work": {"round": 258, "scope": "One bounded cross-architecture source admission in the unified CDT framework", "admission_requires": ["Fixed candidate, target numerical relation, complete minimal function family and proposed fill-in domain before construction", "Hypothetical numerical relation removes entire nonmeromorphic local monodromy in the complete minimal function family", "Quantifiable common analytic-domain gain", "True period projection, function independence, common pullback and complete prefix arithmetic cost", "Same-object strict holonomy margin or a full-scale certificate changing net feasibility with finite remaining conditions before implementation"], "priority": "Genuinely different cyclotomic channels and multi-source common-domain mechanism", "reject_if": ["Only more germs or jets", "Only removal of already permitted meromorphic pole", "Functional algebraic independence mistaken for numerical independence", "Only an at-least-one statement containing an already known irrational value", "No relation-sensitive mechanism or common-domain gain"], "automatic_parameter_prime_map_sheet_or_vector_extension": False, "abstract_lemma_redefines_numeric_success": False},
    "runs": {"mathematics": 0, "finite_n_hand_heads_programs_or_certificates": 0, "cas_or_interval": 0, "prime_parameter_map_word_scans": 0, "lean": 0, "external_git_mutations": 0, "old_archive_producers": 0, "this_documentary_archive": 1},
    "sources": {"new_web_search_calls": 0, "new_primary_gets": 0, "new_pdf_downloads_by_team": 0, "new_html_downloads_by_team": 0, "whole_primary_paper_reading_claim": False, "precise_scope": "Four final reading scopes; exact frozen256 inputs; self-contained paper proofs"},
    "previous_manifest": pin(PREVIOUS),
    "previous_manifest_nonpolicy_files_preserved": 99,
    "report": pin(REPORT),
    "independent_math_and_report_review": pin(REVIEW),
    "root_independent_spectral_author_review": pin(SOURCES / "root_reading_scope.md"),
    "previous_policy": {"bytes": len(old_policy), "sha256": digest(old_policy)},
    "new_policy": pin(POLICY),
    "previous_main": {"bytes": len(old_main), "sha256": digest(old_main)},
    "new_main": pin(MAIN),
    "files": [pin(path) for path in sorted(paths)],
}
MANIFEST.write_text(json.dumps(manifest, ensure_ascii=False, indent=2)+"\n", encoding="utf-8")
assert PREVIOUS.read_bytes() == previous_data and REVIEW.read_bytes() == review_data
print(json.dumps({"status": "PASS", "numeric_theorem": False, "goal_status": "active", "next_formal_review": 260, "latest_formal_review": 264, "completed_since_formal": 1, "old_nonpolicy_files_preserved": 99, "files": len(manifest["files"]), "manifest": pin(MANIFEST), "main": pin(MAIN), "policy": pin(POLICY)}, ensure_ascii=False))
