"""One-shot documentary archive; no mathematical producer or Git mutation."""
from pathlib import Path
import hashlib
import json
import re

root = Path(__file__).resolve().parent.parent
assert root == Path('E:/kimi-build/zeta5').resolve()
main = root / 'research/cdt_odd_background_progress_20261006.md'
report = root / 'research/research_global_review_round236_20261008.md'
previous = root / 'literature/manifest_fine_holonomy_gate_round235_20261008.json'
dest = root / 'literature/manifest_global_review_round236_20261008.json'


def sha(data):
    return hashlib.sha256(data).hexdigest()


old = main.read_bytes()
body = report.read_bytes()
assert len(old) == 609097
assert sha(old) == '893052a9f26c83b1453b2553c449786e458b5779801bf5a1fa3ebc8af520a687'
assert len(body) == 8215
assert sha(body) == 'ffa610322e48bc13d0f8e2d70bed5b3683fccfbb461802d72f0d91cc08f0fbb6'
assert len(previous.read_bytes()) == 14458
assert sha(previous.read_bytes()) == 'b0e5ccb7f9022fb1874bd14c19042cee2cf4af38e0532fdf204e9c176fc0c6e5'
assert not dest.exists(), 'Do not rerun a completed archive'

frozen = {
    'global_joint_lattice_review_round236_20261008.md':
        (11134, 'b60541c17c0f4440f3c971e3fd7c0224ebcfdd675f6120331d16262e710c4e70'),
    'global_catalan_weight4_review_round236_20261008.md':
        (13797, 'cf93376bf4add588566fc577a3cf3bf682b5164dc9b1e02036e1e588cbfbb6a0'),
    'global_alternative_route_review_round236_20261008.md':
        (11218, 'b99bcb2616a6a2c2fa2640a728464ce209650bce8b3a26e61ca4d3b025b3fe57'),
    'research_round236_joint_lattice_review_20261008.md':
        (3646, '6856154db4ac2d1a23add4d13b269fd9fa68631e98a5f4012270f4db19c60080'),
    'research_round236_catalan_weight4_review_20261008.md':
        (2433, 'bd616edd280ee08f30609a3b77746ccfceac2d317ef481e0f4395e651108c231'),
    'research_round236_root_math_check_20261008.md':
        (5897, '16d08beead578c9c4a1be7672f88906d6000f5d0fb9bd5b335468c803ac3756e'),
}
for name, (size, digest) in frozen.items():
    data = (root / 'research' / name).read_bytes()
    assert len(data) == size and sha(data) == digest, name
review = root / 'research/research_round236_global_report_review_20261008.md'
assert review.is_file(), 'Independent global-report review not yet saved'
assert 'PASS' in review.read_text(encoding='utf-8-sig')

files = set((root / 'research').glob('*round236*20261008.*'))
files.update((root / 'literature/global_review_sources_round236_20261008').glob('*'))
pins = []
for path in sorted(files):
    if not path.is_file():
        continue
    data = path.read_bytes()
    if path.suffix in {'.md', '.py'}:
        content = data.decode('utf-8-sig')
        assert not any(ord(c) < 32 and c not in '\r\n\t' for c in content), path
    pin = {'path': path.relative_to(root).as_posix(), 'bytes': len(data), 'sha256': sha(data)}
    if path.suffix == '.txt':
        content = data.decode('utf-8-sig')
        codes = sorted({ord(c) for c in content if ord(c) < 32 and c not in '\r\n\t'})
        if codes:
            pin['original_pdf_text_control_counts'] = {str(c): content.count(chr(c)) for c in codes}
    pins.append(pin)

links = []
for target in re.findall(r'\]\(([^)]+)\)', body.decode('utf-8-sig')):
    if target.startswith(('http:', 'https:', '#')):
        continue
    assert (report.parent / target.split('#', 1)[0]).resolve().is_file(), target
    links.append(target)

combined = old + b'\n\n' + body
manifest = {
    'round': 236, 'date': '2026-10-08', 'status': 'progress',
    'previous_goal_turn_classification': 'progress',
    'formal_global_review': True,
    'mathematical_program_runs': 0, 'mathematical_program_failures': 0,
    'parameter_scans': 0, 'new_pdf_downloads': 0, 'git_mutations': 0, 'lean_builds': 0,
    'documentary_archive_attempts': 1,
    'mathematical_status': 'Complete local odd-jet obstruction closes fixed weight-four rational filtering; exact full prime-window jet rank and Jacobi determinant give a full CRT integral model with index 45/4 D^2 and same-row-model gain 15/4 D^2. No new numerical irrationality or linear independence theorem.',
    'joint_lattice_paid': 'Same rank-three source, all degree-D columns, all 0..N jets, exact p-window index, all-prime-power CRT fallback, adopted Shidlovsky N=3D+O(1) injection.',
    'joint_lattice_unpaid': 'Direct BC metric degree and complete filtered evaluation transfer; raw index is not CDT tau or strict net margin. Conditional 2*kappa/9=5/2 is not an adopted theorem.',
    'weight4_closed_scope': 'Any nonzero S channel plus complete fixed 1,D,B,P background with C(q) rational coefficients on the two specified accesses cannot be q=4 meromorphic.',
    'weight4_not_closed': 'Larger mixed-period matrices, nonlinear determinants, new sources and independent integral models.',
    'geometric_review': 'Specific cellular projection loses fastest mode; M0,10 remains only a bounded alternative requiring an all-scale actual zeta7 projection, not the already-covered at-least-one zeta5/zeta7 endpoint.',
    'global_review_cadence': {
        'previous_formal': 232, 'elapsed_rounds_before_this_review': 4,
        'last_formal': 236, 'next_default': 242, 'allowed_window': [240, 244],
        'two_round_tactical_trigger': True, 'reset_by_this_round': True,
    },
    'next_interface': '237: prove the same-source joint lattice BC metric/filtered rank criterion, test the complete conservative model, then only refine prime layers if strict headroom remains; stop this model if the bridge or budget fails.',
    'repository_state': 'Fresh read-only ls-remote main equals clean local fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb; no fetch, checkout, mutation, Lean or whole-repository proof certification.',
    'source_scope': 'Individual scopes kept separately; Root FULL selected CDT/ICM/cellular pages and two Catalan sections, agent C FULL eight Catalan sections but no finite-certificate execution.',
    'review_scope': 'Root FULL all three final math notes and scopes; independent C-on-B, A-on-C and final global-report reviews, with explicit unverified original finite certificate boundaries.',
    'verification_scope': 'Only new236 pins and links, preserved235 main prefix and manifest; no historical producer reruns or broad retrospective audit.',
    'predecessor': {'path': previous.relative_to(root).as_posix(), 'bytes': previous.stat().st_size, 'sha256': sha(previous.read_bytes())},
    'main_preserved_prefix': {'bytes': len(old), 'sha256': sha(old)},
    'appended_report': {'path': report.relative_to(root).as_posix(), 'bytes': len(body), 'sha256': sha(body)},
    'main_after_append': {'path': main.relative_to(root).as_posix(), 'bytes': len(combined), 'sha256': sha(combined)},
    'report_links_checked': links, 'new_pins': pins,
}
dest.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
main.write_bytes(combined)
assert main.read_bytes() == combined
print(json.dumps({
    'status': 'PASS', 'round': 236, 'pins': len(pins), 'report_links': len(links),
    'mathematical_runs': 0, 'main_bytes': len(combined), 'main_sha256': sha(combined),
    'manifest_bytes': dest.stat().st_size, 'manifest_sha256': sha(dest.read_bytes()),
}, ensure_ascii=False))
