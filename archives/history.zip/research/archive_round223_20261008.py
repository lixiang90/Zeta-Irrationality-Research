"""One-shot documentary round-223 freeze; no mathematical producers are run."""
from pathlib import Path
from hashlib import sha256
import json
import re

ROOT = Path(__file__).resolve().parents[1]
MAIN = 'research/cdt_odd_background_progress_20261006.md'
REPORT = 'research/research_pade_structure_round223_20261008.md'
PREVIOUS = 'literature/manifest_cdt_global_source_review_round222_20261008.json'
OUTPUT = 'literature/manifest_cdt_pade_structure_round223_20261008.json'
SOURCE_DIR = 'literature/pade_structure_sources_round223_20261008'


def identity(relative):
    data = (ROOT / relative).read_bytes()
    return {'path': relative, 'bytes': len(data), 'sha256': sha256(data).hexdigest()}


def require(relative, length, digest):
    item = identity(relative)
    assert (item['bytes'], item['sha256']) == (length, digest), item
    return item


assert not (ROOT / OUTPUT).exists(), 'Completed documentary archive must not be rerun.'
require(PREVIOUS, 26144, 'b0da22af848abc6d1fa50393a920b523753ee8f1b22c7c739930a212d4b60e9d')
previous = json.loads((ROOT / PREVIOUS).read_text(encoding='utf-8'))
old_checked = [require(p['path'], p['bytes'], p['sha256'])
               for p in previous['pins'] if p['path'] != MAIN]
prefix = (ROOT / MAIN).read_bytes()
assert len(prefix) == 516292
assert sha256(prefix).hexdigest() == '65918c974ba750a38b51f9507c1579819f5d36ffdf7a6c09250d5b293ddc01cb'

expected = '''
research/pade_integer_valued_denominators_round223_20261008.md 6110 cea842775409706034017f9f1dbc7cbcde39ed6d331691dfa3d80588ab79c648
research/pade_holonomic_structure_round223_20261008.md 11517 54eb60ab2835832855cd268c5dfb4318f2c25019a4589cf713483460fa00866a
research/pade_actual_growth_structure_round223_20261008.md 11630 abc734b21846a221e76daf0941dff3f6e5dba47d723ad420f87d78ce9b60922f
research/pade_infinite_nonzero_gate_round223_20261008.md 10073 f12f19984ebdcff427ac336f48869057e48d57353b28e0ea1b620252d2889931
research/research_round223_integer_denominator_review_20261008.md 2284 1a7789ff131bf8613dc6c27ce20a3307667871b2ef2e41cab3aa834bc1e31154
research/research_round223_holonomic_structure_review_20261008.md 4025 944315b055b2e6800c23ab9b945b530aa8158eebbe0e419b179008e306d2bcdb
research/research_round223_actual_growth_review_20261008.md 6094 9b8797bcb7e7852c880f71918985887360b65431046611451f96222f7e1eb1f7
research/research_round223_infinite_gate_review_20261008.md 2604 9a301287e9aa45d7c6f76400418353abcbec5980ce64851d87147f0b9aec875a
research/research_pade_structure_round223_20261008.md 8464 6ee2aa403fdd73e32b6d5cc82f3611b49e4ef231b0b5b3f646e7937fa57f1edd
literature/pade_structure_sources_round223_20261008/root_reading_scope.md 5747 81b4d3e03ed933ca56ad833b6e824645907f0c49d934f3c2009ba2c888be7a0e
literature/pade_structure_sources_round223_20261008/lambert_reading_scope.md 3442 3b58968f46b60f3f7120691b5515ea319ff8fcf50b7eb8ed8d4e2c497fb1e978
literature/pade_structure_sources_round223_20261008/dual_source_reading_record_round223_20261008.md 4344 60766f00732f4d3a2d6cfd877caa86a8ff0bedb869349a38ec96014552f87709
'''
pins = {p['path']: p for p in old_checked}
pins[PREVIOUS] = identity(PREVIOUS)
new_paths = []
for line in expected.splitlines():
    if line.strip():
        relative, length, digest = line.split()
        pins[relative] = require(relative, int(length), digest)
        new_paths.append(relative)

# Independent final report receipt, actual FULL read by Root before execution.
REVIEW = 'research/research_round223_report_review_20261008.md'
REVIEW_BYTES = 7087
REVIEW_SHA = 'cc5b1156f2a295a4206b951d573b01e271265e09727aa4d7bad7a1b1e209ef11'
pins[REVIEW] = require(REVIEW, REVIEW_BYTES, REVIEW_SHA)
new_paths.append(REVIEW)

for file in sorted((ROOT / SOURCE_DIR).rglob('*')):
    if file.is_file():
        relative = file.relative_to(ROOT).as_posix()
        pins[relative] = identity(relative)
        new_paths.append(relative)

new_mds = sorted({p for p in new_paths if p.endswith('.md')})
links = []
for relative in new_mds:
    content = (ROOT / relative).read_text(encoding='utf-8')
    assert not any(ord(c) < 32 and c not in '\n\r\t' or ord(c) == 127 for c in content), relative
    for target in re.findall(r'\[[^\]\n]*\]\(([^)\n]+)\)', content):
        target = target.strip().strip('<>').split('#', 1)[0]
        if re.match(r'^(?:https?://|app://)', target):
            continue
        if Path(target).suffix.lower() not in {'.md', '.pdf', '.json', '.txt', '.py', '.png', '.tex'}:
            continue  # Not mathematical [v^h](...) notation.
        resolved = ((ROOT / relative).parent / target).resolve()
        assert resolved.is_relative_to(ROOT), (relative, target)
        link_path = resolved.relative_to(ROOT).as_posix()
        assert resolved.is_file() or link_path == OUTPUT, (relative, target)
        links.append({'source': relative, 'target': link_path})
        if resolved.is_file() and link_path not in pins and link_path != MAIN:
            pins[link_path] = identity(link_path)

new_pdfs = [p for p in new_paths if p.endswith('.pdf')]
assert len(set(new_pdfs)) == 3, new_pdfs
report = (ROOT / REPORT).read_bytes()
main_final = prefix + b'\n\n' + report
(ROOT / MAIN).write_bytes(main_final)
assert (ROOT / MAIN).read_bytes() == main_final
pins[MAIN] = identity(MAIN)
script = Path(__file__).relative_to(ROOT).as_posix()
pins[script] = identity(script)

record = {
    'round': 223, 'date': '2026-10-08', 'goal_status': 'active',
    'new_numerical_theorem': False,
    'round_outcome': 'Actual fixed packet G-function structure, full prime-power denominator improvement, actual alternating remainder exponential upper bound, and complete first residuals at two unbounded prime scales.',
    'navigation': {
        'last_formal_global_review': 222,
        'next_normal_global_review': 228, 'allowed_window': [226, 230],
        'early_triggers': ['structural counterexample/cap', 'two completed rounds without a core interface advance'],
        'this_round_has_core_interface_advance': True,
        'next_task': 'Concrete same-source recurrence/module and nonzero bridge, or exact nondegeneracy of the remaining p-adic rows; no repeated safe-bound or parameter scans.'},
    'completed_math': [
        'Actual A/C, even subsequences, Delta/Xi and fixed rational-g H are P-recursive and their generating functions satisfy the G-function definition; no explicit operator or minimal rank.',
        'All prime powers: d_n^(6-j)c_jk integral; 64d_n^(7-s)A_s integral; complete d_n^7 C integral.',
        'Delta safe prefix exponent 24->12; Xi/H 48->26. Conditional ordinary flat(0,12,26) cost 166/9; not an optimal joint cost or passed CDT gate.',
        'Actual I_n=O(n^-5 log(n) rho^n), rho=2^42/3^27<1, retaining all finite head terms. J upper bound has factor 2^60 rho^2>1.',
        'First normalized residual ranks are exactly 2 at n=p-1,p+1,p+3 (p>37) and exactly 1 at n=2p,2p+2,2p+4 (p>11); local integrality, not infinite nonzero.'
    ],
    'remaining_gates': [
        'infinite target nonzero with a paid finite-singularity bridge',
        'explicit actual recurrence/cyclic module and rank',
        'generic dominant singularity and strict relation overconvergence',
        'same-source complete arithmetic/analytic strict comparison'
    ],
    'execution_ledger': {
        'mathematical_program_runs': 0, 'CAS': 0, 'creative_telescoping_runs': 0,
        'recurrence_guessing': 0, 'parameter_or_prime_scans': 0, 'matrix_programs': 0,
        'PSLQ': 0, 'numerical_integrations': 0, 'old_proof_producer_reruns': 0,
        'Lean_builds': 0, 'Git_mutations': 0, 'new_repository_status_check': False,
        'new_PDF_downloads': 3, 'new_DLMF_short_formulas': 2,
        'documentary_operations': 'Selected-page PDF extraction; two PNG renders; metadata/hash/link/control checks; this one-shot archive. No mathematical producer imports or executions.'
    },
    'source_claim_policy': 'Only the actual selected primary pages/sections scoped in the three reading records and independent receipts. Root selected Zudilin PDF6,7,23,24 and viewed PNG6,23; not full primary papers, current-cloud status, or Lean audit.',
    'independent_review': {
        'integer_model': 'C FULL PASS', 'holonomic_G': 'B FULL PASS',
        'actual_growth': 'A FULL PASS', 'prime_residual_gates': 'Root independent FULL PASS within stated scope',
        'report_and_root_scope': 'C FULL PASS at final pinned identity'
    },
    'predecessor': {'manifest': identity(PREVIOUS), 'immutable_pins_checked': len(old_checked),
                    'mutable_main_excluded_from_old_final_hash': True},
    'main_append': {'preserved_prefix_bytes': len(prefix), 'preserved_prefix_sha256': sha256(prefix).hexdigest(),
                    'append_separator_hex': '0a0a', 'appended_report': identity(REPORT), 'final': identity(MAIN)},
    'verification': {'control_character_documents': len(new_mds), 'controls': 'PASS',
                     'local_links': links, 'links': 'PASS including the planned manifest checked after creation'},
    'pins': sorted(pins.values(), key=lambda p: p['path']),
}
(ROOT / OUTPUT).write_text(json.dumps(record, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
for link in links:
    assert (ROOT / link['target']).is_file(), link
for item in record['pins']:
    require(item['path'], item['bytes'], item['sha256'])
require(PREVIOUS, 26144, 'b0da22af848abc6d1fa50393a920b523753ee8f1b22c7c739930a212d4b60e9d')
print(json.dumps({'manifest': identity(OUTPUT), 'main': identity(MAIN), 'pins': len(record['pins']),
                  'local_links': len(links), 'controls_md': len(new_mds),
                  'predecessor_immutable_pins': len(old_checked), 'checks': 'PASS'}, ensure_ascii=False))
