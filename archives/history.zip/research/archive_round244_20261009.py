"""One-shot documentary archive of round244; no mathematics is executed."""
from pathlib import Path
import hashlib
import json

root = Path(__file__).resolve().parent.parent
assert root == Path('E:/kimi-build/zeta5').resolve()
main = root / 'research/cdt_odd_background_progress_20261006.md'
report = root / 'research/research_global_review_round244_20261009.md'
policy = root / 'research/research_global_review_policy.md'
previous = root / 'literature/manifest_logistic_residual_filter_round243_20261009.json'
sources = root / 'literature/global_review_sources_round244_20261009'
destination = root / 'literature/manifest_global_review_cm_log_round244_20261009.json'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def pin(path):
    data = path.read_bytes()
    return {
        'path': path.relative_to(root).as_posix(),
        'bytes': len(data),
        'sha256': sha(data),
    }


assert not destination.exists(), 'Never rerun a completed documentary producer'
old = main.read_bytes()
assert len(old) == 663490
assert sha(old) == '018b9afb42cfd9585e78dcefcac367f0c84943beb22ce8222fab4e38d9908765'
assert sha(previous.read_bytes()) == 'eb880b676e8c6987aaa678f05167a2bcbc7061559c0358b52955e8f3f61e388b'

expected = {
    'research/research_global_review_round244_20261009.md': (9348, '526a76d60e568902b5e7f77d9f20ade33478c3dea181edade8c8ddbad1f6b3b3'),
    'research/global_cm_log_trigger_round244_20261009.md': (6783, '187cbbd9bda470a07691dc2c962dd5054144e6c65a6542491498bb9342456d9c'),
    'research/global_chi7_positive_carrier_round244_20261009.md': (7698, '639071cdf1d9469046246623e2308069b55271650cd74a17d3f837720b6d34c3'),
    'research/global_logistic_direction_review_round244_20261009.md': (9524, '74a58cdec68dec627b6fd4239797f0535b5c0747a1f5b64006e08b9d73f038a5'),
    'research/global_period_direction_review_round244_20261009.md': (13132, 'cd34a475100c637a28c99f72508186d5d1a84a425ed103baa5fe3d871c9fa0a9'),
    'research/global_repository_direction_review_round244_20261009.md': (9111, 'd4d46f7ca53bd6d642f12a7bf29004416c52f7ba4181a4bab0236876206b33c6'),
    'research/research_round244_chi7_positive_carrier_review_20261009.md': (2390, 'bfa363a8e7ec5e20999fa5ec0c6e74df474c7e1b9841c6e86a871485e72a3788'),
    'research/research_round244_cm_log_trigger_review_20261009.md': (3509, '5d1a4ebc8a90e0b257416a17698411492d7f4f633fa0d4f4ee9a5d17474b2960'),
    'research/research_round244_global_report_review_20261009.md': (3361, '99abbbceea5abc8a84128947e384fddaf81f4fcbee1c7eec3760bc26404c0aa7'),
    'research/research_global_review_policy.md': (7884, 'd3fe3938af18fda00c15c8aa2c29e37c846ae2dfa67f84872469a4f36116a80c'),
    'literature/global_review_sources_round244_20261009/alternative_reading_scope.md': (3085, '801090ac4058c7f5805a0088dbb43e874ced8c1339acb55d26360917cf8f7984'),
    'literature/global_review_sources_round244_20261009/alternative_cm_review_scope.md': (1407, '26a8a34ee41187b841c4e24360d2db384c86870d61b567dd5c1036dfc5289e82'),
    'literature/global_review_sources_round244_20261009/packet_reading_scope.md': (6409, '0c0fb18786fda939ee4ce0f8b15b5d2cbe468688b7c3f491101ec3eb62de07bb'),
    'literature/global_review_sources_round244_20261009/dual_reading_scope.md': (9866, '4907d0dd9ca62dad5571fb0f50801ae55ce27ebfb25767720bef47b452cecf6a'),
    'literature/global_review_sources_round244_20261009/dual_report_review_scope.md': (3048, 'f469037664592e0fc0b0cee0e53bfbb20ebddf02935d78f2713de5a12249b0e0'),
    'literature/global_review_sources_round244_20261009/root_fischler_siegel_current_20261009.pdf': (513673, '1576b611c8c0771fb63406274faf022898d568a085f243a469dda1c0f7ece7f5'),
    'literature/global_review_sources_round244_20261009/alternative_sun_zhou_2602_12091v2.html': (1295974, '45dac041f91f907b566863b6aaa56ff1bf251c0c899b7882460503bc9caa2e2d'),
    'literature/global_review_sources_round244_20261009/dual_sun_zhou_v2_intro_thm11_table1.html': (135447, 'b252d2d254a6e321ce645123cb646b79a6f493f5c6caa824b565a2d6e644b095'),
    'literature/global_review_sources_round244_20261009/dual_sun_zhou_v2_intro_thm11_table1.txt': (13189, 'b4109e83c58a0685fdac5040d2b7d4600db808c3071f3e8fae2abb4f7dd6ae0f'),
    'literature/global_review_sources_round244_20261009/dual_cdt_L2chi_fresh_author_20261009.pdf': (3621996, '7100fc291bb5c2bce4880d725eeba11e73114b0a20b4277f522030f855d89835'),
    'literature/global_review_sources_round244_20261009/dual_git_readonly_check.json': (557, '5787166fd7a7c1138d9af9f2aafb22ba0f0ef37ad059dc179e4008aadb174c23'),
}
for path, (length, digest) in expected.items():
    record = pin(root / path)
    assert record['bytes'] == length and record['sha256'] == digest, path

policy_data = policy.read_bytes()
previous_policy = {
    'bytes': 6141,
    'sha256': '3b009d8a08aedb4192ae52cc6724250110afe367692ef68a15792e2c217fd26c',
}
assert sha(policy_data[:6141]) == previous_policy['sha256']
for receipt, target in (
    ('research/research_round244_chi7_positive_carrier_review_20261009.md',
     'research/global_chi7_positive_carrier_round244_20261009.md'),
    ('research/research_round244_cm_log_trigger_review_20261009.md',
     'research/global_cm_log_trigger_round244_20261009.md'),
    ('research/research_round244_global_report_review_20261009.md',
     'research/research_global_review_round244_20261009.md'),
):
    text = (root / receipt).read_text(encoding='utf-8-sig')
    assert 'PASS' in text and expected[target][1] in text, receipt

records = set((root / 'research').glob('*round244*20261009.*'))
records.update(p for p in sources.rglob('*') if p.is_file())
records.add(policy)
pins = [pin(p) for p in sorted(records)]
body = report.read_bytes()
combined = old + b'\n\n' + body
assert len(combined) == 672840
manifest = {
    'round': 244,
    'date_started': '2026-10-09',
    'date_completed': '2026-10-10',
    'classification': 'progress',
    'previous_goal_turn_classification': 'progress',
    'goal_status': 'active',
    'new_numerical_irrationality_or_independence_theorem': False,
    'formal_global_review': {
        'last': 240, 'this_round': 244, 'completed_round_interval': 4,
        'counter_reset_this_round': True, 'next_scheduled': 248,
    },
    'bounded_main_window': [245, 246],
    'resource_decision': {
        'sole_main_admission': 'CM mixed-period source: actual rank, full integral types, all transported leaves',
        'old_K5_default_local_optimization': 'stop',
        'chi7_scalar_and_symmetric_sources': 'calibration and nonzero reserve only',
        'automatic_window_extension': False,
        'same_object_arithmetic_analytic_and_nonzero_required': True,
    },
    'object': {
        'target': '735 L(2, chi_-7) - 86 pi^2',
        'CM_point': '1/4096',
        'relation_source': 'H_g(z) = integral_0^z (G(t) + g F(t))/(1-4096 t) dt',
        'primary_evaluation_input': 'Sun-Zhou 2602.12091v2, (1.12), Theorem1.1 and Table1',
        'primary_full_modular_proof_independently_certified': False,
    },
    'paid': [
        'Formal global comparison of recent four rounds, with explicit resource and exit decisions.',
        'Chi_-7 full shifted functional projection and uniform common-contour leading Heine comparison.',
        'Chi_-7 positive even kernel and symmetric-source positive Gram nonzero at all n,h.',
        'Full nonsymmetric foreign-prime tail rank and coefficient-cost upper certificate.',
        'A specific fixed rational cover of the low-weight K source is relation-blind for its basic entry.',
        'CM native logarithm cancels under the hypothesized rational target relation.',
        'Complete CM Taylor prefix integer clearers: 92b d_N d_(2N)^2 for H_g, 92 d_(2N)^2 for G.',
        'Exact seven-row rational differential closure; actual rank is at most seven.',
        'G-function defining conditions and native full disk continuation under the target hypothesis.',
        'Independent full paper reviews of the chi7 proof, CM proof and final global report.',
    ],
    'not_paid': [
        'Actual independent or minimal cyclic rank of the complete CM source.',
        'Complete arithmetic types, primitive joint lattice, all transported CM leaves and legal common map.',
        'Strict same-object holonomy or BC budget and a new numerical irrationality or independence theorem.',
        'Independent full certification of the primary modular evaluation proof or global novelty.',
        'Original full -6 analytic input certification; transfer alone does not certify its value.',
        'Lean kernel, full repository or import audit, or a solution for all odd zeta values.',
    ],
    'upper_certificates': {
        'old_K5_whole_prime_rate': '1511/60',
        'old_K5_recent_saving': '1/24',
        'chi7_foreign_tail_35_over_2_to_35': '175/4',
        'these_are_actual_fee_lower_bounds': False,
    },
    'next_gate': 'Rounds245-246: first actual full cyclic rank, integral types and transported-leaf admission; no map scan before leaf conditions, no old K5 prime restart; redirect if the bounded gate fails.',
    'runs': {
        'mathematics': 0, 'cas_or_interval': 0, 'prime_or_parameter_scans': 0,
        'lean': 0, 'external_git_mutations': 0, 'old_archive_producers': 0,
        'this_documentary_archive': 1,
    },
    'source_reading_scope': 'Per-reader scope files distinguish full project documents from primary selected pages; stored full PDFs or HTML do not imply full mathematical proof certification.',
    'previous_manifest': pin(previous),
    'report': pin(report),
    'previous_policy': previous_policy,
    'new_policy': pin(policy),
    'previous_main': {'bytes': len(old), 'sha256': sha(old)},
    'new_main': {
        'path': main.relative_to(root).as_posix(),
        'bytes': len(combined), 'sha256': sha(combined),
    },
    'files': pins,
}

main.write_bytes(combined)
with destination.open('x', encoding='utf-8', newline='\n') as stream:
    json.dump(manifest, stream, ensure_ascii=False, indent=2)
    stream.write('\n')
assert main.read_bytes()[:len(old)] == old
assert main.read_bytes()[len(old):] == b'\n\n' + body
for record in pins:
    assert pin(root / record['path']) == record
print(json.dumps({
    'status': 'PASS', 'manifest': pin(destination), 'main': pin(main),
    'pinned_files': len(pins), 'formal_review_next': 248,
}, ensure_ascii=False))
