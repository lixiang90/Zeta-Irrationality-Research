"""One-shot documentary archive for round 249; no mathematics or Git runs."""
from pathlib import Path
import hashlib
import json

ROOT = Path(__file__).resolve().parents[1]
assert ROOT == Path(r"E:\kimi-build\zeta5").resolve()
MANIFEST = ROOT / "literature/manifest_fricke_admission_round249_20261010.json"
assert not MANIFEST.exists(), "Completed archive must not be rerun"
PREVIOUS = ROOT / "literature/manifest_global_review_round248_20261010.json"
MAIN = ROOT / "research/cdt_odd_background_progress_20261006.md"
POLICY = ROOT / "research/research_global_review_policy.md"
REPORT = ROOT / "research/research_fricke_admission_progress_round249_20261010.md"
REVIEW = ROOT / "research/research_round249_fricke_admission_review_20261010.md"


def digest(data):
    return hashlib.sha256(data).hexdigest()


def pin(path):
    data = path.read_bytes()
    return {"path": path.relative_to(ROOT).as_posix(), "bytes": len(data), "sha256": digest(data)}


def verify(path, size, sha):
    data = path.read_bytes()
    assert len(data) == size and digest(data) == sha, str(path)
    return data


previous_data = verify(PREVIOUS, 12291, "d6b4de454d024d7814942794ed2e6df4f5dc4400b729db3bee68693b731aa8c4")
previous = json.loads(previous_data)
assert len(previous["files"]) == 30
for item in previous["files"]:
    verify(ROOT / item["path"], item["bytes"], item["sha256"])
old_main = verify(MAIN, 699540, "35235950844d3b55036783a046dcee7c2b35f1ef4cc9d12ff859424ab8dd2f43")
old_policy = verify(POLICY, 14895, "7cb22679bc034c89995e8a6ab5de7ee1b826954faccc3fbf8f1676c7154209cd")
report_data = verify(REPORT, 5770, "7e507934073941998575666cf2f161aa7a75516c90131afc6cb9da6d4ca89dc2")

fixed = [
    ("research/chi7_fricke_return_periods_round249_20261010.md", 11197, "31c4ed25574a9670e37eb9f92e33487ba92ff9821cadf49083f746586cd1f917"),
    ("research/fricke_local_monodromy_gate_round249_20261010.md", 13239, "94e5777244ad1c13f315863b5ab02e53ef3bb29cd611561447e2d517506faba5"),
    ("research/fricke_number_field_budget_round249_20261010.md", 10490, "b4837616dcd55384b9d4ba6de2cdd206cf6786880b88ad34d9972cd070b01f8e"),
    ("research/fricke_univalent_product_gate_round249_20261010.md", 8502, "e15164de3d8f00cf4901e81637c3950a44fa70c53991ec1e6d1f0980952ee165"),
    ("research/chi7_fricke_return_fixed_certificate_round249_20261010.py", 4022, "264c7fba643e86a557f9020a5ed25a42b44f4c393cf3fcbb5ac37def83b19fc6"),
    ("research/chi7_fricke_return_fixed_certificate_round249_20261010.json", 4237, "ac81d61f860e4abab65ce3c0191c6b3d123b2facfe36541b151f605ddccaf3b3"),
    ("literature/fricke_admission_sources_round249_20261010/root_reading_scope.md", 3781, "de3510eaeecc6028abf49166d997df7c7b4b63ec122ad20179cc9901953f29ca"),
]
for rel, size, sha in fixed:
    verify(ROOT / rel, size, sha)
verify(REVIEW, 4719, "eec04e8966d3c92350dd05c375a4506ced2beda02db21e34d7bff1183f54655a")
review_text = REVIEW.read_text(encoding="utf-8-sig")
for sha in [fixed[3][2], digest(report_data)]:
    assert sha in review_text, "Unique review must cover this frozen math/report"
assert "5770" in review_text and "PASS" in review_text and "252" in review_text

policy_append = """

## 第249轮停止单叶入口并集中运输稳定子

249已付四个指定椭圆返回的完整周期常数、四有限点收敛局部型、所有∞返回叶的非零log²，以及当前完整数域整型的两处单叶产品cap。两列(0,1,1)给τ16/9、rank3；strict要求平均λ>8/3，而两个实处均单叶时平均λ≤log4。立即停止该arch-only单叶入口，不投入地图或素数微调。此界不涵盖多叶图、更优实际整型或已付有限处增益，没有新数值定理。

250唯一前置证书为完整Γ/Fricke生成与路径关系、实际仿射周期矩阵和全运输稳定子；先查哪些有限点的所有到达叶强制偶数分歧，才判断能否取得多叶图的椭圆提升容量界或合法补支逃逸。四个指定返回不冒认完整生成系，∞全叶证书不扩至四有限点。有限处形式增益只为条件后备，不同时开优化前线；不做word/map/prime/parameter/LCD扫描。

249–250默认窗口不自动延长；250不能改变多叶准入或同对象strict比较则结束窗口并重新比较其它明确数值出口。真正改变strict比较的核心证书才允许252前有界补完。最近正式复盘248，当前距它一轮；下一次仍252，连续两轮无核心进展提前查方向，最迟八轮规则继续。详见research_fricke_admission_progress_round249_20261010.md；goal active。
""".encode("utf-8")
assert "## 第249轮".encode("utf-8") not in old_policy
assert report_data not in old_main

# All frozen prerequisites and report review are checked before either append.
POLICY.write_bytes(old_policy + policy_append)
MAIN.write_bytes(old_main + b"\n\n" + report_data)
assert POLICY.read_bytes()[:len(old_policy)] == old_policy
assert MAIN.read_bytes()[:len(old_main)] == old_main
assert MAIN.read_bytes().count(report_data) == 1

paths = set((ROOT / "research").glob("*round249*20261010*"))
paths.update((ROOT / "literature/fricke_admission_sources_round249_20261010").iterdir())
paths.add(POLICY)
manifest = {
    "round": 249,
    "date_completed": "2026-10-10",
    "classification": "progress",
    "progress_kind": "Exact four returns, rational forcing/all-infinity leaves, number-field budget and univalent product obstruction",
    "goal_status": "active",
    "new_numerical_irrationality_or_independence_theorem": False,
    "formal_global_review": {"last": 248, "this_round_is_formal": False, "completed_rounds_since_last": 1, "counter_reset_this_round": False, "next_scheduled": 252},
    "source": {"field": "Q(sqrt(2))", "coordinate": "t=(eta1 eta14/(eta2 eta7))^4", "rank": 3, "target": "L(2,chi_-7)/2+sqrt(2)pi^2/28 not in Q(sqrt(2))", "safe_full_prefix": "7b d_N^2", "cleared_frame": ["1", "7b B_g", "7b E delta B_g"], "lcm_array": [[0, 0], [1, 1], [1, 1]], "tau": "16/9"},
    "paid": ["Four specified order-two actual returns and their exact Eichler constants", "Complete rational forcing t[11+9eps sqrt(2)-8(1+eps sqrt(2))t]/(7Q_-eps)", "Convergent finite local analytic plus square-root channel", "Every infinity-return leaf retains nonzero log-squared term", "Actual coefficient conjugate and nonfillable native small-root leaf", "Holomorphic cleared full frame and normalized number-field budget", "All univalent two-place maps satisfy derivative product <=16", "Strict basic necessary average log derivative >8/3"],
    "not_paid": ["New numerical theorem", "Four specified returns form full generating/path basis", "All finite transported filling leaves or stabilizer", "Multivalent legal-map bound", "Actual positive finite-place charts", "Optimal joint integral type", "Global novelty or fresh Lean proof audit"],
    "closed_entry": {"scope": "Current complete safe array, arch-only basic criterion, both embeddings univalent", "cap": "average log derivative <=log(4)", "strict_necessary": ">8/3", "multivalent_or_all_place_exclusion": False},
    "conditional_all_place": {"finite_gain_needed_if_arch_univalent": ">8/3-log(4)", "actual_charts_constructed": False},
    "resource_decision": {"unique_next_round": 250, "first_certificate": "Complete generating paths, affine period monodromy and transported stabilizer", "default_window": [249, 250], "parameter_word_prime_map_lcd_scans": False, "formal_next": 252, "two_stagnant_rounds": "Reconsider direction early"},
    "runs": {"mathematics": 1, "exact_fixed_certificate": 1, "root_math": 0, "cas_or_interval": 0, "prime_parameter_map_word_scans": 0, "lean": 0, "external_git_mutations": 0, "old_archive_producers": 0, "this_documentary_archive": 1},
    "new_primary_carriers": {"official_html_saved": 1, "reused_cdt_selected_texts": 2, "fresh_repository_get": 0, "full_primary_pdf_claim": False},
    "previous_manifest": pin(PREVIOUS),
    "previous_manifest_files_preserved": 29,
    "report": pin(REPORT),
    "independent_math_and_report_review": pin(REVIEW),
    "previous_policy": {"bytes": len(old_policy), "sha256": digest(old_policy)},
    "new_policy": pin(POLICY),
    "previous_main": {"bytes": len(old_main), "sha256": digest(old_main)},
    "new_main": pin(MAIN),
    "files": [pin(p) for p in sorted(paths) if p.is_file()],
}
MANIFEST.write_text(json.dumps(manifest, ensure_ascii=False, indent=2)+"\n", encoding="utf-8")
assert PREVIOUS.read_bytes() == previous_data
for item in previous["files"]:
    if item["path"] != "research/research_global_review_policy.md":
        verify(ROOT / item["path"], item["bytes"], item["sha256"])
print(json.dumps({"status": "PASS", "numeric_theorem": False, "next_formal_review": 252, "files": len(manifest["files"]), "manifest": pin(MANIFEST), "main": pin(MAIN), "policy": pin(POLICY)}, ensure_ascii=False))
