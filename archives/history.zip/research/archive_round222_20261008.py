"""Documentary round-222 freeze. Never imports or executes mathematical producers."""
from pathlib import Path
from hashlib import sha256
import json
import re

ROOT = Path(__file__).resolve().parents[1]
MAIN = 'research/cdt_odd_background_progress_20261006.md'
REPORT = 'research/research_global_review_round222_20261008.md'
PREVIOUS = 'literature/manifest_cdt_cyclotomic_symmetry_round221_20261008.json'
OUTPUT = 'literature/manifest_cdt_global_source_review_round222_20261008.json'
SOURCE_DIR = 'literature/global_review_sources_round222_20261008'

def identity(relative):
    data = (ROOT / relative).read_bytes()
    return {'path': relative, 'bytes': len(data), 'sha256': sha256(data).hexdigest()}

def require(relative, length, digest):
    item = identity(relative)
    assert (item['bytes'], item['sha256']) == (length, digest), item
    return item

assert not (ROOT / OUTPUT).exists(), 'A completed archive must not be rerun.'
require(PREVIOUS, 13444, 'c72ee3ec89a90ec9b3a851c89884dd99b0c600e52dfcaf5adaeaaea2e3cd1a86')
previous = json.loads((ROOT / PREVIOUS).read_text(encoding='utf-8'))
old_checked = [require(p['path'], p['bytes'], p['sha256'])
               for p in previous['pins'] if p['path'] != MAIN]
prefix = (ROOT / MAIN).read_bytes()
assert len(prefix) == 507032
assert sha256(prefix).hexdigest() == '7ff0c61a74a5ad1500a1c79ae8379a2292a44f312942b91b89c495565ad53295'

expected_research = '''
elementary_beta_weight_family_global_round222_20261008.md 7024 1004a8326ce6c8fa12e08a79354236b7ec651a0e8f4961afadf506c06051c64d
zeta_residue_suspension_rigidity_global_round222_20261008.md 2798 7ff7a3dba66b658b2022d931d7cfcf604908d33d21e6081bda015a69346699c9
cyclotomic_joint_integral_global_round222_20261008.md 8410 6c45b5ab4083d012d32f35cfad6f29f522b66f8b3420c8461490677d460d80cc
relation_source_architecture_global_round222_20261008.md 11908 35cc2ee9e99f667bdb1881efeb6ff8142cdbd1a088cef92822f2577e604c948d
openai_source_architecture_global_round222_20261008.md 15555 e6d56d39c27f5ae67021598cac0e3df5a3d0b065582e640168d2cf029437aeb9
pade_target_head_nonzero_round222_20261008.md 3006 c017f50216ba3f9c8d37525ddac139bbceaf27d0f9e2c3aea03a05967e001b7f
research_global_review_round222_20261008.md 9258 a29a0253b047859a035d8098aafb37cc1773177594548f9429185a239ffb6f32
research_round222_beta_weight_family_review_20261008.md 3234 c28fe88c6536b69a8294be2aab80dac588358d181d6427a95bd54990250cc9e8
research_round222_zeta_suspension_rigidity_review_20261008.md 2053 771dfaeb57f1e199872f1b9b33e18c5a97edf80865b2266cbaf75096b40bafdf
research_round222_joint_integral_review_20261008.md 2207 300bc8178cbaa5167cbf75ac9d3488fd0a5a00b7e29adbd420943a31a438af9d
research_round222_relation_packet_review_20261008.md 2428 694de1f98b48023a1abdbdcb9af2507cdfdccb1968b0c64b5be9bd6558857c92
research_round222_source_architecture_review_20261008.md 3746 0046422ace46f4e102f8c0d12e871fa39887b8867b6a319a1db760b65aaf0c15
research_round222_pade_target_head_review_20261008.md 3439 5a339e0c598ef92d3a3b87ec25b5af0ebd5de027567d498d29b5c69294348099
certify_pade_target_head_round222_20261008.py 2046 f6c4c10658ef388bc05a77d6331f254ec25cd64a370dac23da5bd0acde41df1e
pade_target_head_certificate_round222_20261008.json 550 5f718666ac8e40e74bf4d7c1946ed1938ed68275d72b866d9032f32a05323127
review_pade_target_head_bell_round222_20261008.py 4138 5d927f6204f43322ebfbed3d2307124bf1993f0a79fb60f432f0ac110bfd47f7
pade_target_head_bell_review_round222_20261008.json 3271 c39442df73ecaa941eb9c535c87df0dd80f69e78f0ace6e8bf41ec7199b80740
'''
pins = {p['path']: p for p in old_checked}
pins[PREVIOUS] = identity(PREVIOUS)
for line in expected_research.splitlines():
    if line.strip():
        name, length, digest = line.split()
        relative = 'research/' + name
        pins[relative] = require(relative, int(length), digest)
require(SOURCE_DIR + '/source_reading_record.md', 11126,
        '6a71dc5d857629ab8ffdc833beeb28026f8b0c4e116a99ec21810dc84f657dab')
require(SOURCE_DIR + '/root_reading_scope.md', 6041,
        'da04321e56cfbb5ef202c568c93ac4bc81989bfc7994d48b898062a38af8985a')
global_review = 'research/research_round222_global_report_review_20261008.md'
pins[global_review] = require(global_review, 7561,
                            '72c6583845ba8ea459f1e7bd3443190d1cef8e81934e0fad553dcc24070b7548')
for file in sorted((ROOT / SOURCE_DIR).rglob('*')):
    if file.is_file():
        relative = file.relative_to(ROOT).as_posix()
        pins[relative] = identity(relative)
for relative, length, digest in [
    ('literature/fauzan_zeta5.pdf', 476337, 'a42c05ccc46b9a7c36428913453c4617202c59109713ba20f464ab9ec640d0da'),
    ('literature/fischler2020_dirichlet_irrationality.pdf', 243833, '8faaf867a2d2b5ef608f53190cd5cef01e6ca79eabf97d397f009e8672e768e7'),
    ('literature/fischler_rivoal2013_mzv_pade_vasilyev_v1.pdf', 267828, '8121d1e154c12de2169333555d858124d43ad7749709d5a73443661468ae22f1'),
    ('literature/mistiaen2025_dirichlet_l_independence_v1.pdf', 507853, 'a10553ad0b221f9620b229943400cab24ed20876c2bf459d318c14806a08c65d'),
    ('literature/openai_math_2026_special_values_20261007/openai2026_catalans_constant_irrational_20260924.pdf', 574388, '4023d0344abceb79dc46a16380dac3a662193f9d4f23e6c340b2162068b04c0e'),
]:
    pins[relative] = require(relative, length, digest)

new_mds = [p for p in pins if p.endswith('.md') and
           ('round222_' in p or p.startswith(SOURCE_DIR + '/'))]
links = []
for relative in sorted(new_mds):
    content = (ROOT / relative).read_text(encoding='utf-8')
    assert not any(ord(c) < 32 and c not in '\n\r\t' or ord(c) == 127 for c in content), relative
    for target in re.findall(r'\[[^\]\n]*\]\(([^)\n]+)\)', content):
        target = target.strip().strip('<>').split('#', 1)[0]
        if re.match(r'^(?:https?://|app://)', target):
            continue
        if Path(target).suffix.lower() not in {'.md', '.pdf', '.json', '.txt', '.py'}:
            continue  # excludes mathematical [t^n](...) notation
        resolved = ((ROOT / relative).parent / target).resolve()
        assert resolved.is_relative_to(ROOT), (relative, target)
        link_path = resolved.relative_to(ROOT).as_posix()
        assert resolved.is_file() or link_path == OUTPUT, (relative, target)
        links.append({'source': relative, 'target': link_path})
        if resolved.is_file() and link_path not in pins and link_path != MAIN:
            pins[link_path] = identity(link_path)

report = (ROOT / REPORT).read_bytes()
main_final = prefix + b'\n\n' + report
(ROOT / MAIN).write_bytes(main_final)
assert (ROOT / MAIN).read_bytes() == main_final
pins[MAIN] = identity(MAIN)
script = Path(__file__).relative_to(ROOT).as_posix()
pins[script] = identity(script)
record = {
    'round': 222, 'date': '2026-10-08', 'goal_status': 'active',
    'new_numerical_theorem': False,
    'round_outcome': 'Early global review; two family lemmas, joint integral sublattice, explicit three-period packet and independently certified finite Delta_0 nonzero.',
    'navigation': {'next_normal_global_review': 228, 'allowed_window': [226, 230],
                   'early_triggers': ['structural counterexample/cap', 'two completed rounds without a core interface advance'],
                   'next_task': 'Fixed packet recurrence, infinite nonzero and actual generic/conditional analytic gap before further optimization.'},
    'completed_math': ['Paid elementary beta-family staircase fails all s>=2 within the specified common-map class; not an optimal joint-lattice no-go.',
                       'Complete elementary zeta suspension is a fixed shear and gives no new full-source domain.',
                       'Highest-layer joint CRT model gives a finite short-rectangle saving; complete five-row injectivity range has no such overlap.',
                       'Actual three-period identities and full prime-power safe denominators.',
                       'Delta_0=11581683398946533579805/32768>0 by two exact finite algorithms; not infinite nonzero.'],
    'remaining_gates': ['infinite target nonzero', 'actual recurrence/cyclic rank', 'generic dominant singularity and strict relation overconvergence', 'same-source complete arithmetic/analytic strict comparison'],
    'execution_ledger': {'mathematical_program_runs': 2,
                         'scope': 'Root finite factor-convolution producer once; independent Bell/Fraction verifier once, only n=0,2,4.',
                         'CAS': 0, 'parameter_or_prime_scans': 0, 'PSLQ': 0, 'numerical_integrations': 0,
                         'old_proof_producer_reruns': 0, 'Lean_builds': 0, 'Git_mutations': 0, 'new_PDF_downloads': 0},
    'source_claim_policy': 'Primary selected sections/pages only, as scoped in source_reading_record and root_reading_scope. No full Catalan/Fauzan/Lean audit or exhaustive latest-theorem absence claim.',
    'independent_review': {'six_math_or_architecture_documents': 'PASS at final pinned identities',
                           'global_report': 'PASS at final pinned identity',
                           'finite_certificate': 'Two exact algorithms match; finite scope only'},
    'predecessor': {'manifest': identity(PREVIOUS), 'immutable_pins_checked': len(old_checked), 'mutable_main_excluded_from_old_final_hash': True},
    'main_append': {'preserved_prefix_bytes': len(prefix), 'preserved_prefix_sha256': sha256(prefix).hexdigest(),
                    'append_separator_hex': '0a0a', 'appended_report': identity(REPORT), 'final': identity(MAIN)},
    'verification': {'control_character_documents': len(new_mds), 'controls': 'PASS', 'local_links': links,
                     'links': 'PASS except the planned self-manifest link, checked immediately after creation'},
    'pins': sorted(pins.values(), key=lambda p: p['path']),
}
(ROOT / OUTPUT).write_text(json.dumps(record, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
for link in links:
    assert (ROOT / link['target']).is_file(), link
for item in record['pins']:
    require(item['path'], item['bytes'], item['sha256'])
require(PREVIOUS, 13444, 'c72ee3ec89a90ec9b3a851c89884dd99b0c600e52dfcaf5adaeaaea2e3cd1a86')
print(json.dumps({'manifest': identity(OUTPUT), 'main': identity(MAIN),
                  'pins': len(record['pins']), 'local_links': len(links), 'controls_md': len(new_mds),
                  'predecessor_immutable_pins': len(old_checked), 'checks': 'PASS'}, ensure_ascii=False))
