"""One-shot documentary archive; no mathematics, historical producer or Git."""
from pathlib import Path
import hashlib
import json
import re

root = Path(__file__).resolve().parent.parent
assert root == Path("E:/kimi-build/zeta5").resolve()
main = root / "research/cdt_odd_background_progress_20261006.md"
report = root / "research/research_fine_holonomy_gate_round235_20261008.md"
previous = root / "literature/manifest_rational_source_global_gate_round234_20261008.json"
dest = root / "literature/manifest_fine_holonomy_gate_round235_20261008.json"


def sha(data):
    return hashlib.sha256(data).hexdigest()


old_sha = "7a29e38b9df45590ea3eb0c849bfdc4e791e2bdd3d67f71bbc9aac20bcb14b75"
previous_sha = "f3ffe48922d09aaf61244fa7983dbf95743ed34711a97fd70a4c5076dfbf737a"
report_sha = "a00c7d5edcb1a450da827c3b2742f84b0c98d9c72b022b2ab1685a14e3ff4b94"
old, body = main.read_bytes(), report.read_bytes()
assert len(old) == 603690 and sha(old) == old_sha, "Main prefix changed"
assert previous.stat().st_size == 10874 and sha(previous.read_bytes()) == previous_sha
assert len(body) == 5405 and sha(body) == report_sha, "Final report changed"
assert not dest.exists(), "Do not rerun completed archive"

frozen = {
    "truncated_literal_integral_arithmetic_gate_round235_20261008.md":
        (8633, "2ff4e12e1965d03b49df9f2b201a955aa1b8449ea051b03580087b535c424d23"),
    "truncated_multimap_convexity_gate_round235_20261008.md":
        (8700, "1a9f112281c15d2319967d36e4b2eb2c7b517d02aead494ff15fccda03e2f335"),
    "holonomy_fine_multimap_and_period_candidate_round235_20261008.md":
        (9563, "eba6a74d5b06d29462aa4223fc614578008002a866f18209b795520d41411f46"),
}
for name, (size, digest) in frozen.items():
    data = (root / "research" / name).read_bytes()
    assert len(data) == size and sha(data) == digest, name

files = set(root.joinpath("research").glob("*round235*20261008.*"))
for folder in (
    "refined_arithmetic_gate_sources_round235_20261008",
    "refined_arithmetic_sources_round235_20261008",
    "truncated_multimap_sources_round235_20261008",
    "holonomy_interfaces_sources_round235_20261008",
):
    files.update(root.joinpath("literature", folder).glob("*"))
pins = []
for path in sorted(files):
    if not path.is_file():
        continue
    data = path.read_bytes()
    if path.suffix in {".md", ".py"}:
        content = data.decode("utf-8-sig")
        assert not any(ord(c) < 32 and c not in "\r\n\t" for c in content), path
    pin = {"path": path.relative_to(root).as_posix(), "bytes": len(data), "sha256": sha(data)}
    if path.suffix == ".txt":
        content = data.decode("utf-8-sig")
        codes = sorted({ord(c) for c in content if ord(c) < 32 and c not in "\r\n\t"})
        if codes:
            pin["original_pdf_text_control_counts"] = {str(c): content.count(chr(c)) for c in codes}
    pins.append(pin)

links = []
for target in re.findall(r"\]\(([^)]+)\)", body.decode("utf-8-sig")):
    if target.startswith(("http:", "https:", "#")):
        continue
    assert (report.parent / target.split("#", 1)[0]).resolve().is_file(), target
    links.append(target)

combined = old + b"\n\n" + body
manifest = {
    "round": 235, "date": "2026-10-08", "status": "progress",
    "previous_goal_turn_classification": "progress",
    "mathematical_program_runs": 0, "mathematical_program_failures": 0,
    "parameter_scans": 0, "new_pdf_downloads": 0, "git_mutations": 0, "lean_builds": 0,
    "documentary_archive_attempts": 1,
    "mathematical_status": "Fixed literal powers and arbitrary LCM matrices have sharp arithmetic floor 7/3; actual multimap, radial convexity, nonnegative optimal weights and binomial displayed formulas retain log c; fixed complete three-dimensional source's listed public entrances closed. Weight-four beta mixed period has exact connection value, actual rank-five source and rational descent; no numerical theorem",
    "closed_scope": "Fixed u and rational g, complete V, arbitrary fixed rational Taylor basis, fixed literal n^e, finite LCM matrix, current displayed Theorem6.0.2, 7.0.1, 7.1.6, 7.1.10, 7.1.13, 7.6.4 and 8.0.1 formulas under their actual conditions",
    "not_closed": "General unpublished/display-absent hybrid metrics, new Euclidean metric, extra finite-place inputs, scale-dependent source-level joint polynomial lattices, new coordinates or sources",
    "candidate": {
        "value": "beta(4)-pi^2 G/8 = -K4(2)/96",
        "paid": "Canonical-access connection value, actual rank 5, centered involution and complete Q[[q]] descent",
        "unpaid": "Relation-sensitive complete branch projection, full q-source joint integral lattice and strict arithmetic/analytic margin; no global novelty certification",
    },
    "global_review_cadence": {
        "last_formal": 232, "elapsed_rounds": 3, "next_formal": 236,
        "original_default": 238, "allowed_window": [236, 240],
        "reason_for_earlier_review": "Both bounded stronger interfaces closed; compare genuinely different source-level arithmetic and period geometry before further investment",
        "reset_by_this_round": False,
    },
    "next_interface": "Formal global review at236: compare source-level joint lattices, weight4 descended beta combination versus actual OpenAI Catalan source, and alternative geometric periods; choose by first unpaid core lemma and strict budget possibility, no automatic W/log-depth/type/metric scan",
    "verification_scope": "Only new235 identities and report links, preserved234 main prefix and predecessor; no old producer/archive or broad audit",
    "review_scope": "Root actual FULL final three math notes and scopes; B independently paid arithmetic, A independently FULL audited B and proved analytic formulas, Root independently rederived period connection/descent; C I2 switch corrected using physical68 image",
    "source_scope": "Reused local220-page CDT selected full pages and critical68 PNG; each agent scope preserved separately, no full-paper certification. Root had one truncated batch and explicitly reread complete123-125 pages",
    "repository_state": "C read local clean HEAD fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb and origin only; no fresh remote validation or mutation",
    "predecessor": {"path": previous.relative_to(root).as_posix(), "bytes": 10874, "sha256": previous_sha},
    "main_preserved_prefix": {"bytes": 603690, "sha256": old_sha},
    "appended_report": {"path": report.relative_to(root).as_posix(), "bytes": len(body), "sha256": report_sha},
    "main_after_append": {"path": main.relative_to(root).as_posix(), "bytes": len(combined), "sha256": sha(combined)},
    "report_links_checked": links, "new_pins": pins,
}
dest.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
main.write_bytes(combined)
assert main.read_bytes() == combined
print(json.dumps({
    "status": "PASS", "round": 235, "pins": len(pins), "report_links": len(links),
    "mathematical_runs": 0, "main_bytes": len(combined), "main_sha256": sha(combined),
    "manifest_bytes": dest.stat().st_size, "manifest_sha256": sha(dest.read_bytes()),
}, ensure_ascii=False))
