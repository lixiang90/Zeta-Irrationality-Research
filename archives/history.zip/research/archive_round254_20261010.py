"""One-shot documentary archive254. No mathematical computation."""
from pathlib import Path
import hashlib
import json

ROOT = Path(__file__).resolve().parents[1]
assert ROOT == Path(r"E:\kimi-build\zeta5").resolve()
MANIFEST = ROOT / "literature/manifest_rv_chi8_budget_round254_20261010.json"
assert not MANIFEST.exists(), "Completed254 archive must not be rerun"
PREVIOUS = ROOT / "literature/manifest_rv_chi8_round253_20261010.json"
MAIN = ROOT / "research/cdt_odd_background_progress_20261006.md"
POLICY = ROOT / "research/research_global_review_policy.md"
REPORT = ROOT / "research/research_rv_chi8_budget_progress_round254_20261010.md"
REVIEW = ROOT / "research/research_round254_rv_budget_review_20261010.md"
SOURCES = ROOT / "literature/rv_chi8_sources_round254_20261010"


def digest(data):
    return hashlib.sha256(data).hexdigest()


def pin(path):
    data = path.read_bytes()
    return {"path": path.relative_to(ROOT).as_posix(), "bytes": len(data), "sha256": digest(data)}


def verify(path, size, sha):
    data = path.read_bytes()
    assert len(data) == size and digest(data) == sha, str(path)
    return data


previous_data = verify(PREVIOUS, 14372, "1dea05d19858882c66c00e217b3cf7d9f6529a6758c14d52b6031dd77b7c7bb6")
previous = json.loads(previous_data)
assert previous["round"] == 253 and len(previous["files"]) == 49
assert previous["formal_global_review"]["last"] == 252
for item in previous["files"]:
    verify(ROOT / item["path"], item["bytes"], item["sha256"])
old_main = verify(MAIN, 729650, "71452f4beafaca25636578f9771e5732660dcc5ff5d17480b4f92aa58580249e")
old_policy = verify(POLICY, 23622, "9eaa369a964309831ffde190d7a1605aa4c4abb05641b72a714413c514114903")
report_data = verify(REPORT, 5575, "98d10951e7c51f353455989b516aa23ab8bab38eb7af8023fea4deea25c94961")
authors = [
    ("rv_chi8_mellin_uniform_gate_round254_20261010.md", 7789, "8a1787ba5e7e19ac877327d63fca62e565489d0949570b34c0e85628ebc219d1"),
    ("rv_chi8_primitive_budget_round254_20261010.md", 9256, "a21fc59352a6343befa23023adc695f5fdeecc978c5528aa57785007f3f61060"),
    ("rv_chi8_signed_error_round254_20261010.md", 8062, "d823df352a0c657262b7e14d409992cbff9f46cddbe80d238312fd33f7695a29"),
    ("rv_chi8_analytic_admission_round254_20261010.md", 8522, "1a9676cfb61d22d694f2f8b946861145f17ceb5117d7ec242c99e2ad5b05fadd"),
]
review_data = REVIEW.read_bytes()
review_text = review_data.decode("utf-8-sig")
assert "PASS" in review_text and "256" in review_text and "255" in review_text
for name, size, sha in authors:
    verify(ROOT / "research" / name, size, sha)
    assert sha in review_text
assert digest(report_data) in review_text
for name in ["root", "primitive", "error", "packet"]:
    assert (SOURCES / f"{name}_reading_scope.md").is_file()
assert "## 第254轮".encode("utf-8") not in old_policy
assert report_data not in old_main

policy_append = """

## 第254轮完整primitive预算及当前固定RV实现结算

同一253固定包、v=adj(first4 R modΦ8)e0、v4=0不变。B_n为(8n)!(5n)!/[(6n)!(7n)!]既约分子，B≥(4/3)^n且B|d8n；κ=2^floor(9n/4)为公共cyclotomic乘法adj向量exact content。β=κB³直接整除完整v,A,c，不把Q额外B免费放进A。除β后实际完整Gauss头p/q、δ′给q|Λ*=d13n+3 d12n+3，d=gcd(p,δ′)，g=β(Λ/q)d，primitive pair(p/d,qδ′/d)。真实最终费用为q/d，不重复计原Λ。

双Rodrigues/Euler伴随支付ordinary j=−n..4n−1与log j=0..2n−1，实际Q/U′至少5n内部变号。Mellin分子有7n首一整数零因子，剩余H degree≤3n+3；完整χ矩求和、13n转移和奇偶t2n尾核均不免费领signed非零。Root自含Chebyshev给uniform Cρ^−2n与真实V=(q/d)∫(−log)|U′|；同一当前粗安全upper合全部已付内容后自身仍增长。此增长只指upper证书，不是actual误差lower或所有RV方法no-go。

没有实际误差无界非零或primitive严格趋零，没有新的数值ζ/L定理，goal active。按253有界检验条件，结束当前fixed adj(R)e0/v4=0实现的默认投入，保留全部精确资产；κ/B收益与正交子引理不自动开prime/参数/第五列/其它向量/地图续窗。重入需要作用于完整误差的严格核心证据或明确完整新数值出口。

下一255作一次跨架构数值出口比较：单值Padé primitive误差与CDT/Catalan mixed周期增长行列式逐项比较真实周期、全整数模型、无界非零、全有限处成本和全实处能量，选择一个必须新增的定理及停止条件，不因改名重开Fricke/naive Gram/截断mixed。当前未宣告已完成这个比较或选定新目标。

last正式252，完成本轮后计数2，下一定期256；本轮不reset。连续两轮核心停滞提前复盘、最迟八轮不变。四数学稿、主报告、四scope与唯一独审后归档一次，253清单、48非policy文件和main/policy旧字节前缀保持。数学程序/有限头手算及程序证书/CAS/区间/Lean/prime/parameter/map/word扫描/外Git写/旧producer0；Root一web三query仅metadata，团队新PDF/HTML下载0。
""".encode("utf-8")

# Only documentary appends after all author/review/old-state preflight checks.
POLICY.write_bytes(old_policy + policy_append)
MAIN.write_bytes(old_main + b"\n\n" + report_data)
assert POLICY.read_bytes()[:len(old_policy)] == old_policy
assert MAIN.read_bytes()[:len(old_main)] == old_main
assert MAIN.read_bytes().count(report_data) == 1
for item in previous["files"]:
    if item["path"] != "research/research_global_review_policy.md":
        verify(ROOT / item["path"], item["bytes"], item["sha256"])
paths = {ROOT / item["path"] for item in previous["files"] if item["path"] != "research/research_global_review_policy.md"}
paths.update((ROOT / "research").glob("*round254*20261010*"))
paths.update(SOURCES.iterdir())
paths.add(POLICY)
manifest = {
    "round": 254,
    "date_completed": "2026-10-10",
    "classification": "progress",
    "previous_goal_turn_classification": "progress",
    "progress_kind": "Exact primitive pair and complete content; 5n Laurent orthogonality; integer Mellin compression; uniform complete analytic bound and default-realization stop",
    "goal_status": "active",
    "new_numerical_irrationality_or_independence_theorem": False,
    "global_novelty_or_full_lean_audit": False,
    "formal_global_review": {"last": 252, "this_round_is_formal": False, "counter_reset_this_round": False, "completed_rounds_since_last": 2, "next_scheduled": 256, "early_core_stagnation_rounds": 2, "maximum_interval": 8},
    "fixed_object": previous["fixed_object"],
    "paid_this_round": ["beta=2^floor(9n/4) B_n^3 directly divides complete v,A,c", "B_n is reduced factorial numerator; (4/3)^n<=B_n and B_n divides d8n", "Exact primitive pair p/d, q delta_prime/d and q divides Lambda_star", "5n Laurent and2n log moments; at least5n internal sign changes", "Integer Mellin factor G degree7n and H degree<=3n+3", "Uniform Chebyshev bound on same primitive complete error"],
    "strict_status": {"actual_numeric_nonzero_paid": False, "primitive_net_decay_paid": False, "current_safe_upper_certificate_admitted": False, "actual_error_lower_bound_or_optimal_nogo_claimed": False},
    "stopped_default_windows": previous["stopped_default_windows"] + ["Fixed conductor-eight RV adj(R)e0, v4=0 default implementation"],
    "next_unique_work": {"round": 255, "scope": "One cross-architecture numerical-outlet comparison: pure Pade primitive errors versus full mixed-period growth determinants", "must_match": ["Actual numerical period", "Complete integer model", "Unbounded actual nonzero", "Full finite-place cost", "Full real-place energy"], "automatic_parameter_or_source_extension": False, "new_target_selected_this_round": False},
    "runs": {"mathematics": 0, "finite_n_hand_heads_programs_or_certificates": 0, "cas_or_interval": 0, "prime_parameter_map_word_scans": 0, "lean": 0, "external_git_mutations": 0, "old_archive_producers": 0, "this_documentary_archive": 1},
    "sources": {"root_search_calls": 1, "root_search_queries": 3, "search_metadata_only": True, "new_pdf_downloads_by_team": 0, "new_html_downloads_by_team": 0, "new_adopted_primary_theorems": 0, "whole_paper_reading_claim": False, "precise_scope": "Four separately pinned reading scopes; published RV integer theorem reused; new chains self-contained"},
    "previous_manifest": pin(PREVIOUS),
    "previous_manifest_nonpolicy_files_preserved": 48,
    "report": pin(REPORT),
    "independent_math_and_report_review": pin(REVIEW),
    "previous_policy": {"bytes": len(old_policy), "sha256": digest(old_policy)},
    "new_policy": pin(POLICY),
    "previous_main": {"bytes": len(old_main), "sha256": digest(old_main)},
    "new_main": pin(MAIN),
    "files": [pin(path) for path in sorted(paths) if path.is_file()],
}
MANIFEST.write_text(json.dumps(manifest, ensure_ascii=False, indent=2)+"\n", encoding="utf-8")
assert PREVIOUS.read_bytes() == previous_data
assert REVIEW.read_bytes() == review_data
print(json.dumps({"status": "PASS", "numeric_theorem": False, "default_rv_implementation_stopped": True, "next_work": 255, "next_formal_review": 256, "completed_since_formal": 2, "files": len(manifest["files"]), "manifest": pin(MANIFEST), "main": pin(MAIN), "policy": pin(POLICY)}, ensure_ascii=False))
