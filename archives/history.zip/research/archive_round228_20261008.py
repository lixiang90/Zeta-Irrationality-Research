"""One-shot documentary archive; no mathematical computations or old producers."""
from pathlib import Path
import hashlib
import json
import re

ROOT = Path(__file__).resolve().parent.parent
MAIN = ROOT / "research/cdt_odd_background_progress_20261006.md"
REPORT = ROOT / "research/research_global_review_round228_20261008.md"
DEST = ROOT / "literature/manifest_global_review_round228_20261008.json"
PREV = ROOT / "literature/manifest_cdt_pade_route_stop_round227_20261008.json"
OLD_BYTES = 556456
OLD_SHA = "37d10ee3a9071bdfa773e0e395c7dd3b0aefba46b1c168dd53bf1b13685ec465"
PREV_SHA = "e0014cff49b1de8b8e287f73ebe2f1693d1dc214d1850a7ab522e4a0fdaf35b9"
REPORT_SHA = "adeead1004c11db2a5189b9bcebe4e33092e643c45859a08f31651a8610c352d"

def sha(data):
    return hashlib.sha256(data).hexdigest()

old = MAIN.read_bytes()
report = REPORT.read_bytes()
assert len(old) == OLD_BYTES and sha(old) == OLD_SHA, "Main prefix changed"
assert sha(PREV.read_bytes()) == PREV_SHA, "Previous manifest changed"
assert sha(report) == REPORT_SHA, "Reviewed report changed"
assert not DEST.exists(), "Archive already exists; do not rerun"

files = sorted({
    *ROOT.joinpath("research").glob("*round228*20261008.*"),
    *ROOT.joinpath("literature/global_review_sources_round228_20261008").glob("*"),
})
pins = []
for path in files:
    if not path.is_file():
        continue
    data = path.read_bytes()
    if path.suffix == ".md":
        body = data.decode("utf-8-sig")
        assert not any(ord(c) < 32 and c not in "\r\n\t" for c in body), path
    pins.append({"path": path.relative_to(ROOT).as_posix(),
                 "bytes": len(data), "sha256": sha(data)})

body = report.decode("utf-8-sig")
local_links = []
for target in re.findall(r"\]\(([^)]+)\)", body):
    if target.startswith(("http:", "https:", "#")):
        continue
    resolved = (REPORT.parent / target.split("#", 1)[0]).resolve()
    assert resolved.is_file(), f"Missing report link: {target}"
    local_links.append(target)

new_main = old + b"\n\n" + report
manifest = {
    "round": 228,
    "date": "2026-10-08",
    "formal_global_review": {"previous": 222, "current": 228,
                             "next_default": 234, "next_window": [232, 236]},
    "mathematical_program_runs": 0,
    "mathematical_status": "New paper-proved structural caps; no new numerical theorem",
    "repository": {"path": "E:/codex-build/math",
                   "head": "fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb",
                   "working_tree_clean_after_update": True,
                   "fetch_exit_code": 0, "fast_forward_exit_code": 0,
                   "lean_builds": 0},
    "verification_scope": "Only new files, reviewed report links, predecessor identity and main prefix. No re-verification of 227 historical pins or old mathematical producers.",
    "predecessor": {"path": PREV.relative_to(ROOT).as_posix(),
                    "bytes": PREV.stat().st_size, "sha256": PREV_SHA},
    "main_preserved_prefix": {"bytes": OLD_BYTES, "sha256": OLD_SHA},
    "main_after_append": {"path": MAIN.relative_to(ROOT).as_posix(),
                          "bytes": len(new_main), "sha256": sha(new_main)},
    "appended_report": {"path": REPORT.relative_to(ROOT).as_posix(),
                        "bytes": len(report), "sha256": REPORT_SHA},
    "next_task": "Fixed finite q2 full-pool C_G kernel and restricted C_Theta rank; not ordinary chi-minus8 Gram content optimization",
    "report_local_links_checked": local_links,
    "new_pins": pins,
}

DEST.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
MAIN.write_bytes(new_main)
assert MAIN.read_bytes() == new_main
print(json.dumps({"status": "PASS", "round": 228, "new_pins": len(pins),
                  "report_links": len(local_links), "mathematical_runs": 0,
                  "main_bytes": len(new_main), "main_sha256": sha(new_main),
                  "manifest_bytes": DEST.stat().st_size,
                  "manifest_sha256": sha(DEST.read_bytes())}, ensure_ascii=False))
