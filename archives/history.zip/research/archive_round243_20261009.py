"""One-shot documentary archive, no mathematics or historical producer rerun."""
from pathlib import Path
import hashlib
import json

root=Path(__file__).resolve().parent.parent
assert root==Path('E:/kimi-build/zeta5').resolve()
main=root/'research/cdt_odd_background_progress_20261006.md'
report=root/'research/research_logistic_residual_progress_round243_20261009.md'
carrier=root/'research/logistic_residual_target_carrier_round243_20261009.md'
budget=root/'research/logistic_residual_budget_round243_20261009.md'
previous=root/'literature/manifest_logistic_gauss_budget_round242_20261009.json'
sources=root/'literature/logistic_residual_filter_sources_round243_20261009'
destination=root/'literature/manifest_logistic_residual_filter_round243_20261009.json'

def sha(data): return hashlib.sha256(data).hexdigest()
def pin(path):
    data=path.read_bytes()
    return {'path':path.relative_to(root).as_posix(),'bytes':len(data),'sha256':sha(data)}

assert not destination.exists(), 'Never rerun a completed documentary producer'
old=main.read_bytes()
assert len(old)==659090 and sha(old)=='34250b248883040071c78300917eeda339a63b169ea0dc7fa5c32caca07b3c67'
assert sha(previous.read_bytes())=='f7d6192aaa76137d14647d969cf90bce0878b36ab809b4b1ba28f64663b7c374'
assert pin(report)['sha256']=='54a6e0e105fb0e41a73237e07685428eafc76b6041729cccacbbc1e5fcc4d098'
assert pin(carrier)['sha256']=='cc75d1413edac02ca75f117cd983db1125e88fc4d78e1fc3b84ea66ef7fdbecb'
assert pin(budget)['sha256']=='4a956a585a8a3663fd74855f85efcec011ba169888c95b8d6b057a193c6da4e3'
assert pin(root/'research/research_round243_target_carrier_review_20261009.md')['sha256']=='858db0c127a5eb6c92a795ca17283117f3f0afacb0b532297d123d2f328f5f97'
assert pin(root/'research/research_round243_target_carrier_dual_review_20261009.md')['sha256']=='1daf7c304fca0e7cf3cc5e4fc56a04fa6849cb999087adaa082f7406a60c203c'
assert pin(root/'research/logistic_filtered_residual_round243_20261009.md')['sha256']=='e74b0ea9841ad09de08b7b039da6c627609d52a2778c4f069e941169536de84c'
reviews={
    'research/research_round243_target_carrier_review_20261009.md':carrier,
    'research/research_round243_residual_budget_review_20261009.md':budget,
    'research/research_round243_progress_review_20261009.md':report,
}
for path,target in reviews.items():
    text=(root/path).read_text(encoding='utf-8-sig')
    assert 'PASS' in text and pin(target)['sha256'] in text,path
assert (root/'research/logistic_filtered_residual_round243_20261009.md').is_file()
records=set((root/'research').glob('*round243*20261009.*'))
records.update(p for p in sources.rglob('*') if p.is_file())
records.add(root/'research/research_global_review_policy.md')
pins=[pin(p) for p in sorted(records)]
body=report.read_bytes()
combined=old+b'\n\n'+body
manifest={
    'round':243,'date':'2026-10-09','classification':'progress',
    'previous_goal_turn_classification':'progress','goal_status':'active',
    'new_numerical_irrationality_or_independence_theorem':False,
    'formal_global_review':{'last':240,'next_scheduled':244,'counter_reset_this_round':False},
    'bounded_main_window':[241,244],
    'object':{'target':'3 zeta(3) + zeta(5)','kernel':'D_n^4/D_(5n)',
              'matrix_size':'3n','normalization':'S_n^(3n)Q_n/F_n'},
    'paid':[
        'Unique Bernoulli denominator at degree 2p-1; s=2 whole remainder has exact first-layer rank tau+1.',
        'Every k-minor of the full remainder has coefficient valuation at least k+(k-tau-1)_+.',
        'Whole double-minor expansion with all zero slots gives extra (3p-7n-2)_+, leading saving 1/24.',
        'Exact integer greedy on 2n<p<3n is worse than the existing complete class bound.',
        'Whole-prime net upper becomes 1511/60, inheriting all prime powers and unbounded nonzero scales.',
        'Raw s=1 target coefficient rank h-1 by a coprime rational carrier and perfect quotient pairing.',
        'Actual high-head annihilator restriction has target coefficient rank 2p-5n-1, including degree-zero boundary.',
        'Filtered first-layer Schur structure independently documented, without assuming higher-layer content.',
        'Independent full paper reviews of target carrier, budget and final progress report.',
    ],
    'not_paid':[
        'Strict whole-prime rate below 6 and full independent original -6 analytic certification.',
        'Complete constant/Schur content on the remaining filtered s=1 space or optimal whole-source content.',
        'A new numerical irrationality or linear-independence theorem.',
        'Lean kernel certification, full repository/import audit, remote freshness or global novelty.',
    ],
    'arithmetic_upper':{'whole':'1511/60','improvement':'1/24',
                        'new_window_2_to_3':'79/12',
                        'selected_certificate_interface':'B_new < 5/8 - I_in',
                        'selected_certificate_minimum_required_saving':'42/5',
                        'this_interface_is_actual_fee_lower':False},
    'next_gate':'Round244 formal global review: compare paid interfaces, full numerical thresholds and certificate costs; prioritize redirect check, no automatic continuation of local prime/parameter optimization.',
    'runs':{'mathematics':0,'cas_or_interval':0,'prime_or_parameter_scans':0,
            'lean':0,'git_mutations':0,'new_primary_search_or_download':0,
            'old_archive_producers':0,'this_documentary_archive':1},
    'previous_manifest':pin(previous),'report':pin(report),'carrier':pin(carrier),'budget':pin(budget),
    'previous_main':{'bytes':len(old),'sha256':sha(old)},
    'new_main':{'path':main.relative_to(root).as_posix(),'bytes':len(combined),'sha256':sha(combined)},
    'files':pins,
}
main.write_bytes(combined)
destination.write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
assert main.read_bytes()[:len(old)]==old
assert main.read_bytes()[len(old):]==b'\n\n'+body
for record in pins: assert pin(root/record['path'])==record
print(json.dumps({'status':'PASS','manifest':pin(destination),'main':pin(main),
                  'pinned_files':len(pins)},ensure_ascii=False))
