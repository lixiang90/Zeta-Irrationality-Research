"""One-shot documentary round-225 freeze; imports/runs no mathematical producer."""
from pathlib import Path
from hashlib import sha256
import json
import re

ROOT = Path(__file__).resolve().parents[1]
MAIN = 'research/cdt_odd_background_progress_20261006.md'
REPORT = 'research/research_pade_actual_modes_round225_20261008.md'
PREVIOUS = 'literature/manifest_cdt_pade_nonvanishing_round224_20261008.json'
OUTPUT = 'literature/manifest_cdt_pade_actual_modes_round225_20261008.json'
REVIEW = 'research/research_round225_report_review_20261008.md'
REVIEW_BYTES = 9593  # Root actual FULL read of the final independent receipt.
REVIEW_SHA = '227024773e10f581b7a95d6365cef1ba1e9176ce6639ba654465c262944825f6'
SOURCE_DIRS = [
    'literature/pade_actual_modes_sources_round225_20261008',
    'literature/pade_asymptotic_sources_round225_20261008',
    'literature/pade_relation_rank_sources_round225_20261008',
    'literature/pade_singular_bridge_sources_round225_20261008',
]


def identity(relative):
    data = (ROOT / relative).read_bytes()
    return {'path': relative, 'bytes': len(data), 'sha256': sha256(data).hexdigest()}


def require(relative, length, digest):
    item = identity(relative)
    assert (item['bytes'], item['sha256']) == (length, digest), item
    return item


assert not (ROOT / OUTPUT).exists(), 'Completed archive must not be rerun.'
assert REVIEW_BYTES is not None and REVIEW_SHA is not None, 'Final FULL report review required.'
require(PREVIOUS, 41713, '109298f47c6eab0be7068a213884e7a4a0f594cdb00d36da02d502e7098d0fac')
previous = json.loads((ROOT / PREVIOUS).read_text(encoding='utf-8'))
old_checked = [require(p['path'], p['bytes'], p['sha256'])
               for p in previous['pins'] if p['path'] != MAIN]
assert len(old_checked) == 140
prefix = (ROOT / MAIN).read_bytes()
assert len(prefix) == 533197
assert sha256(prefix).hexdigest() == '490c4d03d50af356dac351e311b84ff90c6ed1c3b7ded3d0db2173962fa05fa8'

expected = '''
research/pade_actual_fourier_modes_round225_20261008.md 11160 37d2a980146055a4b3509d7861f77d674bec6fca40cb55e5ec138aeaccc81788
research/pade_actual_leading_symbol_round225_20261008.md 13928 ee1d70e843e53090cefc84dd750452e2ee6c954ae79bf674d0ea9f25ffede798
research/pade_relation_power_rank_gate_round225_20261008.md 14444 7752b5bfeb3b2090d913b999600695c5a12ffc1c731dd36649d4d89104b5b255
research/pade_actual_branch_graph_bridge_round225_20261008.md 6523 5001f4693f14768d3a9ebc39f71934aaeb64aaac733225b7201911864c60be6a
research/pade_relation_radial_cap_round225_20261008.md 5015 8d46532cde29b6133687e926e4af02f82e1cf3a7dfbb9f9eaf26a45ff9835afa
research/certify_pade_leading_symbol_round225_20261008.py 5136 51822e871272b0aee875042c73aa53be06792a1085bed5d4a97bf525846bdffa
research/pade_leading_symbol_certificate_round225_20261008.json 5526 87e412c2184de9c424831dd20e16e0b0b0f4160946a0c63cc69db49331b6f304
research/pade_leading_symbol_first_run_failure_round225_20261008.txt 700 ec02cd37b1e751c159e36405cd6602d8e7ae42db3b8518b5d59cb1cde14a27cf
research/research_round225_actual_modes_review_20261008.md 3437 2d9fe448e12eeff306dbd7a249c3d35ae750a69f6675fc119d091c79bfe80d35
research/research_round225_branch_graph_review_20261008.md 4431 c2fc570b5c9bc0d4d95ea891c739677f51d027cc440deb578fbfa7adc796403c
research/research_round225_leading_symbol_review_20261008.md 7373 dd2d77655ae5202f2562c9a50f4e0ea4d8e628e4879b6a19181d149ff88ebacb
research/research_round225_relation_power_root_review_20261008.md 3122 b67f34fce374e5649c3d87300ff73a601f829b61ec344b30cd783b79109ec115
research/research_round225_stable_modes_review_20261008.md 5302 52b5e26a92b48ea78275d4176df95def55fc02596e54e5d37af9165d50537ec4
research/research_round225_relation_radial_cap_review_20261008.md 3860 604db7ddb4b479e75028af0419e20645625e854aec2da14b44b8aa7bc390194d
research/research_pade_actual_modes_round225_20261008.md 9050 9daacd63563f862e2459fee9146b9a31152a4f55e397e3f119d1ca47021ed7af
literature/pade_actual_modes_sources_round225_20261008/root_reading_scope.md 7437 e648ca01f4c3d3a699dcaead5c3f1be05c8dc88ccce397eac6af33a3cb090d89
literature/pade_actual_modes_sources_round225_20261008/dual_reading_scope.md 3038 2ae339ba537a254c7aee104a182b41540fa1ffdcb2da1a610f71e5d2b879924f
literature/pade_actual_modes_sources_round225_20261008/dual_dlmf_5_11.html 212098 a89274abb01789070d9a97ce30c1e7f9d608523f0a2d3cf851c28e090a0ab1c3
literature/pade_asymptotic_sources_round225_20261008/lambert_reading_scope.md 2696 4d74ba70edbfad73aea3e28b8d08ba59b1c7645c456986295bcac42648b8425a
literature/pade_relation_rank_sources_round225_20261008/packet_reading_scope.md 5116 a6eb373027024c39bcf5fa20809cbefdb1acbe1c95ade509889b7453f5c0b28c
literature/pade_singular_bridge_sources_round225_20261008/root_cdt_fixed_v2_theorems2_5_1_2_7_1_remark2_11_1.txt 10820 f0dd7f1b8dccd640392dfe1c8a0dfc86e8c735d8bfa201ff515b521fa7cc201b
'''
pins = {p['path']: p for p in old_checked}
pins[PREVIOUS] = identity(PREVIOUS)
new_paths = []
for line in expected.splitlines():
    if line.strip():
        relative, length, digest = line.split()
        pins[relative] = require(relative, int(length), digest)
        new_paths.append(relative)
pins[REVIEW] = require(REVIEW, REVIEW_BYTES, REVIEW_SHA)
new_paths.append(REVIEW)
for relative in [
    'research/research_round225_stable_modes_review_20261008.md',
    'research/research_round225_relation_radial_cap_review_20261008.md',
    'literature/pade_actual_modes_sources_round225_20261008/root_reading_scope.md',
]:
    assert (ROOT / relative).is_file(), relative
    pins[relative] = identity(relative)
    new_paths.append(relative)
for directory in SOURCE_DIRS:
    for file in sorted((ROOT / directory).rglob('*')):
        if file.is_file():
            relative = file.relative_to(ROOT).as_posix()
            pins[relative] = identity(relative)
            new_paths.append(relative)
new_paths = sorted(set(new_paths))
assert not any(p.endswith('.pdf') for p in new_paths)
assert len([p for p in new_paths if p.endswith('.html')]) == 1
assert not any(p.endswith('.tex') for p in new_paths)

# Cached primary identities used by A/B this round; these are not new downloads.
for relative, length, digest in [
    ('literature/apery1979_asterisque.pdf', 217525, '12781716e9c7744bc632e9c2afdf985bf8a7ca776cccc34638e17e35a0c70384'),
    ('literature/cdt2025_arithmetic_holonomy.pdf', 751610, '5f403f337fed8bfd776348a04aaaec7d57ca6f90c31dd871ed793bf24239c8f1'),
]:
    pins[relative] = require(relative, length, digest)
cached_image = 'literature/cdt_period_extension_sources_20261007/apery1979_page4_root_review.png'
pins[cached_image] = identity(cached_image)

links = []
new_mds = [p for p in new_paths if p.endswith('.md')]
for relative in new_mds:
    content = (ROOT / relative).read_text(encoding='utf-8')
    assert not any(ord(c) < 32 and c not in '\n\r\t' or ord(c) == 127 for c in content), relative
    for target in re.findall(r'\[[^\]\n]*\]\(([^)\n]+)\)', content):
        target = target.strip().strip('<>').split('#', 1)[0]
        if re.match(r'^(?:https?://|app://)', target):
            continue
        if Path(target).suffix.lower() not in {'.md', '.pdf', '.json', '.txt', '.py', '.png', '.tex'}:
            continue
        resolved = ((ROOT / relative).parent / target).resolve()
        assert resolved.is_relative_to(ROOT), (relative, target)
        link_path = resolved.relative_to(ROOT).as_posix()
        assert resolved.is_file() or link_path == OUTPUT, (relative, target)
        links.append({'source': relative, 'target': link_path})
        if resolved.is_file() and link_path not in pins and link_path != MAIN:
            pins[link_path] = identity(link_path)

report = (ROOT / REPORT).read_bytes()
main_final = prefix + b'\n\n' + report
(ROOT / MAIN).write_bytes(main_final)
assert (ROOT / MAIN).read_bytes() == main_final
pins[MAIN] = identity(MAIN)
script = Path(__file__).relative_to(ROOT).as_posix()
pins[script] = identity(script)
record = {
    'round': 225, 'date': '2026-10-08', 'goal_status': 'active',
    'new_numerical_theorem': False,
    'round_outcome': 'Actual dominant Fourier connections and exact generic radius; actual leading recurrence and full six-mode basis; I/J infinite nonzero, J nonrational, conditional original Q(z)-rank3; generic and target radial nonmeromorphic branches exclude their raw univalent CDT entrances.',
    'navigation': {
        'last_formal_global_review': 222,
        'next_normal_global_review': 228, 'allowed_window': [226, 230],
        'default_review_interval_completed_rounds': 6,
        'early_triggers': ['structural counterexample/cap', 'two completed rounds without a core interface advance'],
        'this_round_has_core_interface_advance': True,
        'this_round_has_early_source_direction_check': True,
        'early_check_is_not_claimed_as_comprehensive_global_literature_review': True,
        'next_task': 'First certify a changed legal analytic entrance with paid all-place normalization/descent or actual ramified common map/energy. Raw univalent D and target H both fail even at zero arithmetic cost. Minimal differential closure alone does not evade this cap.',
        'stop_rule': 'In the next two completed rounds, pay at least one legal analytic entrance interface or a definitive cap and downgrade the fixed source. If only formal factors/safe estimates appear, park it and compare other sources/targets at the global review. Do not restart prime/parameter scans or optimize the safe166/9 array before a legal entrance.'
    },
    'completed_math': [
        'Actual B1/B3/B5=(-1)^r*c_j*r^(-11/2)*L_j^r*(1+O(1/r)); c_j>0. Full contour, sector, global maximum and far tails paid.',
        'Actual Delta=(-1)^r*d*r^(-33/2)*(L1*L2*L3)^r*(1+O(1/r)); exact generic radius1/(L1*L2*L3); two-nuisance wedge eventually nonzero.',
        'h-regular bridge to degree6 quotient pays actual leading characteristic polynomial and all seven coefficient degree differences=-30. Weighted Volterra improves actual I root upper to kappa.',
        'Harmonic telescoping and rational Galois transfer pay gamma=-11/2 for all six roots; mixed past/future Green contraction constructs full actual basis including equal-modulus complex pair.',
        'I/J infinitely nonzero; J exact root T=L1*L2*q with q in{kappa,s}; J/T^r tends0 and its generating function is nonrational.',
        'Under zeta7=g rational, original span{1,D,X}=span{1,D,Hg} has Q(z)-dimension3; not minimal differential rank3.',
        'Exact relative log radius gain belongs to{(9/2)log(3*alpha),9log(3+2*sqrt3)}; max<18<safe166/9. Not a common-map derivative or optimal cost bound.',
        'Generic and target have nonmeromorphic original radial branches. Koebe quarter with full contained disk gives raw univalent derivative bounds4/(L1*L2*L3) and4/T, both<1. All-path or all-map no-go is not claimed.'
    ],
    'remaining_gates': [
        'legal normalized/ramified same-source analytic entrance and actual energy',
        'complete all-place integral model after any normalization/descent',
        'minimal differential/cyclic source and applicable arithmetic holonomy rank',
        'complete strict arithmetic/analytic comparison',
        'new numerical irrationality/linear-independence theorem'
    ],
    'execution_ledger': {
        'mathematical_program_runs': 2, 'failed_mathematical_runs': 1, 'successful_mathematical_runs': 1,
        'fixed_quotient_algebra_runs': 2, 'actual_sequence_samples': 0,
        'Root_B_C_mathematical_runs': 0, 'CAS': 0, 'recurrence_guessing': 0,
        'parameter_or_prime_scans': 0, 'PSLQ': 0, 'numerical_integrations': 0,
        'old_proof_producer_reruns': 0, 'Lean_builds': 0, 'Git_mutations': 0,
        'new_repository_status_check': False,
        'new_PDF_downloads': 0, 'new_DLMF_HTML_archives': 1, 'new_DLMF_short_TEX': 0,
        'new_primary_selected_TXT': 1,
        'documentary_operations': 'Primary selected reading, cached PDFs, formula HTML, FULL mathematical drafts/receipts, metadata/control/link checks and this one-shot append/archive. No mathematical producer is imported/executed by archive.'
    },
    'source_claim_policy': 'Root actual complete selected CDT fixed theorems/Koebe passage and DLMF used formula/sector/remainder conditions; C selected DLMF5.11, HTML archive not FULL chapter; B cached Apery four pages and CDT2025 pages2-5; A/C selected DLMF2.9 not used as arbitrary-order theorem. No fresh cloud/Lean verification claim.',
    'independent_review': {
        'actual_Fourier_modes': 'Root FULL independent paper PASS',
        'actual_leading_symbol_and_stable_upper': 'C FULL independent paper PASS at final terminology-corrected identity',
        'six_modes_and_nonrational_field_rank': 'A FULL independent PASS plus Root FULL independent paper PASS',
        'generic_radial_graph_cap': 'C FULL independent PASS',
        'target_radial_graph_cap': 'B FULL independent PASS after self-contained bounded Abelian remainder added',
        'report_and_root_scope': 'C FULL independent PASS at final pinned identities'
    },
    'predecessor': {'manifest': identity(PREVIOUS), 'immutable_pins_checked': len(old_checked),
                    'mutable_main_excluded_from_old_final_hash': True},
    'main_append': {'preserved_prefix_bytes': len(prefix), 'preserved_prefix_sha256': sha256(prefix).hexdigest(),
                    'append_separator_hex': '0a0a', 'appended_report': identity(REPORT), 'final': identity(MAIN)},
    'verification': {'control_character_documents': len(new_mds), 'controls': 'PASS',
                     'local_links': links, 'links': 'PASS including planned manifest checked after creation'},
    'pins': sorted(pins.values(), key=lambda p: p['path'])
}
(ROOT / OUTPUT).write_text(json.dumps(record, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
for link in links:
    assert (ROOT / link['target']).is_file(), link
for item in record['pins']:
    require(item['path'], item['bytes'], item['sha256'])
require(PREVIOUS, 41713, '109298f47c6eab0be7068a213884e7a4a0f594cdb00d36da02d502e7098d0fac')
print(json.dumps({'manifest': identity(OUTPUT), 'main': identity(MAIN), 'pins': len(record['pins']),
                  'local_links': len(links), 'controls_md': len(new_mds),
                  'predecessor_immutable_pins': len(old_checked), 'checks': 'PASS'}, ensure_ascii=False))
