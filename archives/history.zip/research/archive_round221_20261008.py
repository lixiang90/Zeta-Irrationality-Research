"""Documentary byte/hash/link checks and exact append for round 221; no mathematics."""
from pathlib import Path
import hashlib
import json
import re

ROOT = Path(__file__).resolve().parent.parent
assert ROOT == Path('E:/kimi-build/zeta5')
sha = lambda raw: hashlib.sha256(raw).hexdigest()

def identity(relative):
    raw = (ROOT / relative).read_bytes()
    return {'path': relative, 'bytes': len(raw), 'sha256': sha(raw)}

expected = {
    'research/cyclotomic_relation_differential_projection_round221_20261008.md': (5368, '9586adb394cf371588e204077eda32ddc129e4066a85711fc44f0522ab80c03f'),
    'research/cyclotomic_symmetry_analytic_round221_20261008.md': (16171, 'ba26cab8550aafc5ea1cf177c50a1f302e415e2cb9b1265305592d17dee55aa0'),
    'research/cyclotomic_symmetry_arithmetic_round221_20261008.md': (13880, 'ec00ff4c6dd4d76b61d1093234e0525a4d164ffdc66d34ac37c4fcda1e56c28e'),
    'research/cdt_actual_trace_transfer_round221_20261008.md': (13182, '7f267e3c856313435b59a4bcb02d0fd655336c2377d995a851aa058a6642be92'),
    'research/cyclotomic_quotient_global_map_obstruction_round221_20261008.md': (7527, '41916916956130d288497d90793d3cdbd5648dfa6fe750e2f5999bddb368783d'),
    'research/research_round221_differential_projection_review_20261008.md': (2482, 'c6592efd86c09edf340a87ba4344d88674754462e295177c647bb7cdebc06720'),
    'research/research_round221_symmetry_analytic_review_20261008.md': (3626, '56c0322d1879a3c7e43a7ce3335b659fda4ece6adc24c06cb7fc3395216b07e0'),
    'research/research_round221_symmetry_arithmetic_review_20261008.md': (6613, '0196d5b45849b300ae585e94d1856cfbeed5302e7a5fd1936967857723fe46d4'),
    'research/research_round221_actual_trace_review_20261008.md': (4056, '131a3e0b54b849c962fb4d6908ac022c7647777de53e98adf19c10e39f6a76e1'),
    'research/research_round221_global_map_obstruction_review_20261008.md': (5477, '7583f3bb6483d22ca6a5c6a3d0693207d7072cd57a53b7e10fbd37b46f77790f'),
    'research/cdt_cyclotomic_symmetry_gate_round221_20261008.md': (6873, '3be37acfd427ad802d85f5399b992708712aaaa5811edb6888d61e498ecee7db'),
    'literature/trace_sources_round221_20261008/reading_scope.md': (2263, '0a41d22f59823f4de64791112e95595b4a01975f887a87b241c4ae3e1f69698e'),
    'literature/trace_sources_round221_20261008/global_reading_scope.md': (3297, '7f6ec463727915f2ffb0b012284fdf9262b712cd7e3d62dc28e1c95243bbce8d'),
    'literature/manifest_cdt_global_relation_gate_round220_20261008.json': (24657, '37e3835903dd1953289be725040c015173ca75d2c746949a3bdb25a5982793b3'),
}
for relative, (size, digest) in expected.items():
    found = identity(relative)
    assert (found['bytes'], found['sha256']) == (size, digest), found

review_path = 'research/research_round221_report_review_20261008.md'
review = (ROOT / review_path).read_text(encoding='utf-8')
assert 'PASS' in review and expected['research/cdt_cyclotomic_symmetry_gate_round221_20261008.md'][1] in review

previous_path = 'literature/manifest_cdt_global_relation_gate_round220_20261008.json'
previous = json.loads((ROOT / previous_path).read_text(encoding='utf-8'))
main_path = 'research/cdt_odd_background_progress_20261006.md'
old_checked = 0
for pin in previous['pins']:
    if pin['path'] == main_path:
        continue
    assert identity(pin['path']) == pin, pin['path']
    old_checked += 1

new_paths = list(expected)[:13] + [review_path]
source_paths = sorted(p.relative_to(ROOT).as_posix() for p in (ROOT / 'literature/trace_sources_round221_20261008').glob('*.txt'))
old_paths = [previous_path, 'research/research_global_review_round220_20261008.md',
             'research/cross_target_strategy_global_round220_20261008.md',
             'research/cdt_new_repository_carriers_20261007.md',
             'research/research_navigation_protocol.md', 'literature/cdt2024_l2_chi_minus3.pdf']
manifest_path = 'literature/manifest_cdt_cyclotomic_symmetry_round221_20261008.json'
assert not (ROOT / manifest_path).exists(), 'Do not replace an existing round manifest.'
links = []
non_file_brackets = 0
for relative in new_paths:
    raw = (ROOT / relative).read_bytes()
    text = raw.decode('utf-8')
    assert not [c for c in text if ord(c) < 32 and c not in '\t\r\n'], relative
    for target in re.findall(r'\[[^\]\n]*\]\(([^)\n]+)\)', text):
        target = target.strip('<>')
        if re.match(r'^[a-zA-Z][\w+.-]*:', target) or target.startswith('#'):
            continue
        target = target.split('#', 1)[0]
        if not re.search(r'\.(?:md|pdf|json|txt|py)$', target, re.IGNORECASE):
            non_file_brackets += 1
            continue
        resolved = ((ROOT / relative).parent / target).resolve()
        assert resolved.is_relative_to(ROOT), (relative, target)
        assert resolved.exists() or resolved == ROOT / manifest_path, (relative, target)
        links.append({'source': relative, 'target': target})

report_path = 'research/cdt_cyclotomic_symmetry_gate_round221_20261008.md'
report = (ROOT / report_path).read_bytes()
before = (ROOT / main_path).read_bytes()
prefix_size = 500157
prefix_digest = 'a40b9d01abca62d13057773a92f09ed56cf8d94e2cc3de434d9150b7bdb603ae'
assert len(before) == prefix_size and sha(before) == prefix_digest
after = before + b'\n\n' + report
(ROOT / main_path).write_bytes(after)
saved = (ROOT / main_path).read_bytes()
assert saved[:prefix_size] == before and saved[prefix_size:] == b'\n\n' + report

pin_paths = list(dict.fromkeys(new_paths + source_paths + old_paths + [main_path, 'research/archive_round221_20261008.py']))
manifest = {
    'round': 221, 'date': '2026-10-08', 'goal_status': 'active', 'new_numerical_theorem': False,
    'round_outcome': 'Progress: all-prime-power odd outer-index lemma and genuine7/96 original-x cost reduction; actual parity ranks; all actual common quotient maps have log derivative<7/2; paid full types fail positive cost; ordinary-J subset obstruction. No numerical theorem.',
    'navigation': {'default_completed_rounds_between_reviews': 6, 'allowed_window': [4, 8],
                   'last_completed_global_review': 220, 'regular_next_review': 226,
                   'regular_window': [224, 228], 'early_next_review': 222,
                   'early_trigger': 'Proved quantitative cap for all actual common maps of the current source.',
                   'stopped_work': 'Further ordinary parity/map/prime/parameter tuning on this source.',
                   'next_direction': 'Global comparison of genuinely new relation-induced sources, proved joint integral-model gains, and novelty/status checks for zeta/L numerical targets before local work.'},
    'completed_math': {
        'odd_denominator_lemma': 'For positive odd M and positive odd k<M: M*k^2 divides q_M^2*q_floor(M/3), all odd prime powers covered; fixed g and dyadic constants paid.',
        'paid_cost_gain': 'Original x rank4 odd source tau11/6 versus61/32: improvement7/96. Squared t type11/3; coordinate log derivative, J and fees double together.',
        'prefix_denominators': 'Even log Den=5N+o(N), odd14N/3+o(N); finite p|6c_g excluded in lower arguments. These are row denominators, not optimal joint-lattice costs.',
        'actual_ranks': 'Each parity rank4, combined rank5; reflected pi obstruction paid; compensated Q source loses G-condition.',
        'all_map_cap': 'Actual a,b quotient pullbacks force no -1 or interior poles; log(1+psi) omits odd deck points including +/-2pi*i. Therefore logabs(psi_prime(0))<7/2. Actual e/o restore a,b analytically, without adding free Taylor rows.',
        'full_type_failure': 'Paid odd11/3, even61/16 and full5 arbitrary-array lower18/5 all exceed7/2; no allowed common map meets their positive-cost gate.',
        'subset_scope': 'For disk-holomorphic psi meromorphic near the closed disk, ordinary J>=log derivative. The paid rank3(1,a,o) needs derivative log>44/9. Other refined CDT numerators are not excluded.',
        'projection_scope': 'Together with full background(1,A,B), rational differential projection either retains rank4 via nonzero c0 or kills numerical monodromy via c0=0; no claim for independently rebuilt reduced backgrounds.',
        'CDT_trace': 'Actual chi-minus3 proof is14 rows with16603/3920. Coarse trace has matching doubled cost/geometry; fine gains require actual preserved literal-n integral structure.'},
    'remaining_gates': ['Proved new-source or optimized joint-integral advantage overcoming the cap/cost gap.',
                        'Actual Q-germ, complete source rank, all-prime/all-row integral input, branch-correct common maps.',
                        'Strict arithmetic-holonomy contradiction and a new numerical theorem.',
                        'Latest source/novelty audit for any new numerical target; no new repo or whole-literature audit claimed here.'],
    'independent_review': {'status': 'PASS at final pinned versions for the actual recorded scopes',
                           'math_receipts': new_paths[5:10], 'report_receipt': review_path,
                           'corrections': 'Finite p=3 and zero-degree coefficient boundaries corrected in math notes; report corrected odd k restriction, closed-disk J scope and retained-background rank scope.'},
    'root_reading_receipt': {'math_notes': 'Actually FULL five final mathematical notes.',
                            'reviews': 'Actually FULL five final mathematical receipts and final report receipt.',
                            'report_scope': 'Actually FULL final report6873 bytes and global scope3297 bytes; trace scope2263 bytes FULL.',
                            'primary_selected': 'Actually FULL fixed CDT PDF pages122-123,149-150,153,157,172-173; eight pages. Earlier selected-page work reused, not relabeled as new.',
                            'other_readers': 'Trace author and reviewer FULL pages146-174,67-68,203-205; arithmetic author new FULL122-123, prior66-70 reused; arithmetic reviewer new relevant67-68. See scope/receipts.',
                            'old_inputs': 'FULL final220 global/cross notes and historical repository-carriers note. No latest full-repository audit.',
                            'final_manifest': 'Root reads the final saved manifest in full; no self-hash cycle.'},
    'source_claim_policy': {'new_external_sources': 0, 'primary': 'Existing fixed CDT v2 PDF; selected text archived in trace_sources_round221_20261008.',
                            'locator': 'Full extracted PDF text only for locating; not a claim of FULL218-page reading.',
                            'OpenAI_repo': 'Historical analysis reused. No Git, update, latest survey, new proof/formalization verification this round.',
                            'formalization': 'Paper derivation with independent review; no Lean claim.',
                            'novelty': 'No new numerical theorem and no new-target novelty claim.'},
    'execution_ledger': {k: 0 for k in ['mathematical_program_runs', 'prime_or_parameter_scans', 'finite_matrix_runs', 'symbolic_engines', 'PSLQ', 'Lean', 'Git_operations', 'numerical_integrations']},
    'predecessor': {**identity(previous_path), 'unchanged': True, 'historical_mutable_main_pin_not_recursively_rechecked': True},
    'main_append': {'path': main_path, 'preserved_prefix_bytes': prefix_size, 'preserved_prefix_sha256': prefix_digest,
                    'separator_hex': '0a0a', 'appended_report': report_path, 'appended_report_bytes': len(report),
                    'appended_report_sha256': sha(report), 'final_bytes': len(saved), 'final_sha256': sha(saved),
                    'report_heading_line': saved[:prefix_size+2].count(b'\n')+1,
                    'byte_for_byte_prefix_check': 'PASS', 'exact_append_check': 'PASS'},
    'pins': [identity(p) for p in pin_paths],
    'verification': {'pins': 'PASS', 'pinned_artifact_count': len(pin_paths), 'new_markdown_local_links': 'PASS',
                     'checked_local_link_count': len(links), 'new_document_controls': 'PASS', 'new_markdown_checked': len(new_paths),
                     'main_append': 'PASS', 'predecessor_immutable_pins_checked': old_checked,
                     'non_file_bracket_expressions_skipped': non_file_brackets},
}
manifest['execution_ledger'].update({'new_downloads': {'PDF': 0, 'HTML': 0, 'TEX': 0, 'README': 0},
                                     'documentary_operations': ['PDF text/selected pages', 'Markdown read/write', 'byte/hash/link/control checks and exact append'],
                                     'documentary_computation_is_not_a_math_experiment': True})
(ROOT / manifest_path).write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
check = json.loads((ROOT / manifest_path).read_text(encoding='utf-8'))
for pin in check['pins']:
    assert identity(pin['path']) == pin
for link in links:
    assert ((ROOT / link['source']).parent / link['target']).resolve().exists()
print(json.dumps({'manifest': identity(manifest_path), 'main': identity(main_path), 'verification': check['verification']}, ensure_ascii=False, indent=2))
