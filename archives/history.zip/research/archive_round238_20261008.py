"""One-shot documentary archive; no mathematical computation or Git mutation."""
from pathlib import Path
import hashlib
import json

root = Path(__file__).resolve().parent.parent
assert root == Path('E:/kimi-build/zeta5').resolve()
main = root / 'research/cdt_odd_background_progress_20261006.md'
report = root / 'research/research_actual_flag_round238_20261008.md'
policy = root / 'research/research_global_review_policy.md'
previous = root / 'literature/manifest_joint_lattice_metric_bridge_round237_20261008.json'
dest = root / 'literature/manifest_actual_flag_round238_20261008.json'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def pin(path):
    data = path.read_bytes()
    return {'path': path.relative_to(root).as_posix(),
            'bytes': len(data), 'sha256': sha(data)}


old, body = main.read_bytes(), report.read_bytes()
assert len(old) == 626196
assert sha(old) == 'a4559118e94daf175f07cb8e9cdf847b93ac4d9253d3813ca59d0ced4bba3aa6'
assert len(body) == 7515
assert sha(body) == '787a61726cee087e2c3f6cad3cd4f7721dc01b80bcde3c1cd2e96cf98a72505e'
assert sha(policy.read_bytes()) == '5ffd16d45f12ad7d4c7bae051b017fa10603eba4282676e3cef990db7b3f2caf'
assert sha(previous.read_bytes()) == 'fa88684c6faf6a8c90da717a93b99d2c196af0e5596d86f1ec10061b98add429'
assert not dest.exists(), 'Archive exists; do not rerun a completed producer'

frozen = {
    'actual_flag_determinant_round238_20261008.md':
        (8061, '799156d8cc6e030e77622cfe5eeeb7fa0ad5a4a61b80e8fb95e8851101f14954'),
    'actual_flag_independent_round238_20261008.md':
        (10621, 'ca6baa875e7c18a51afe6ba7682adfca6589abe2dd7621c24c77dde21ce2062d'),
    'cellular_uniform_projection_gate_round238_20261008.md':
        (7305, '0f203220ec292dfd279ac2f1afbe7950732f0189fec33a2eb6a1901e43e513d5'),
}
for name, (size, digest) in frozen.items():
    data = (root / 'research' / name).read_bytes()
    assert len(data) == size and sha(data) == digest, name

receipts = {
    'research_round238_report_review_20261008.md': sha(body),
    'research_round238_independent_check_20261008.md':
        frozen['actual_flag_independent_round238_20261008.md'][1],
    'research_round238_packet_check_20261008.md':
        frozen['actual_flag_determinant_round238_20261008.md'][1],
}
for name, digest in receipts.items():
    review = (root / 'research' / name).read_text(encoding='utf-8-sig')
    assert 'PASS' in review and digest in review, name

files = set((root / 'research').glob('*round238*20261008.*'))
files.update((root / 'literature/actual_flag_sources_round238_20261008').glob('*'))
files.add(policy)
records = [pin(p) for p in sorted(files) if p.is_file()]
primary_paths = [
    'literature/global_review_sources_round228_20261008/packet_cdt_L2chi_current_author.pdf',
    'literature/global_review_sources_round236_20261008/packet_cdt_current_pdf50_54.txt',
    'literature/brown2014_irrationality_moduli.pdf',
]
primaries = [pin(root / p) for p in primary_paths]
assert primaries[0]['sha256'] == '9d778fc22f82fb064371722ff457d54a2fc787608b8493ed9893a8fd39929a1c'
assert primaries[1]['sha256'] == '9789168f87f5db923d6a83335f091d8385412fb64679e20628e68f29b6aaadbd'

combined = old + b'\n\n' + body
manifest = {
    'round': 238, 'date': '2026-10-08', 'classification': 'progress',
    'goal_status': 'active', 'previous_goal_turn_classification': 'progress',
    'numerical_irrationality_or_independence_theorem': False,
    'paid': [
        'Actual filled g0=t whole positive-moment representation and corrected opposite outer-cut signs.',
        'Self-contained one-defect zero estimate; all-D full Taylor injectivity with N=3D+3.',
        'Actual one-hole flag V={0,...,3m} minus {m+h*}; h* is greatest nonzero cofactor index.',
        'Exact intrinsic fee A_D=-m log b_g-log|delta_h*| for the real actual flag under rationality.',
        'Selected-minor Chebyshev bound gives small fee lower 3 log(4/3), not the needed upper.',
        'Additional safe fixed-rational-g cutoff N=3D+10 from current CDT Theorem3.2.10.',
        'Fallback: standard dual observation misses all five forbidden coordinates; same-F eta period zeta3 disproves free GM projection inference.',
        'User global-review rule persisted: default six rounds, allowed four to eight, bounded route decisions.',
    ],
    'not_paid': [
        'Critical square perfection, a usable upper for the actual selected cofactor fee, or strict holonomy margin.',
        'All-n original cellular six-channel projection, explicit relative certificate, or a new numerical theorem.',
        'Global novelty, full-repository proof verification, or a general all-odd-zeta method.',
    ],
    'direction': {
        '239': 'Only full finite-place/content certificate for actual selected minor, uniformly over candidate holes if needed.',
        '240': 'Continue/stop check; without opening the basic BC necessary budget window, stop this source optimization and inspect a concrete cellular relative projection certificate.',
        '242': 'Default formal global review; retain this route until then only with actual fee improvement and a legal same-map energy interface.',
    },
    'formal_global_review': {'last': 236, 'next_default': 242,
                             'window': [240, 244], 'default_interval': 6,
                             'this_round_resets_counter': False},
    'mathematical_program_runs': 0, 'parameter_scans': 0,
    'new_saved_pdf_downloads': 0, 'git_mutations': 0, 'lean_builds': 0,
    'documentary_archive_attempts': 1,
    'corrections': 'Root right-cut sign error was independently caught, withdrawn and corrected before the paid proof. Read-only Windows rg glob error was fixed. No approval rejection.',
    'previous_manifest': pin(previous), 'previous_main': pin(main),
    'report': pin(report), 'policy': pin(policy), 'files': records,
    'reused_primary_files': primaries,
    'main_after': {'path': main.relative_to(root).as_posix(),
                   'bytes': len(combined), 'sha256': sha(combined)},
}
serialized = (json.dumps(manifest, ensure_ascii=False, indent=2) + '\n').encode('utf-8')
main.write_bytes(combined)
dest.write_bytes(serialized)
assert main.read_bytes()[:len(old)] == old
assert sha(main.read_bytes()) == manifest['main_after']['sha256']
assert json.loads(dest.read_text(encoding='utf-8'))['main_after'] == manifest['main_after']
print(json.dumps({'status': 'PASS', 'round': 238, 'file_pins': len(records),
                  'main_after': manifest['main_after'], 'manifest': pin(dest)}, ensure_ascii=False))
