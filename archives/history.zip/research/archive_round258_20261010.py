"""One-shot source-admission258 documentary archive. Never rerun a completed archive."""
from pathlib import Path
import hashlib
import json

ROOT = Path(__file__).resolve().parents[1]
assert ROOT == Path(r"E:\kimi-build\zeta5").resolve()
MANIFEST = ROOT / "literature/manifest_source_admission_round258_20261010.json"
PREVIOUS = ROOT / "literature/manifest_native_chi8_feasibility_round257_20261010.json"
MAIN = ROOT / "research/cdt_odd_background_progress_20261006.md"
POLICY = ROOT / "research/research_global_review_policy.md"
REPORT = ROOT / "research/research_source_admission_progress_round258_20261010.md"
REVIEW = ROOT / "research/research_round258_source_admission_review_20261010.md"
SOURCES = ROOT / "literature/source_admission_round258_20261010"
# Set only after Root has actually read the final, unique independent review.
REVIEW_SIZE = 14982
REVIEW_SHA = "e11d92a009821b89abf8def72e4b5b293fc22a8e5425f10b9f122392abebc2d3"


def digest(data):
    return hashlib.sha256(data).hexdigest()


def pin(path):
    data = path.read_bytes()
    return {"path": path.relative_to(ROOT).as_posix(), "bytes": len(data), "sha256": digest(data)}


def verify(path, size, sha):
    data = path.read_bytes()
    assert len(data) == size and digest(data) == sha, str(path)
    return data


assert not MANIFEST.exists(), "258 already completed; archive must not be rerun"
previous_data = verify(PREVIOUS, 31055, "8ef9519a93e75751405f6457d6e5bf9cba144228b66118bd3c76e7cc62c29635")
previous = json.loads(previous_data)
assert previous["round"] == 257 and len(previous["files"]) == 117
assert previous["formal_global_review"]["last"] == 256
assert previous["formal_global_review"]["completed_rounds_since_last"] == 1
for item in previous["files"]:
    verify(ROOT / item["path"], item["bytes"], item["sha256"])
old_main = verify(MAIN, 756536, "604cad1782f001025016758eb928d74a82da040cf937137e2c2d60a9b7aef6b7")
old_policy = verify(POLICY, 35715, "773dde038797bc593376eb1b52060f280e80d1a4616abed07f2a7ff330664074")
review_data = verify(REVIEW, REVIEW_SIZE, REVIEW_SHA)
review_text = review_data.decode("utf-8-sig")
review_lower = review_text.lower()
assert "PASS" in review_text and "260" in review_text and "264" in review_text
math_names = [
    "source_admission_shared_jump_round258_20261010.md",
    "source_admission_cyclotomic_round258_20261010.md",
    "source_admission_cdt_round258_20261010.md",
    "source_admission_alternative_round258_20261010.md",
]
math_paths = [ROOT / "research" / name for name in math_names]
for path in math_paths + [REPORT]:
    assert path.is_file()
    assert pin(path)["sha256"] in review_lower, str(path)
scope_paths = [SOURCES / f"{name}_reading_scope.md" for name in ["root", "cyclotomic", "cdt", "alternative"]]
for path in scope_paths:
    assert path.is_file()
    assert pin(path)["sha256"] in review_lower, str(path)
root_scope = scope_paths[0].read_text(encoding="utf-8-sig")
assert "独立数学复核" in root_scope
assert pin(math_paths[1])["sha256"] in root_scope.lower()
report_data = REPORT.read_bytes()
assert report_data not in old_main
assert "## 第258轮".encode("utf-8") not in old_policy
assert all(path.is_file() for path in SOURCES.iterdir())

policy_append = """

## 第258轮：关系收益先于实现与重复来源止损

用户每4–8轮俯瞰全局的要求持续执行：默认4个完成轮、最多8轮，连续2轮核心准入或净可行性没有推进则提前。复盘按目标差距、关键缺口变化、真实完整费用、跨架构机会成本及下一首证书/停止条件决策；文档、局部引理、改名坐标和工作量不计作数值出口推进，也不重置clock。本轮不属正式重置：last256，258完成后计数2，next260、latest264。

本轮保留新的完整坏芽判据：对全部潜在复系数数值关系自动亚纯化，当且仅当实际类[F_j]=Theta_j[F_0]。字面常函数1通常不能承载目标unit period；必须检查完整坏芽，不只最高log项或有限jets。这一规则仅约束CDT补点机制；乘积公式路线可以由关系使同一完整增长det有理而取得收益，不必改变branch。

固定经典三/四圆分Li及其有限Hadamard闭包不消指定完整supports；Hadamard改变权重和endpoint目标。固定weight≤7 DD/KZ的真实ζ(7)投影和全log-Taylor费用已给，但ζ(7)有理不消nilpotent monodromy，且未付ordinary rational-germ入口，故不准入。均不是全部圆分/KZ方法或目标数值的no-go。

拟议level14 A7/B7/C7去重后拒绝：B/C就是247旧R/D，A为旧carrier的weight0有理倍，同完整field。新三叶t不是旧u的有理rescaling，仍不是新关系机制；不借旧m/τ给新tuple费用，也不领取新rank。既停level14源不得用新坐标或period行改名重开259。

本轮无候选得到实现准入。下一轮先有界选择真正新载体或有证据改变完整净预算的product-formula机制，固定目标、完整实际族及关系收益后才进入第一证书。没有具体机制，不硬开导子、参数、prime、map、sheet或矩阵窗口。第一关通过亦不自动续长优化；同对象严格余量、实际无界非零与完整算术费用仍是原成功标准。总目标active，new numeric false。

新文献及准确scope保存在source_admission_round258_20261010，四数学稿、report与唯一独审后单次归档。Root独核cyclotomic，cyclotomic独审Root/CDT/alternative/report；Root另核CDT与DD/KZ。旧257全部117 pins先核，116非policy旧files不变，main/policy旧bytes前缀保留。精确有理CAS仅用于CDT固定identity/fiber初始证书，次数见cdt scope，不作全jump/rank/能量认证；其它作者数学运行0。无finite-n数值/interval、parameter/prime/map/word扫描、Lean、外Git写或旧producer。下载、文件核验及文档归档不代替数学结果。
""".encode("utf-8")

paths = {ROOT / item["path"] for item in previous["files"] if item["path"] != "research/research_global_review_policy.md"}
paths.update([PREVIOUS, POLICY, REPORT, REVIEW, Path(__file__)])
paths.update(math_paths)
paths.add(ROOT / "research/source_admission_cdt_round258_reading_scope_20261010.md")
paths.update(SOURCES.iterdir())
assert len(paths) == 116 + 5 + 4 + 1 + len(list(SOURCES.iterdir()))
assert all(path.is_file() for path in paths)

# Mutation only after all identities and the independent frozen review are verified.
POLICY.write_bytes(old_policy + policy_append)
MAIN.write_bytes(old_main + b"\n\n" + report_data)
assert POLICY.read_bytes()[:len(old_policy)] == old_policy
assert MAIN.read_bytes()[:len(old_main)] == old_main
assert MAIN.read_bytes().count(report_data) == 1
for item in previous["files"]:
    if item["path"] != "research/research_global_review_policy.md":
        verify(ROOT / item["path"], item["bytes"], item["sha256"])

manifest = {
    "round": 258,
    "date_completed": "2026-10-10",
    "classification": "progress",
    "goal_status": "active",
    "progress_kind": "Complete bad-germ relation-lift criterion; classic Hadamard closure boundary; actual CDT calibration and level14 duplicate rejection; fixed KZ full-family and prefix arithmetic admission audit",
    "new_numerical_irrationality_or_independence_theorem": False,
    "global_novelty_or_full_lean_audit": False,
    "formal_global_review": {"last": 256, "previous_formal": 252, "this_round_is_formal": False, "counter_reset_this_round": False, "completed_rounds_since_last": 2, "next_scheduled": 260, "latest_required": 264, "default_interval": 4, "maximum_interval": 8, "early_core_stagnation_rounds": 2},
    "paid_this_round": ["Complete germ-quotient criterion with all-complex-coefficient quantifier and explicit limited necessity", "Nontrivial unit-period carrier requirement for automatic CDT relation lifting", "Exact classic four-channel endpoint and full local support classification", "Finite classic Hadamard closure and weight/target-change boundary", "CDT fixed-v2 complete shared-jump calibration", "Level14 explicit coordinate and Abel-period/prefix certificate retained as duplicate asset only", "Old247/248 source equivalence and no automatic revival of stopped level14 window", "Fixed weight7 KZ nilpotent-jump and finite-ramification lemma", "Minimal full scalar rank14 and all-prime log-Taylor prefix model; universal255 safe model"],
    "admission": {"classic_four_channels": "rejected for specified automatic fill-in mechanism", "level14_three_sources": "duplicate-rejected; no new source or implementation admission", "fixed_weight7_KZ": "rejected for proposed relation-sensitive single-valued meromorphic fill-in", "implementation_admitted": False, "general_cyclotomic_KZ_or_level14_impossibility": False},
    "stopped_default_windows": previous["stopped_default_windows"] + ["Fixed classic four-channel finite Hadamard closure for automatic branch fill-in", "Fixed weight<=7 universal/scalar KZ subtraction source for zeta7 relation-sensitive fill-in", "Level14 ABC7 re-expression of stopped247/248 R/D source; no new default window"],
    "next_unique_work": {"round": 259, "scope": "Bounded selection of genuinely new actual period carrier or evidenced same-object product-formula mechanism before any implementation", "admission_requires": ["Fixed numerical target, complete actual family and relation-produced analytic or arithmetic gain", "Comparison to old stopped windows before calling coordinate or channel changes new", "Nontrivial unit-period carrier and entire shared bad germ for CDT fill-in", "Complete period cancellation, arithmetic, actual nonzero and strict same-object margin for product formula"], "automatic_parameter_prime_map_sheet_or_matrix_extension": False, "if_no_new_mechanism": "Do not open implementation; return to scheduled global review"},
    "runs": {"root_math_programs": 0, "cyclotomic_math_programs": 0, "alternative_math_programs": 0, "cdt_exact_cas_processes": 3, "cdt_cas_scope": "Fixed HG pullback, T elimination/branch/fiber and F7 identities; no full analytic jump/rank/energy certificate", "finite_n_numerical_or_interval": 0, "prime_parameter_map_word_scans": 0, "lean": 0, "external_git_mutations": 0, "old_archive_producers": 0, "this_documentary_archive": 1},
    "sources": {"precise_scopes": [pin(path) for path in scope_paths], "whole_primary_paper_reading_claim": False, "fresh_cloud_repository_equality_claim": False, "mathematics_independently_proved_not_inferred_from_hashes": True},
    "previous_manifest": pin(PREVIOUS),
    "previous_manifest_nonpolicy_files_preserved": 116,
    "report": pin(REPORT),
    "independent_math_and_report_review": pin(REVIEW),
    "previous_policy": {"bytes": len(old_policy), "sha256": digest(old_policy)},
    "new_policy": pin(POLICY),
    "previous_main": {"bytes": len(old_main), "sha256": digest(old_main)},
    "new_main": pin(MAIN),
    "files": [pin(path) for path in sorted(paths)],
}
MANIFEST.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
assert PREVIOUS.read_bytes() == previous_data and REVIEW.read_bytes() == review_data
print(json.dumps({"status": "PASS", "numeric_theorem": False, "goal_status": "active", "files": len(paths), "old_nonpolicy_preserved": 116, "completed_since_formal": 2, "next_formal": 260, "latest_formal": 264, "manifest": pin(MANIFEST), "main": pin(MAIN), "policy": pin(POLICY)}, ensure_ascii=False))
