"""One-shot documentary archive. No mathematical producer or Git operations."""
from pathlib import Path
import hashlib
import json
import re

root = Path(__file__).resolve().parent.parent
main = root / "research/cdt_odd_background_progress_20261006.md"
report = root / "research/research_bounded_source_gate_round233_20261008.md"
previous = root / "literature/manifest_global_review_round232_20261008.json"
dest = root / "literature/manifest_bounded_source_gate_round233_20261008.json"
old_size = 592157
old_sha = "f727cbcd46348ca253b133bd7f443ef61f26de255029d22e67ba1c1a4554f451"
prev_sha = "c4f4003653809d0cb6d80ea70c0564a7c783a94630ca3aaa4278d91b026cf975"
report_sha = "051e26f670d3251f340f19d72d85cafa6b022afd5c7ffd92e7ce2e36d9050dd6"


def sha(data):
    return hashlib.sha256(data).hexdigest()


old, body = main.read_bytes(), report.read_bytes()
assert len(old) == old_size and sha(old) == old_sha, "Main prefix changed"
assert sha(previous.read_bytes()) == prev_sha, "Predecessor changed"
assert sha(body) == report_sha, "Report changed"
assert not dest.exists(), "Do not rerun a completed archive"
review = root / "research/research_round233_bounded_report_review_20261008.md"
assert review.is_file(), "Final independent report review is pending"

files = sorted({*root.joinpath("research").glob("*round233*20261008.*"),
                *root.joinpath("literature/truncated_gate_sources_round233_20261008").glob("*")})
pins = []
for path in files:
    if not path.is_file():
        continue
    data = path.read_bytes()
    if path.suffix == ".md":
        text = data.decode("utf-8-sig")
        assert not any(ord(c) < 32 and c not in "\r\n\t" for c in text), path
    pins.append({"path": path.relative_to(root).as_posix(),
                 "bytes": len(data), "sha256": sha(data)})

links = []
for target in re.findall(r"\]\(([^)]+)\)", body.decode("utf-8-sig")):
    if target.startswith(("http:", "https:", "#")):
        continue
    assert (report.parent / target.split("#", 1)[0]).resolve().is_file(), target
    links.append(target)

combined = old + b"\n\n" + body
manifest = {
    "round": 233, "date": "2026-10-08", "status": "progress",
    "previous_goal_turn_classification": "progress",
    "mathematical_program_runs": 0, "mathematical_program_failures": 0,
    "git_mutations": 0, "lean_builds": 0,
    "mathematical_status": "Bounded gate downgrades original truncated W; all-scale Cauchy residue rank and positive comparison paid, actual spectral point remains; fixed algebraic differential filter obstruction proved; distinct rational mixed-period source has exact canonical branch cancellation and full safe Taylor transport; no new numerical irrationality theorem",
    "global_review_cadence": {
        "last_formal": 232, "elapsed_rounds": 1,
        "default_next": 238, "window": [236, 240],
        "reset_by_this_round": False,
        "tactical_stop_check": "Two rounds without core-interface progress trigger a local stop check; a disproved mechanism is downgraded immediately",
    },
    "next_interface": "One bounded admissibility gate for H_g=P+gC and the distinct t target: actual rank, all-preimage univalent leaf, full Taylor denominator type, same-map strict CDT budget, and existing theorem coverage; no automatic determinant scan or six-round optimization",
    "verification_scope": "New files and current report links; preserved main prefix and predecessor identity only; no historical producer/archive or broad pin audit",
    "source_scope": "Reused fixed CDT v2 PDF26 and PDF34 fully read and newly extracted; selected earlier theorem text reread; no new PDF download, full-paper or global novelty certification",
    "repository_state": "No fresh remote or Git operation this round; inherited round232 evidence only",
    "predecessor": {
        "path": previous.relative_to(root).as_posix(),
        "bytes": previous.stat().st_size, "sha256": prev_sha,
    },
    "main_preserved_prefix": {"bytes": old_size, "sha256": old_sha},
    "appended_report": {
        "path": report.relative_to(root).as_posix(),
        "bytes": len(body), "sha256": report_sha,
    },
    "main_after_append": {
        "path": main.relative_to(root).as_posix(),
        "bytes": len(combined), "sha256": sha(combined),
    },
    "report_links_checked": links, "new_pins": pins,
}
dest.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
main.write_bytes(combined)
assert main.read_bytes() == combined
print(json.dumps({
    "status": "PASS", "round": 233, "pins": len(pins),
    "report_links": len(links), "mathematical_runs": 0,
    "main_bytes": len(combined), "main_sha256": sha(combined),
    "manifest_bytes": dest.stat().st_size,
    "manifest_sha256": sha(dest.read_bytes()),
}, ensure_ascii=False))
