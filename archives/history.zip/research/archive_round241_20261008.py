"""One-shot documentary archive; no mathematics, Git operation, or Lean run."""
from pathlib import Path
import hashlib
import json

root = Path(__file__).resolve().parent.parent
assert root == Path('E:/kimi-build/zeta5').resolve()
main = root / 'research/cdt_odd_background_progress_20261006.md'
report = root / 'research/research_logistic_prime_edge_progress_round241_20261008.md'
certificate = root / 'research/logistic_prime_edge_full_certificate_round241_20261008.md'
policy = root / 'research/research_global_review_policy.md'
previous = root / 'literature/manifest_global_review_round240_20261008.json'
source_dir = root / 'literature/logistic_prime_edge_round241_20261008'
destination = root / 'literature/manifest_logistic_prime_edge_round241_20261008.json'


def digest(data):
    return hashlib.sha256(data).hexdigest()


def pin(path):
    data = path.read_bytes()
    return {'path': path.relative_to(root).as_posix(),
            'bytes': len(data), 'sha256': digest(data)}


assert not destination.exists(), 'Never rerun a completed archive producer'
old = main.read_bytes()
assert len(old) == 650997
assert digest(old) == '7fc6199892edaf7073fcef1933843dd48cb9d67a4429c8f61b7fb5312317e999'
assert digest(previous.read_bytes()) == '60735e2cd4f1a065fb7b5f3f98bc6e4aeeb4ed86bcac743e30e91f4b00377b77'
assert digest(policy.read_bytes()) == '1d0734fe99cdaaa92fa2430493e4eda19899e2e292a6ffc8b9dc908cac01e5af'
body, proof = report.read_bytes(), certificate.read_bytes()
assert len(body) == 3734
assert digest(body) == '0cbf6e65b6fb3ce980720d2b31be037a1a64aaa0a790071c51b8b9883a30e05d'
assert len(proof) == 9100
assert digest(proof) == '57e591ba89c52556066ec502c8dbb9d5bc81521cbecfaa18bc0d793fd433c665'

review_targets = {
    'research/research_round241_full_certificate_review_20261008.md': certificate,
    'research/research_round241_distribution_block_review_20261008.md': certificate,
    'research/research_round241_progress_report_review_20261008.md': report,
}
for review, target in review_targets.items():
    text = (root / review).read_text(encoding='utf-8-sig')
    assert 'PASS' in text and digest(target.read_bytes()) in text, review

for name in ['packet', 'dual', 'arithmetic']:
    assert (root / f'research/logistic_prime_edge_{name}_round241_20261008.md').is_file()
for name in ['root', 'packet', 'dual', 'alternative']:
    assert (source_dir / f'{name}_reading_scope.md').is_file()

check = root / 'research/logistic_prime_edge_fixed_blocks_round241_20261008.json'
run = json.loads(check.read_text(encoding='utf-8'))
assert run['variable_prime_sampling'] is False
assert [x['determinant'] for x in run['blocks']] == [
    '541936393813/62208', '-100344353231/3888', '-210779/4']
combined = old + b'\n\n' + body
files = set((root / 'research').glob('*round241*20261008.*'))
files.update(p for p in source_dir.rglob('*') if p.is_file())
files.add(policy)
records = [pin(p) for p in sorted(files) if p.is_file()]
manifest = {
    'round': 241, 'date': '2026-10-09', 'filename_date_label': '20261008',
    'classification': 'progress', 'previous_interrupted_turn_classification': 'no progress',
    'goal_status': 'active', 'new_numerical_irrationality_or_independence_theorem': False,
    'formal_global_review': {'last': 240, 'counter_reset_this_round': False,
                             'next_default': 246, 'allowed_window': [244, 248]},
    'object': {'target': '3 zeta(3) + zeta(5)', 'functional': '(3/2) B partial + (1/24) B partial^3 on t f',
               'kernel': 'D_n^4 / D_(5n)', 'matrix_size': '3n', 'edge': 'n=p-1'},
    'paid': [
        'Whole high-order rational distribution with exact polynomial quotient and all harmonic heads, local error valuation at least beta.',
        'Complete CRT basis, same-disc unit weights independent of local indices, every off-disc positive excess, including half-valuations.',
        'Three explicit fixed V3 Gram unit blocks, independently derived on paper and checked once by exact rational arithmetic.',
        'Actual full primitive P_(p-1) has p-unit constant and coefficient k valuation at least 5k outside a fixed finite set.',
        'Every fixed rational q has P_(p-1)(q) nonzero for every eligible prime not dividing its denominator, hence infinitely many unbounded scales.',
        'Exact all-coefficient auxiliary-prime Gauss valuation of Q is 5-9p and of Qtilde is 5-3p; primitive ratio cost is 3p-5.',
        'Independent complete-certificate, distribution-block, and final-progress-report paper reviews.',
    ],
    'not_paid': [
        'A new numerical irrationality/linear-independence theorem or completion of the original objective.',
        'Whole-prime/window primitive Gauss cost below the strict same-object analytic threshold.',
        'Independent complete certification of the original -6 FstarInput energy bound.',
        'Lean kernel verification, full source/import audit, current remote freshness, or global novelty certification.',
    ],
    'next_gate': 'Round242: actual all-coefficient whole-prime/window Gauss budget, with S_n and F_n, for the same fixed complete source; no extra prime-edge sampling.',
    'bounded_main_window': [241, 244],
    'runs': {'mathematics': 1, 'fixed_constant_blocks_checked': 3,
             'variable_prime_or_parameter_scans': 0, 'lean': 0, 'git_mutations': 0,
             'old_archive_producers': 0, 'this_documentary_archive': 1},
    'sources': {'repository': 'dtq1997/zeta2-zeta3-linear-independence',
                'pinned_commit': '669c92bf7a3728e0de9ad80c373bc29fb5ca3d58',
                'reading_scope_records': [pin(source_dir / f'{n}_reading_scope.md')
                                          for n in ['root', 'packet', 'dual', 'alternative']]},
    'previous_manifest': pin(previous),
    'previous_main': {'bytes': len(old), 'sha256': digest(old)},
    'report': pin(report), 'certificate': pin(certificate),
    'new_main': {'path': main.relative_to(root).as_posix(),
                 'bytes': len(combined), 'sha256': digest(combined)},
    'files': records,
}
main.write_bytes(combined)
destination.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
assert main.read_bytes()[:len(old)] == old
assert main.read_bytes()[len(old):] == b'\n\n' + body
for entry in records:
    assert pin(root / entry['path']) == entry
print(json.dumps({'status': 'PASS', 'manifest': pin(destination),
                  'main': pin(main), 'pinned_files': len(records)}, ensure_ascii=False))
