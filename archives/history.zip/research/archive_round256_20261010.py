"""One-shot documentary archive256; no mathematical computation or external Git writes."""
from pathlib import Path
import hashlib
import json

ROOT = Path(__file__).resolve().parents[1]
assert ROOT == Path(r"E:\kimi-build\zeta5").resolve()
MANIFEST = ROOT / "literature/manifest_native_chi8_round256_20261010.json"
assert not MANIFEST.exists(), "Completed256 archive must not be rerun"
PREVIOUS = ROOT / "literature/manifest_architecture_round255_20261010.json"
MAIN = ROOT / "research/cdt_odd_background_progress_20261006.md"
POLICY = ROOT / "research/research_global_review_policy.md"
REPORT = ROOT / "research/research_native_chi8_progress_round256_20261010.md"
REVIEW = ROOT / "research/research_round256_native_gate_review_20261010.md"
SOURCES = ROOT / "literature/native_chi8_sources_round256_20261010"


def digest(data):
    return hashlib.sha256(data).hexdigest()


def pin(path):
    data = path.read_bytes()
    return {"path": path.relative_to(ROOT).as_posix(), "bytes": len(data), "sha256": digest(data)}


def verify(path, size, sha):
    data = path.read_bytes()
    assert len(data) == size and digest(data) == sha, str(path)
    return data


previous_data = verify(PREVIOUS, 22464, "f436ed5c0379f6cb752ba8c715304234416e5ac3d30387ec4903f02bee76c8e9")
previous = json.loads(previous_data)
assert previous["round"] == 255 and len(previous["files"]) == 83
assert previous["formal_global_review"]["last"] == 252
assert previous["formal_global_review"]["completed_rounds_since_last"] == 3
assert previous["formal_global_review"]["next_scheduled"] == 256
for item in previous["files"]:
    verify(ROOT / item["path"], item["bytes"], item["sha256"])
old_main = verify(MAIN, 742285, "c044d6baab2e53a7d7548af116dfc8eeed748d707b5f6d40e6d64c5f40f34bc4")
old_policy = verify(POLICY, 28276, "32692531b5912398cc2b59ca6477a315fcf69bb01e1578377627df0ec1094f11")
report_data = verify(REPORT, 7975, "22fe7f3b33784d3ce11af4e77ac101acfc1f84c7dfc6c1f422359910d124cc31")
review_data = verify(REVIEW, 7404, "f9abebb07b5926257c7f60c95c31738c59fc35d3696edbd80930a4af3e9a1798")
review_text = review_data.decode("utf-8-sig")
assert "PASS" in review_text and "257" in review_text and "260" in review_text and "264" in review_text
authors = [
    ("chi8_native_sensitivity_gate_round256_20261010.md", 5652, "46cb484affbd555ba890762fff10869ff0b1c6c1c8155ee4a73762cdd9f85f86"),
    ("chi8_native_contour_gate_round256_20261010.md", 12037, "7f697bd08576d4c24fcf7db1258da740503a312a62eb0290c8a2307566b84720"),
    ("chi8_native_integer_gate_round256_20261010.md", 12234, "6abcbfc48af2cf3553c953c03a527059e78ede541d6526cc4806f4eb18de3877"),
    ("research_global_review_round256_20261010.md", 12994, "6c83de1508263d6487df740a76c145d787a281e0a31334b7ad29d751bd9530d5"),
]
for name, size, sha in authors:
    verify(ROOT / "research" / name, size, sha)
    assert sha in review_text
assert digest(report_data) in review_text
scopes = [
    ("root", 3620, "b8113d54b8566f51406d9b98204cc01b7aaec6d702a9390a127f4b10fba79be7"),
    ("contour", 2985, "474538ac54027aef2a55fce05b8954ca68ff444e57c6ccf4ca5b5c297f416ba0"),
    ("integer", 2934, "7ad5ef3c5927842629c819ba6d4876386e8ac5a12f063b056cad80f31e5e86df"),
    ("global", 5248, "65e3c10979b095e8a5dd755795944f08f03823489d2213026c5a6fe7c3a7bce0"),
]
for name, size, sha in scopes:
    verify(SOURCES / f"{name}_reading_scope.md", size, sha)
    assert sha in review_text
root_scope = (SOURCES / "root_reading_scope.md").read_text(encoding="utf-8")
assert authors[3][2] in root_scope and "独立数学复核" in root_scope
for source_name, original in [
    ("contour_input255_root.md", ROOT / "research/research_architecture_gate_round255_20261010.md"),
    ("contour_input255_A.md", ROOT / "research/research_catalan_architecture_round255_20261010.md"),
    ("contour_input255_B.md", ROOT / "research/research_holonomy_architecture_round255_20261010.md"),
    ("contour_input255_progress.md", ROOT / "research/research_architecture_progress_round255_20261010.md"),
    ("contour_input255_manifest.json", PREVIOUS),
]:
    assert (SOURCES / source_name).read_bytes() == original.read_bytes()
assert len(list(SOURCES.iterdir())) == 9
assert "## 第256轮".encode("utf-8") not in old_policy
assert report_data not in old_main

policy_append = """

## 第256轮正式全局复盘：共同载体首关与唯一目标特定净检验

用户要求每4–8轮俯瞰全局已落实：默认每4个完成轮正式复盘、最大8轮；连续2轮只改善局部rank/upper而不改变核心数值出口则提前。每次正式回顾必须比较完整目标period、整模型、实际关系点无界非零、同对象finite费用与real能量，并决定继续、停止或转向。新增引理数量不作为默认延窗依据。正式256完成后last256、计数0、next260、latest264；原总目标active，没有新数值ζ/L定理。

本轮固定255 native Q χ−8完整两sheet载体：a=1/√2、实际绕+1一次T、3+T、N=a^i(3+T)M，沿用整数contact prototype和全部raw j<2n。支付共同实际双变量芽、固定合法theta contour、全部polar divisor和可去奇点、全indices继续与Cauchy系数交换，三个真实starts及全部finite heads；ordinary Z另用其实际伴随积分，不领new sheet正性。

完整全prime-power前缀证书q_H=2^(2H+1)d_(H+1)^3清所有R、两period coefficients及Z heads；初等logq_H=O(H)。全row heights、native a^i尺度及整数filter的列l1费用已包含。固定row整数content乘积κ=2^(n(n+1)/2)给q^nΔ/κ∈Z[T]，与另一native行尺度不可双扣。同对象primitive正号多项式不因有理行列缩放改变；标准PNT换算scalar fee为6+(7/2)log2，primitive leading安全fee为6+(9/2)log2，都不是最优内容或actual-energy lower。

正式宏观比较保留K5、β4、Fricke、RV、M0,10等各自完整资产，旧默认局部窗口不改名重开。幂相位Sρ<k仍须真实代数独立k源与同一合法图；UDClevel raising不免费应用于一般polylog。安全upper失败不宣判全路线no-go。

新增关系敏感性证书：完整free-start双芽差16(g−Y)/[(1−zw)sqrt(1−z²/2)]；Δ_n(g)=(16·2^n)^n det(gI−K_n)，K_n有理并保留全部heads；Chebyshev排除固定g区间uniform负二次界，但不排除特殊Y或有理点。直接零列C_g满足(C_g/A)'=8arcsin(az)/[a z(1−z)]，z1固定−4πlog对所有g非零，所以只关闭直接C_g-at1目标补点桥，不关闭完整contact或两sheet行列式。

唯一下一257只检验同一prototype actualY谱积/完整两sheet能量与完整primitive费用的净可行性。数值出口要在无界子列同时付Π_n(Y)非零与limsup n^(−2)(logℓ_n+Σlog|Y−λ_j(K_n)|)<0。或新增足以严格改变完整净预算的全尺度内容/actual能量证书并指出剩余有限条件；局部rank、同一旧safe upper、未付primitive成本的decay不准续窗。若只有后者，结束默认prototype实现并保留载体，不自动扫prime/Frobenius/参数/maps/sheetwords/换向量。

四数学final、正式报告、四actual scopes及唯一独审后单次归档。Root独核B作者新数学，B独审Root/A/C/report。255全部83pins先核，82非policy旧files与main/policy旧bytes前缀保留。数学程序、有限n头、CAS/区间、prime/参数/map/word扫描、Lean、外Git写和旧producer0；文档读写/散列/一次archive不作数学计算。Root一web三queries未命中未采用；B实际复读已保存ICM物理3–4、9–13选段；团队新PDF/HTML下载0，不声称全球novelty、全部primary全文审计或Lean验证。
""".encode("utf-8")

paths = {ROOT / item["path"] for item in previous["files"] if item["path"] != "research/research_global_review_policy.md"}
paths.add(PREVIOUS)
paths.update((ROOT / "research").glob("*round256*20261010*"))
paths.update(SOURCES.iterdir())
paths.add(POLICY)
assert len(paths) == 100 and all(path.is_file() for path in paths)

# All mutations occur only after frozen inputs and the unique independent review pass.
POLICY.write_bytes(old_policy + policy_append)
MAIN.write_bytes(old_main + b"\n\n" + report_data)
assert POLICY.read_bytes()[:len(old_policy)] == old_policy
assert MAIN.read_bytes()[:len(old_main)] == old_main
assert MAIN.read_bytes().count(report_data) == 1
for item in previous["files"]:
    if item["path"] != "research/research_global_review_policy.md":
        verify(ROOT / item["path"], item["bytes"], item["sha256"])
manifest = {
    "round": 256,
    "date_completed": "2026-10-10",
    "classification": "progress",
    "goal_status": "active",
    "progress_kind": "Common actual bivariate generating germ and contour; complete exponential Z-prefix integer model; target-sensitive spectrum and primitive criterion; formal global investment review",
    "new_numerical_irrationality_or_independence_theorem": False,
    "global_novelty_or_full_lean_audit": False,
    "formal_global_review": {"last": 256, "previous_formal": 252, "this_round_is_formal": True, "counter_reset_this_round": True, "completed_rounds_since_last": 0, "next_scheduled": 260, "latest_required": 264, "default_interval": 4, "early_core_stagnation_rounds": 2, "maximum_interval": 8},
    "paid_this_round": ["Actual common bivariate germ and fixed theta contour for all indices", "All polar divisors and removable roots, uniform analytic continuation and Cauchy coefficient matching", "Complete heads, all prime powers and ordinary Z-prefix q_H=2^(2H+1)d_(H+1)^3 with log q_H=O(H)", "Full row and filter heights, native scales and known row content without double credit", "Exact rational K_n spectrum and positive-leading primitive determinant criterion", "Free-start whole-germ identity, Chebyshev and real sublevel bounds with correct pointwise limits", "Direct C_g-at1 target-sensitive fill-in obstruction with fixed nonzero log", "Formal four-interface global comparison and one bounded target-specific257 investment"],
    "strict_status": {"actual_common_germ_and_contour_paid": True, "complete_prefix_integer_budget_paid_for_new_source": True, "optimal_primitive_content_paid": False, "actual_numeric_nonzero_paid_for_new_source": False, "complete_net_energy_paid_for_new_source": False, "target_coefficient_rank_is_numeric_nonzero": False, "safe_upper_is_actual_energy_lower": False},
    "stopped_default_windows": previous["stopped_default_windows"],
    "bridge_closed_this_round": {"object": "Direct native zero-column C_g at z=1", "reason": "Native log leading coefficient -4*pi is nonzero for every free start g", "does_not_close_full_contact_or_two_sheet_determinant": True},
    "next_unique_work": {"round": 257, "fixed_target": "Y=L(2,chi_-8)", "fixed_object": "Same a=1/sqrt2, actual parameter loop at +1, 3+T, N=a^i barM; same integer monomial contact prototype and selected-even determinant", "scope": "One actual-Y spectrum or full two-sheet energy feasibility certificate with full primitive cost on n^2 scale", "continue_only_if": ["Actual unbounded nonzero and strict net quadratic bound", "New full-scale content or actual energy certificate strictly changes the complete net budget, with the remaining finite condition stated"], "stop_if": ["Only more local rank or computable coefficient data", "Same insufficient safe upper", "Decay without complete same-scale primitive cost"], "automatic_parameter_prime_map_or_sheet_extension": False, "stop_is_investment_decision_not_general_chi8_impossibility": True},
    "runs": {"mathematics": 0, "finite_n_hand_heads_programs_or_certificates": 0, "cas_or_interval": 0, "prime_parameter_map_word_scans": 0, "lean": 0, "external_git_mutations": 0, "old_archive_producers": 0, "this_documentary_archive": 1},
    "sources": {"root_search_calls": 1, "root_search_queries": 3, "root_search_empty_and_no_theorem_adopted": True, "new_pdf_downloads_by_team": 0, "new_html_downloads_by_team": 0, "whole_paper_reading_claim": False, "precise_scope": "Four final reading scopes; frozen255 carrier inputs; existing ICM physical3-4 and9-13 full saved sections read by B"},
    "previous_manifest": pin(PREVIOUS),
    "previous_manifest_nonpolicy_files_preserved": 82,
    "report": pin(REPORT),
    "formal_global_review_document": pin(ROOT / "research/research_global_review_round256_20261010.md"),
    "independent_math_and_report_review": pin(REVIEW),
    "root_independent_global_author_review": pin(SOURCES / "root_reading_scope.md"),
    "previous_policy": {"bytes": len(old_policy), "sha256": digest(old_policy)},
    "new_policy": pin(POLICY),
    "previous_main": {"bytes": len(old_main), "sha256": digest(old_main)},
    "new_main": pin(MAIN),
    "files": [pin(path) for path in sorted(paths)],
}
MANIFEST.write_text(json.dumps(manifest, ensure_ascii=False, indent=2)+"\n", encoding="utf-8")
assert PREVIOUS.read_bytes() == previous_data
assert REVIEW.read_bytes() == review_data
print(json.dumps({"status": "PASS", "numeric_theorem": False, "next_formal_review": 260, "latest_formal_review": 264, "completed_since_formal": 0, "old_nonpolicy_files_preserved": 82, "files": len(manifest["files"]), "manifest": pin(MANIFEST), "main": pin(MAIN), "policy": pin(POLICY)}, ensure_ascii=False))
