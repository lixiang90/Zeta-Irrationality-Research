"""One-shot documentary archive for round 234; no mathematical producer."""
from pathlib import Path
import hashlib
import json
import re

root = Path(__file__).resolve().parent.parent
assert root == Path("E:/kimi-build/zeta5").resolve()
main = root / "research/cdt_odd_background_progress_20261006.md"
report = root / "research/research_rational_source_global_gate_round234_20261008.md"
previous = root / "literature/manifest_bounded_source_gate_round233_20261008.json"
dest = root / "literature/manifest_rational_source_global_gate_round234_20261008.json"


def sha(data):
    return hashlib.sha256(data).hexdigest()


old_size = 597737
old_sha = "561c0a1e431681b1c505ec33de0f918db30e0d8133d6a32dcaf678a4b100dd4d"
previous_sha = "e4fa1ce9fd411f62e9bae576fde76a94b1ba151130c52f88873ea284ab86babc"
report_sha = "f8984fa2b1cf7df2e8398f2db8a4ae9d2b14150abf4915a8254bd1f17e170f61"
old, body = main.read_bytes(), report.read_bytes()
assert len(old) == old_size and sha(old) == old_sha, "Main prefix changed"
assert previous.stat().st_size == 6405 and sha(previous.read_bytes()) == previous_sha
assert len(body) == 5951 and sha(body) == report_sha, "Final report changed"
assert not dest.exists(), "Completed archive must not be rerun"

frozen_math = {
    "truncated_rational_source_exact_lcd_round234_20261008.md": (6081, "255c474af62a9d85f15b67b2932e652b0676dcef50830f03e8aa45274aec87bf"),
    "truncated_meromorphic_all_map_cap_round234_20261008.md": (4408, "9211d4ccf424ede0cf1fe94def12191c0747c5e364da7c723dd4b797ce73e390"),
    "truncated_rational_source_rank_leaf_gate_round234_20261008.md": (9707, "2c7bb29c41b935159a9f9ad8d97107dbcd3173d436777895e8461651e14c5b8f"),
    "truncated_rational_pullback_integral_flags_round234_20261008.md": (9529, "ca350ab2f584583fe0146684afb112867280d73dc92b44036037945051dc2f03"),
    "truncated_fixed_basis_denominator_floor_round234_20261008.md": (6484, "eea286f00d9c9168558519f753079d0e5de96d0a06cf8eec960b0b7333d936d2"),
    "truncated_target_primary_coverage_round234_20261008.md": (4756, "187aa8288531b182978c13b8ce2c7fe15fd4f7366241c7b22cbd6e3a0d0d10a7"),
}
for name, (size, digest) in frozen_math.items():
    data = (root / "research" / name).read_bytes()
    assert len(data) == size and sha(data) == digest, name

files = set(root.joinpath("research").glob("*round234*20261008.*"))
for folder in (
    "rational_source_gate_sources_round234_20261008",
    "truncated_analytic_sources_round234_20261008",
    "truncated_gate_sources_round234_20261008",
    "truncated_coverage_sources_round234_20261008",
):
    files.update(root.joinpath("literature", folder).glob("*"))
pins = []
for path in sorted(files):
    if not path.is_file():
        continue
    data = path.read_bytes()
    if path.suffix in {".md", ".py"}:
        content = data.decode("utf-8-sig")
        allowed_controls = "\r\n\t"
        assert not any(ord(c) < 32 and c not in allowed_controls for c in content), path
    pin = {"path": path.relative_to(root).as_posix(), "bytes": len(data), "sha256": sha(data)}
    if path.suffix == ".txt":
        content = data.decode("utf-8-sig")
        codes = sorted({ord(c) for c in content if ord(c) < 32 and c not in "\r\n\t"})
        if codes:
            pin["original_pdf_text_control_counts"] = {str(code): content.count(chr(code)) for code in codes}
    pins.append(pin)

links = []
for target in re.findall(r"\]\(([^)]+)\)", body.decode("utf-8-sig")):
    if target.startswith(("http:", "https:", "#")):
        continue
    assert (report.parent / target.split("#", 1)[0]).resolve().is_file(), target
    links.append(target)

combined = old + b"\n\n" + body
manifest = {
    "round": 234, "date": "2026-10-08", "status": "progress",
    "mathematical_program_runs": 0, "mathematical_program_failures": 0,
    "parameter_scans": 0, "new_pdf_downloads": 0, "git_mutations": 0, "lean_builds": 0,
    "documentary_archive_attempts": 3,
    "previous_documentary_attempts": "Both stopped before manifest/main writes because original PDF-extraction TXT font-control characters were rejected; validator now checks prose/code controls, records original TXT control counts and preserves all source bytes",
    "mathematical_status": "Sharp prefix LCD growth 3 and actual rank 3; all-map capacity bound and fixed-rational-basis basic tau floor 7/3 close this fixed complete three-dimensional source's basic CDT entrance; no new numerical irrationality or linear-independence theorem",
    "closed_scope": "Fixed u coordinate, fixed rational g, complete V=span_Q(u){1,E,J_g}, arbitrary fixed rational basis, basic Theorem2.5.1 arrays and all common meromorphic pullback maps",
    "not_closed": "Refined literal/integral arithmetic types, scale-dependent joint polynomial lattices, new coordinates or algebraic sources, genuine additional independent functions, or the numerical target itself",
    "global_review_cadence": {
        "last_formal": 232, "elapsed_rounds": 2, "default_next": 238,
        "window": [236, 240], "reset_by_this_round": False,
        "early_stop": "Two rounds without core-interface progress trigger tactical review; disproved branches are closed immediately",
    },
    "next_interface": "One bounded primary-theorem audit of refined arithmetic types and joint holonomy for a genuine gain beyond the closed basic entrance; compare old low-cost Tate enlargement failures before adding functions; no automatic map/basis/log-depth optimization",
    "review_scope": "Root actually full-read all six final mathematical notes and source scopes; A independently full-read final Root proofs, B proved fixed-basis invariance and reviewed unchanged mathematical report sections; only direction wording changed after B's report read",
    "source_scope": "Root current CDT physical PDF16-17,34,25 selected full pages and selected DLMF formulas; agents' other selected primary reads retained separately; no full-paper or global novelty certification",
    "version_difference": "Current 220-page CDT Theorem2.11.17 has three terms; fixed 218-page v2 has four. Difference recorded without inferring cause or invalidity",
    "repository_state": "No fresh Git/remote check; inherits round232 evidence only",
    "verification_scope": "Only new234 files, current report links, predecessor identity and preserved main prefix; no historical archive/producer or broad audit",
    "predecessor": {"path": previous.relative_to(root).as_posix(), "bytes": 6405, "sha256": previous_sha},
    "main_preserved_prefix": {"bytes": old_size, "sha256": old_sha},
    "appended_report": {"path": report.relative_to(root).as_posix(), "bytes": len(body), "sha256": report_sha},
    "main_after_append": {"path": main.relative_to(root).as_posix(), "bytes": len(combined), "sha256": sha(combined)},
    "report_links_checked": links, "new_pins": pins,
}
dest.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
main.write_bytes(combined)
assert main.read_bytes() == combined
print(json.dumps({
    "status": "PASS", "round": 234, "pins": len(pins), "report_links": len(links),
    "mathematical_runs": 0, "main_bytes": len(combined), "main_sha256": sha(combined),
    "manifest_bytes": dest.stat().st_size, "manifest_sha256": sha(dest.read_bytes()),
}, ensure_ascii=False))
