"""Archive one primary source; preserve the bytes of every existing PDF."""
from pathlib import Path
from datetime import datetime, timezone
import json
import fitz
import archive_global_literature_20261004 as base

ROOT = Path(__file__).resolve().parents[1]
CONFIG = ROOT/"literature/cdt_odd_background_sources_20261005.json"
MANIFEST = ROOT/"literature/manifest_cdt_odd_background_20261005.json"
base.PREVIOUS = {r["file"]:r for r in json.loads(
    MANIFEST.read_text(encoding="utf-8"))["sources"]} if MANIFEST.exists() else {}

def main():
    records = [base.archive(s) for s in json.loads(
        CONFIG.read_text(encoding="utf-8"))["sources"]]
    assert all(r["archive_status"] != "failed" for r in records), records
    out = ROOT/"research/cdt_odd_background_source_identity_20261005"
    out.mkdir(exist_ok=True)
    for rec in records:
        path = ROOT/"literature"/rec["file"]
        doc = fitz.open(path)
        doc[0].get_pixmap(matrix=fitz.Matrix(1.3,1.3), alpha=False).save(
            out/(path.stem+"_first.png"))
        old = base.PREVIOUS.get(rec["file"], {})
        rec["first_page_identity_visually_checked"] = (
            old.get("sha256") == rec["sha256"]
            and bool(old.get("first_page_identity_visually_checked")))
        rec["visual_identity_file"] = str(
            (out/(path.stem+"_first.png")).relative_to(ROOT)).replace("\\","/")
    MANIFEST.write_text(json.dumps({
        "as_of":"2026-10-05",
        "created_at_utc":datetime.now(timezone.utc).isoformat(),
        "sources":records}, ensure_ascii=False, indent=2)+"\n", encoding="utf-8")
    print(json.dumps([{"file":r["file"],"pages":r["pages"],"sha256":r["sha256"]}
                      for r in records], ensure_ascii=False))

if __name__ == "__main__":
    main()
