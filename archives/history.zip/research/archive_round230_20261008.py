"""One-shot documentary archive; no mathematical producer calls."""
from pathlib import Path
import hashlib
import json
import re

root = Path(__file__).resolve().parent.parent
main = root / "research/cdt_odd_background_progress_20261006.md"
report = root / "research/research_residue_projection_progress_round230_20261008.md"
previous = root / "literature/manifest_uniform_projection_round229_20261008.json"
dest = root / "literature/manifest_residue_projection_round230_20261008.json"
old_size = 571414
old_sha = "7b7e6e040785f7e37d15c5482ae51b38f65af545a43e6bf47094b599977860fb"
prev_sha = "ca2aaabf8c45b6c7a72ac83552dc10ce1783c0abd6723d661e6eb61172e86429"
report_sha = "70e62494d9f14d39ce1c02149f7eb508fd3bcb610a5aaade1d8807b69e890925"

def sha(data):
    return hashlib.sha256(data).hexdigest()

old, body = main.read_bytes(), report.read_bytes()
assert len(old) == old_size and sha(old) == old_sha, "Main prefix changed"
assert sha(previous.read_bytes()) == prev_sha, "Predecessor changed"
assert sha(body) == report_sha, "Report changed"
assert not dest.exists(), "Do not rerun a completed archive"

files = sorted({*root.joinpath("research").glob("*round230*20261008.*"),
                *root.joinpath("literature/relative_residue_sources_round230_20261008").glob("*")})
pins = []
for path in files:
    if not path.is_file():
        continue
    data = path.read_bytes()
    if path.suffix == ".md":
        text = data.decode("utf-8-sig")
        assert not any(ord(c) < 32 and c not in "\r\n\t" for c in text), path
    pins.append({"path": path.relative_to(root).as_posix(),
                 "bytes": len(data), "sha256": sha(data)})

links = []
for target in re.findall(r"\]\(([^)]+)\)", body.decode("utf-8-sig")):
    if target.startswith(("http:", "https:", "#")):
        continue
    assert (report.parent / target.split("#", 1)[0]).resolve().is_file(), target
    links.append(target)

combined = old + b"\n\n" + body
manifest = {
    "round": 230, "date": "2026-10-08", "status": "progress",
    "mathematical_program_runs": 1, "mathematical_program_failures": 0,
    "mathematical_producer": "Eight preselected exact finite-field cases, exit0; no infinite-rank claim",
    "document_selected_page_extractions": 1, "git_mutations": 0, "lean_builds": 0,
    "mathematical_status": "Complete p-residue convolution and exact rank reduction, conditional local denominator/nonzero, same-object analytic criterion proved; no new numerical irrationality theorem",
    "global_review_cadence": {"last_formal": 228, "next_default": 234,
                              "window": [232, 236], "reset_by_this_round": False,
                              "early_trigger": "Structural obstruction or two successive rounds without core-interface progress"},
    "next_interface": "Unbounded full rank of the actual residual stack, or boundary determinant nondivisibility; then complete all-place cost and real zeta/L target isolation",
    "verification_scope": "New document identities, report local links, predecessor identity and main preserved prefix only; no old producers, archives or historical pins rerun",
    "predecessor": {"path": previous.relative_to(root).as_posix(), "bytes": previous.stat().st_size, "sha256": prev_sha},
    "main_preserved_prefix": {"bytes": old_size, "sha256": old_sha},
    "appended_report": {"path": report.relative_to(root).as_posix(), "bytes": len(body), "sha256": report_sha},
    "main_after_append": {"path": main.relative_to(root).as_posix(), "bytes": len(combined), "sha256": sha(combined)},
    "source_scope": "One previously saved primary PDF reused; newly selected PDF2-5 text. Reading boundaries in A and Root receipts; no full-paper certification",
    "report_links_checked": links, "new_pins": pins,
}
dest.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
main.write_bytes(combined)
assert main.read_bytes() == combined
print(json.dumps({"status": "PASS", "round": 230, "pins": len(pins),
                  "report_links": len(links), "mathematical_runs": 1,
                  "main_bytes": len(combined), "main_sha256": sha(combined),
                  "manifest_bytes": dest.stat().st_size, "manifest_sha256": sha(dest.read_bytes())}, ensure_ascii=False))
