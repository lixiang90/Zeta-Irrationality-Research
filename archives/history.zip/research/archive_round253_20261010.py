"""One-shot documentary archive for253; no mathematical computation."""
from pathlib import Path
import hashlib
import json

ROOT = Path(__file__).resolve().parents[1]
assert ROOT == Path(r"E:\kimi-build\zeta5").resolve()
MANIFEST = ROOT / "literature/manifest_rv_chi8_round253_20261010.json"
assert not MANIFEST.exists(), "Completed253 archive must not be rerun"
PREVIOUS = ROOT / "literature/manifest_global_review_round252_20261010.json"
MAIN = ROOT / "research/cdt_odd_background_progress_20261006.md"
POLICY = ROOT / "research/research_global_review_policy.md"
REPORT = ROOT / "research/research_rv_chi8_progress_round253_20261010.md"
REVIEW = ROOT / "research/research_round253_rv_gate_review_20261010.md"
SOURCES = ROOT / "literature/rv_chi8_sources_round253_20261010"


def digest(data):
    return hashlib.sha256(data).hexdigest()


def pin(path):
    data = path.read_bytes()
    return {"path": path.relative_to(ROOT).as_posix(), "bytes": len(data), "sha256": digest(data)}


def verify(path, size, sha):
    data = path.read_bytes()
    assert len(data) == size and digest(data) == sha, str(path)
    return data


previous_data = verify(PREVIOUS, 11675, "567929b34a24ad6f7a737fe3516cca5a8a6b2e6d411cee882359dbb18ae30ad6")
previous = json.loads(previous_data)
assert previous["round"] == 252 and len(previous["files"]) == 36
assert previous["formal_global_review"]["last"] == 252
for item in previous["files"]:
    verify(ROOT / item["path"], item["bytes"], item["sha256"])
old_main = verify(MAIN, 723735, "4f565a48b7c99f7c2c0eab6084af5578af8d28b25d03328057196f948aa370f2")
old_policy = verify(POLICY, 21563, "b6f87ab4b7fe5810becd4706d82019debc30bb69b4984eb6e2b1ab10406cc32e")
report_data = verify(REPORT, 5913, "ae39da2f4d7090c0cc28c51c512975712c838f0f55cb7e1992da2d5890fd274a")
authors = [
    (ROOT / "research/rv_chi8_positive_root_rank_round253_20261010.md", 9888, "1448f96397dcd1468c91f7780fdcad4dbf7d8e9c030aa292e19c1117c516b0fc"),
    (ROOT / "research/rv_chi8_coefficient_intersection_round253_20261010.md", 7641, "361387718baeceddb10c13cd966c85ece002c0a6bc10eb7c30085e9ab9e5552c"),
    (ROOT / "research/rv_chi8_contiguous_rank_round253_20261010.md", 7244, "0278b174349e9ad6b27b19aaf0fe66c7edfbb4cecbcaf1d9f5c590bf9a101626"),
    (ROOT / "research/rv_chi8_reciprocity_gate_round253_20261010.md", 8159, "ea6e8e703f48c23177b93b1a1ff6cfc69ba4311e6370672a02113bb355058d19"),
]
review_data = REVIEW.read_bytes()
review_text = review_data.decode("utf-8-sig")
assert "PASS" in review_text and "256" in review_text and "254" in review_text
for path, size, sha in authors:
    verify(path, size, sha)
    assert sha in review_text, "Review must bind final mathematics identity"
assert digest(report_data) in review_text, "Review must bind final report"
for name in ["root", "alternative", "packet", "dual"]:
    assert (SOURCES / f"{name}_reading_scope.md").is_file()
assert "## 第253轮".encode("utf-8") not in old_policy
assert report_data not in old_main

policy_append = """

## 第253轮全尺度RV投影通过与唯一下一误差检验

固定252包n≥2、r0..4、tuple(10n+r,8n,8n,5n,10n)不变。实际Q系数的有限和因式化为正移位Euler算子；Rolle重数及Φ8四个非实根的degree矛盾证明首四列ALL n≥2秩4，去constant行秩3。因此constant intersection首关通过，不是有限n头或generic span。无新的数值无理性/线性无关性定理，goal active。

本轮选择R=Q/Λ的整数余数矩阵，v=adj(R余数)e0、v4=0，避免人工Λ³而完整P仍清整Λ。c=Λdet(R余数)非零；完整Gauss迹A−cL(2,χ−8)不追加conductor因子。已付全v/Q/P/A/c粗安全高度，但非primitive费用。c非零不能代替实际形式非零。

完整原I0−logz I1在固定n的∞衰减确定P为多项式部，给F(z)=−∫(−logt)Q(t)/(z−t)dt及Gauss实式A−cY=−∫(−logt)Q(t)(1+t²)/(1+t4)dt。包含全部原修正，另有2n完整正交条件。∞常数不uniform，正测度不保证Q常号；实际无界非零与统一净衰减仍未付。

经本轮真实核心变化，唯一254有界检验为同一v=adj(R)e0、v4=0实现的gcd(A,c)约分后误差预算；需要同对象统一净衰减与无界非零，或能改变该判断的核心证书。若无此证据，结束该默认实现窗口，回到数值出口比较；不自动开255prime/map/参数、新包或第五列优化，也不把粗upper失败说成所有RV方法不可能。已停Fricke、naive Gram和重复mixed源不重开。

最近正式252，完成本轮后计数1，下一正式256；本轮非正式全局轮且不reset。连续两轮核心停滞提前复盘、最迟八轮不变。四最终数学稿、主报告、四scope及唯一独审冻结后归档一次，保留252清单、35非policy文件及main/policy旧字节前缀。数学程序/有限头程序及证书/CAS/区间/Lean/prime/parameter/map/word扫描/外Git写/旧producer0；B有n=1的W(0..2)三项草算符号检查、不作为全n证明输入。Root一次二query metadata检索未采用新命题、团队新PDF/HTML下载0。
""".encode("utf-8")

# All identities and review preflight above precede the only append operations.
POLICY.write_bytes(old_policy + policy_append)
MAIN.write_bytes(old_main + b"\n\n" + report_data)
assert POLICY.read_bytes()[:len(old_policy)] == old_policy
assert MAIN.read_bytes()[:len(old_main)] == old_main
assert MAIN.read_bytes().count(report_data) == 1
for item in previous["files"]:
    if item["path"] != "research/research_global_review_policy.md":
        verify(ROOT / item["path"], item["bytes"], item["sha256"])

paths = {ROOT / item["path"] for item in previous["files"] if item["path"] != "research/research_global_review_policy.md"}
paths.update((ROOT / "research").glob("*round253*20261010*"))
paths.update(SOURCES.iterdir())
paths.add(POLICY)
manifest = {
    "round": 253,
    "date_completed": "2026-10-10",
    "classification": "progress",
    "previous_goal_turn_classification": "progress",
    "progress_kind": "All-n true RV coefficient rank; integer pure projection; complete Cauchy/Gauss real error and2n orthogonality; full safe heights",
    "goal_status": "active",
    "new_numerical_irrationality_or_independence_theorem": False,
    "global_novelty_or_full_lean_audit": False,
    "formal_global_review": {"last": 252, "this_round_is_formal": False, "counter_reset_this_round": False, "completed_rounds_since_last": 1, "next_scheduled": 256, "early_core_stagnation_rounds": 2, "maximum_interval": 8},
    "fixed_object": {"parameters": "n>=2, r=0..4: (10n+r,8n,8n,5n,10n)", "common_normalization": "d_(13n+4)d_(12n+4) z^(16n)(z-1)^(3n)", "chosen_projection": "v=adj(first4 R=Q/Lambda modPhi8)e0; v4=0", "all_n_rank4": True, "actual_numeric_nonzero_paid": False, "primitive_net_decay_paid": False},
    "next_unique_certificate": {"round": 254, "target": "Same fixed adj(R)e0 realization: primitive complete real-error budget", "primitive_pair": "a=A/gcd(abs(A),abs(c)); b=c/gcd(abs(A),abs(c))", "unpaid": "Uniform net decay and unbounded actual nonzero, or checkable core certificate changing admission", "automatic_extension": False, "stop": "No core budget-changing certificate in254 ends this default realization; compare numerical outlets without automatic255 scans or alternative-vector/package optimization"},
    "stopped_default_windows": previous["stopped_default_windows"],
    "runs": {"mathematics": 0, "finite_n_programs_or_certificates": 0, "hand_checks_by_B": "n=1 W(0..2), three scratch signs only; not all-n proof input", "cas_or_interval": 0, "prime_parameter_map_word_scans": 0, "lean": 0, "external_git_mutations": 0, "old_archive_producers": 0, "this_documentary_archive": 1},
    "sources": {"root_search_calls": 1, "root_search_queries": 2, "search_metadata_only": True, "new_pdf_downloads_by_team": 0, "new_html_downloads_by_team": 0, "new_adopted_primary_theorems": 0, "whole_paper_reading_claim": False, "precise_scope": "Four separately pinned reading scopes; old published RV Theorem2.1 remains input"},
    "previous_manifest": pin(PREVIOUS),
    "previous_manifest_nonpolicy_files_preserved": 35,
    "report": pin(REPORT),
    "independent_math_and_report_review": pin(REVIEW),
    "previous_policy": {"bytes": len(old_policy), "sha256": digest(old_policy)},
    "new_policy": pin(POLICY),
    "previous_main": {"bytes": len(old_main), "sha256": digest(old_main)},
    "new_main": pin(MAIN),
    "files": [pin(path) for path in sorted(paths) if path.is_file()],
}
MANIFEST.write_text(json.dumps(manifest, ensure_ascii=False, indent=2)+"\n", encoding="utf-8")
assert PREVIOUS.read_bytes() == previous_data
assert REVIEW.read_bytes() == review_data
print(json.dumps({"status": "PASS", "numeric_theorem": False, "all_n_rank4": True, "next_unique_gate": 254, "next_formal_review": 256, "completed_since_formal": 1, "files": len(manifest["files"]), "manifest": pin(MANIFEST), "main": pin(MAIN), "policy": pin(POLICY)}, ensure_ascii=False))
