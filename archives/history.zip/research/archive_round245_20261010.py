"""One-shot documentary archive of round245. No mathematics is executed."""
from pathlib import Path
import hashlib
import json

root = Path(__file__).resolve().parent.parent
assert root == Path('E:/kimi-build/zeta5').resolve()
main = root / 'research/cdt_odd_background_progress_20261006.md'
report = root / 'research/research_cm_admission_progress_round245_20261010.md'
policy = root / 'research/research_global_review_policy.md'
previous = root / 'literature/manifest_global_review_cm_log_round244_20261009.json'
sources = root / 'literature/cm_admission_sources_round245_20261010'
destination = root / 'literature/manifest_cm_admission_recovery_round245_20261010.json'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def pin(path):
    data = path.read_bytes()
    return {'path': path.relative_to(root).as_posix(),
            'bytes': len(data), 'sha256': sha(data)}


assert not destination.exists(), 'Never rerun a completed documentary producer'
old = main.read_bytes()
assert len(old) == 672840
assert sha(old) == 'c9843eebb2086796b82bdb353471f8175b7b7bd94c122b4b4a6d0aa65b494b5d'
assert sha(previous.read_bytes()) == '1b19ca015069e37c2dd1add4ad5a6e77dbe0bc29f54fafef93f177fb3c645f55'

expected = {
    'research/cm_actual_rank_round245_20261010.md':
        (7188, 'fd02e917049de96221007fe6a6edb62615a55b785785b201979cf14338d18cec'),
    'research/cm_complete_denominator_types_round245_20261010.md':
        (6406, 'bb935f5caedd0a34d58221638d263a5d92c308a51f8137b6e3be1a1e3efef459'),
    'research/cm_transported_leaves_round245_20261010.md':
        (7964, '8fce04cca365c540990f7256139932e1366de6899e0360b63178fe33283927ed'),
    'research/cm_primary_evaluation_audit_round245_20261010.md':
        (8843, '5cb986b9652ffe1ef071dd94acd8de8ac6bbbd5f99ca8f8f18d86b68393d2233'),
    'research/cm_modular_lift_review_round245_20261010.md':
        (9372, 'b2c3e63a48a8ae05612ce51be7bacfeefb24fd21fcb4c35e8ca039e71c28e164'),
    'research/research_cm_admission_progress_round245_20261010.md':
        (8560, 'a62dfb8713aeb253cbbd66bd0c1f1d22d11d6339526f175782a8e6534622529f'),
}
for path, (length, digest) in expected.items():
    item = pin(root / path)
    assert item['bytes'] == length and item['sha256'] == digest, path

review_targets = {
    'research/research_round245_cm_actual_rank_review_20261010.md':
        'research/cm_actual_rank_round245_20261010.md',
    'research/research_round245_complete_types_review_20261010.md':
        'research/cm_complete_denominator_types_round245_20261010.md',
    'research/research_round245_cm_leaf_review_20261010.md':
        'research/cm_transported_leaves_round245_20261010.md',
    'research/research_round245_cm_modular_lift_review_20261010.md':
        'research/cm_modular_lift_review_round245_20261010.md',
    'research/research_round245_cm_report_review_20261010.md':
        'research/research_cm_admission_progress_round245_20261010.md',
}
for receipt, target in review_targets.items():
    text = (root / receipt).read_text(encoding='utf-8-sig')
    assert 'PASS' in text and expected[target][1] in text, receipt

policy_data = policy.read_bytes()
previous_policy = {
    'bytes': 7884,
    'sha256': 'd3fe3938af18fda00c15c8aa2c29e37c846ae2dfa67f84872469a4f36116a80c',
}
assert sha(policy_data[:7884]) == previous_policy['sha256']
assert len(policy_data) > 7884 and '第245轮' in policy_data[7884:].decode('utf-8')
assert '248' in policy_data[7884:].decode('utf-8')
assert (sources / 'root_reading_scope.md').is_file()
records = set((root / 'research').glob('*round245*20261010.*'))
records.update(p for p in sources.rglob('*') if p.is_file())
records.add(policy)
pins = [pin(p) for p in sorted(records)]
body = report.read_bytes()
combined = old + b'\n\n' + body
assert len(combined) == 681402
manifest = {
    'round': 245,
    'date_completed': '2026-10-10',
    'classification': 'progress',
    'previous_goal_turn_classification': 'progress',
    'goal_status': 'active',
    'new_numerical_irrationality_or_independence_theorem': False,
    'formal_global_review': {
        'last': 244, 'this_round_is_formal': False,
        'completed_rounds_since_last': 1,
        'counter_reset_this_round': False, 'next_scheduled': 248,
    },
    'resource_decision': {
        'current_original_coordinate_basic_CM_entry': 'stop immediately',
        'reason': 'Every meromorphic pullback of H_g or S_g recovers F and has derivative at zero at most one.',
        'remaining_map_prime_or_basis_tuning_in_closed_entry': False,
        'applies_to_all_CDT_or_all_CM_methods': False,
        'next_round_gate': 'Actual target-sensitive forcing/recovery and numerical period projection before maps or arithmetic tuning.',
    },
    'object': {
        'target': '735 L(2, chi_-7) - 86 pi^2',
        'native_CM_point': '1/4096',
        'source': 'H_g(z) = integral_0^z (G(t) + g F(t))/(1-4096 t) dt',
        'coordinate': 'original z',
    },
    'paid': [
        'Actual rank seven of the CM source, minimal scalar order seven for H_g, and rank eight after adding one.',
        'All-prime-power full-prefix arithmetic clearers with safe exponents zero, two and three.',
        'Complete literal CDT arithmetic types: tau7 = 93/49; tau8 = 111/64.',
        'Selected primary CM evaluation chain and required Epstein lattice values checked within recorded scope.',
        'An explicit Fricke transported bad leaf, and an independent five-leaf infinity certificate.',
        'Corrected modular-lambda covering argument and exact F function-germ stabilizer.',
        'All legal original-coordinate holomorphic maps with meromorphic F pullback have derivative at zero at most one.',
        'Explicit rational differential recovery of F from S_g and H_g, so their meromorphic pullbacks obey the same bound.',
        'Independent full paper reviews of actual rank, arithmetic types, five-leaf certificate, modular lift and final report.',
    ],
    'not_paid': [
        'A new numerical irrationality or linear-independence theorem, or a solution for all odd zeta values.',
        'A different actual target-sensitive source that escapes this recovery obstruction and passes a strict criterion.',
        'All upstream modular or CM theory independently certified, or full Lean/kernel verification.',
        'A coordinate-independent or all-method impossibility theorem, or minimal arithmetic fee lower bounds.',
    ],
    'bounds': {
        'analytic_derivative_cap': '1',
        'cap_covers': ['F-only', 'S_g-only', 'H_g-only', 'full seven/eight-row source'],
        'g_dependence': 'none',
        'tau7_safe_literal_type': '93/49',
        'tau8_safe_literal_type': '111/64',
        'arithmetic_types_are_necessary_lower_bounds': False,
        'sharp_cap_attainment_claimed_for_H_or_S': False,
    },
    'runs': {
        'mathematics': 0, 'cas_or_interval': 0,
        'prime_parameter_or_map_scans': 0, 'lean': 0,
        'external_git_mutations': 0, 'old_archive_producers': 0,
        'this_documentary_archive': 1,
    },
    'source_reading_scope': 'Per-reader scope files identify exact selected pages and formulas. Saved whole HTML/PDF carriers are not full-proof certifications. Chiang misprinted triangle and transformation were corrected explicitly.',
    'previous_manifest': pin(previous),
    'report': pin(report),
    'previous_policy': previous_policy,
    'new_policy': pin(policy),
    'previous_main': {'bytes': len(old), 'sha256': sha(old)},
    'new_main': {'path': main.relative_to(root).as_posix(),
                 'bytes': len(combined), 'sha256': sha(combined)},
    'files': pins,
}
main.write_bytes(combined)
with destination.open('x', encoding='utf-8', newline='\n') as stream:
    json.dump(manifest, stream, ensure_ascii=False, indent=2)
    stream.write('\n')
assert main.read_bytes()[:len(old)] == old
assert main.read_bytes()[len(old):] == b'\n\n' + body
for record in pins:
    assert pin(root / record['path']) == record
print(json.dumps({'status': 'PASS', 'manifest': pin(destination),
                  'main': pin(main), 'pinned_files': len(pins),
                  'formal_review_next': 248}, ensure_ascii=False))
