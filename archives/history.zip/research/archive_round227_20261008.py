"""One-shot documentary freeze; no mathematical producer is imported or run."""
from pathlib import Path
from hashlib import sha256
import json
import re

ROOT = Path(__file__).resolve().parents[1]
MAIN = 'research/cdt_odd_background_progress_20261006.md'
REPORT = 'research/research_pade_route_stop_round227_20261008.md'
PREVIOUS = 'literature/manifest_cdt_pade_ramified_admission_round226_20261008.json'
OUTPUT = 'literature/manifest_cdt_pade_route_stop_round227_20261008.json'
SOURCE_DIRS = [
    'literature/pade_admission_stop_sources_round227_20261008',
    'literature/pade_all_place_budget_sources_round227_20261008',
    'literature/pade_fixed_prime_sources_round227_20261008',
    'literature/pade_ramified_capacity_sources_round227_20261008',
]
FINAL_REVIEW_PINS = [
    ('research/research_round227_ramified_capacity_diagnostic_review_20261008.md', 5681,
     '4c59550e8c853a493347528b14f02dda395b577174eae68b4de7d016b236c30f'),
    ('research/research_round227_fixed_three_content_review_20261008.md', 4822,
     '4d90a069174f9b747dec682c78204b6dce258b141a2ea4ac35de19d05cb9e585'),
    ('research/research_round227_report_review_20261008.md', 8783,
     '9ff205acef21c67df24087ea4081fc0835553f4f4dbb69560724e89e27a33c4f'),
]  # Root actually FULL read all final independent receipts before freezing.


def identity(relative):
    data = (ROOT / relative).read_bytes()
    return {'path': relative, 'bytes': len(data), 'sha256': sha256(data).hexdigest()}


def require(relative, length, digest):
    item = identity(relative)
    assert (item['bytes'], item['sha256']) == (length, digest), item
    return item


assert not (ROOT / OUTPUT).exists(), 'Completed archive must not be rerun.'
assert len(FINAL_REVIEW_PINS) == 3, 'Final A/C, B/A and C/report FULL receipts required.'
require(PREVIOUS, 54068, '3499c408deda00975b3f434cb8f9eab7c797a3fb9d1c0ded89277ae5d4359305')
previous = json.loads((ROOT / PREVIOUS).read_text(encoding='utf-8'))
old_checked = [require(p['path'], p['bytes'], p['sha256'])
               for p in previous['pins'] if p['path'] != MAIN]
assert len(old_checked) == 193
prefix = (ROOT / MAIN).read_bytes()
assert len(prefix) == 550583
assert sha256(prefix).hexdigest() == '47f1293c3794091e88e3a1e2ed0a9c6c635730e11dcc84011a605a878648436d'

expected = '''
research/pade_fixed_three_content_gate_round227_20261008.md 10209 50ff990271bdb56653e18b93838058e3c893ed138fcb86f9a5a1703e4f046b8c
research/pade_all_place_budget_round227_20261008.md 11436 17b73b07c1b9ad106d9f2cbdab14c2530777632aabc87f6110a62cee071f6e5f
research/pade_ramified_leaf_capacity_diagnostic_round227_20261008.md 11815 458f934a825ac213cafbd47943f8825119f973876759929497ad3b61405ee15b
research/pade_route_stop_and_global_inputs_round227_20261008.md 4834 9f50778ce3a1962d2aee289b63d5557ffd7aa3d79e9593dcf4578187b9c24a1c
research/research_pade_route_stop_round227_20261008.md 5871 b7031454b2434a7b7901733e65bcfbccd0ff3b13442827444b38f6ee3dbf5e12
research/research_round227_root_direction_review_20261008.md 5873 f1b6ff5f60566eb5db12a799115d9cf76ad53eb91a6195d79a70491a814bf911
research/research_round227_root_math_review_20261008.md 5023 b09d5296e709145dca94cc787e8e2e5e3fadedf81c4bd5b4082bfbb7cd9d2ef3
literature/pade_admission_stop_sources_round227_20261008/root_reading_scope.md 3147 1f5df097772de18f90fa77f2f058b19bf7c6976d1dc58cda3bd629722bb8309a
literature/pade_all_place_budget_sources_round227_20261008/packet_reading_scope.md 4116 96b326d1c94c3fbe7ed613eed53c6091c52beb0b18f073f4806c2058ceaabca3
literature/pade_fixed_prime_sources_round227_20261008/lambert_reading_scope.md 4243 474764e59eb2634ca6520b80146e828f86235dbbb02578c91c51aedaf6eeeae4
literature/pade_ramified_capacity_sources_round227_20261008/dual_reading_scope.md 6691 496cd0e08080a25120618895d8ae6d17175628e3f1274b0f1d4e7ceb066ce613
'''
pins = {p['path']: p for p in old_checked}
pins[PREVIOUS] = identity(PREVIOUS)
new_paths = []
for line in expected.splitlines():
    if line.strip():
        relative, length, digest = line.split()
        pins[relative] = require(relative, int(length), digest)
        new_paths.append(relative)
for relative, length, digest in FINAL_REVIEW_PINS:
    pins[relative] = require(relative, length, digest)
    new_paths.append(relative)
for directory in SOURCE_DIRS:
    for file in sorted((ROOT / directory).rglob('*')):
        if file.is_file():
            relative = file.relative_to(ROOT).as_posix()
            pins[relative] = identity(relative)
            new_paths.append(relative)
new_paths = sorted(set(new_paths))
assert len([p for p in new_paths if p.endswith('.pdf')]) == 4
assert len([p for p in new_paths if p.endswith('.txt')]) == 10
assert not any(p.endswith(('.html', '.tex')) for p in new_paths)

links = []
new_mds = [p for p in new_paths if p.endswith('.md')]
for relative in new_mds:
    content = (ROOT / relative).read_text(encoding='utf-8')
    assert not any(ord(c) < 32 and c not in '\n\r\t' or ord(c) == 127 for c in content), relative
    for target in re.findall(r'\[[^\]\n]*\]\(([^)\n]+)\)', content):
        target = target.strip().strip('<>').split('#', 1)[0]
        if re.match(r'^(?:https?://|app://)', target):
            continue
        if Path(target).suffix.lower() not in {'.md', '.pdf', '.json', '.txt', '.py', '.png', '.tex'}:
            continue
        resolved = ((ROOT / relative).parent / target).resolve()
        assert resolved.is_relative_to(ROOT), (relative, target)
        link_path = resolved.relative_to(ROOT).as_posix()
        assert resolved.is_file() or link_path == OUTPUT, (relative, target)
        links.append({'source': relative, 'target': link_path})
        if resolved.is_file() and link_path not in pins and link_path != MAIN:
            pins[link_path] = identity(link_path)

report = (ROOT / REPORT).read_bytes()
main_final = prefix + b'\n\n' + report
(ROOT / MAIN).write_bytes(main_final)
assert (ROOT / MAIN).read_bytes() == main_final
pins[MAIN] = identity(MAIN)
script = Path(__file__).relative_to(ROOT).as_posix()
pins[script] = identity(script)
record = {
    'round': 227, 'date': '2026-10-08', 'goal_status': 'active',
    'new_numerical_theorem': False,
    'round_outcome': 'Actual fixed3 content and centered meromorphic cap for original A7; all finite-place Taylor-paid strict negative budget for existing arrays; exact all-leaf quantifier counterexample with energy and arithmetic cost. Fixed packet is now a structural tool, not the default numerical route.',
    'fixed_packet_status': 'structural_tool_not_default_numeric_route',
    'navigation': {
        'last_formal_global_review': 222, 'next_normal_global_review': 228,
        'allowed_window': [226, 230], 'default_review_interval_completed_rounds': 6,
        'user_review_interval_completed_rounds': [4, 8],
        'early_triggers': ['structural cap/counterexample', 'two rounds without core interface advance'],
        'this_round_has_core_interface_advance': True,
        'this_round_is_not_a_comprehensive_global_literature_review': True,
        'stop_rule_applied': True,
        'next_task': 'Formal global comparison228: repository proof mechanisms with fresh status/source checks; controlled integral models in restricted period families; lower-cost new zeta/L/period-combination targets with novelty and explicit next proof interface.',
        'reactivation_gate': 'Concrete same-target complete relation/head, shared legal map, all-place true energy and complete costs with strict positive margin, or a proved genuinely cheaper complete integral model. No raw-univalent, safe166/9 or formal-spectrum refinement without that new object.'
    },
    'completed_math': [
        'Original A7 at n=2*3^e has exact v3=6 for every e>=0, plus exact normalized unit congruence; no sequence sampling.',
        'Native F7 has Taylor radius1 and, using the actual ordinary ODE plus no-pole/factorization argument, no centered rigid meromorphic continuation beyond1. Only sources retaining/recovering F7 inherit its affine3 cap.',
        'Nonzero rational integer-cleared coefficients obey the product-formula total Taylor-radius budget sup_P sum_p log R_p <= log T+sigma.',
        'Existing safe two-row and three-row arrays have strictly negative all-place margin for univalent arch maps and every finite nonlinear map whose image lies in the original H Taylor disc. Not a primitive-cost or all-map no-go.',
        'Arbitrary same-object S-integer scalar/unit normalization transports full legal place families and preserves L/E/margin; almost-all-unit maps are rectified without changing finite approximation radii.',
        'Exact inverse cubic with irreducible S3 monodromy and native square-root branches admits simple regular-leaf fibers and unbounded derivatives; actual energy limits rank3 gain and fixed3 content prevents free finiteLCM admission.',
        'Conditional three-value orbifold and unique-native0 caps remain conditional; no full-leaf hypothesis or positive actual packet model was paid.'
    ],
    'remaining_gates': [
        'new target/source with checked numerical novelty and positive complete margin',
        'quantitative complete integral model rather than overconvergent representation alone',
        'actual target-specific finite-place meromorphy or genuinely lower joint/primitive cost if fixed packet is revisited',
        'full reachable-leaf connection data and true ramified-map energy if that route is revisited',
        'new numerical irrationality or linear-independence theorem'
    ],
    'execution_ledger': {
        'mathematical_program_runs': 0, 'failed_mathematical_runs': 0,
        'CAS': 0, 'actual_sequence_samples': 0, 'parameter_or_prime_scans': 0,
        'PSLQ': 0, 'numerical_integrations': 0, 'root_solver_or_matrix_runs': 0,
        'old_proof_producer_reruns': 0, 'Lean_builds': 0, 'Git_mutations': 0,
        'new_repository_status_check': False, 'new_PDF_downloads': 4,
        'new_primary_selected_TXT': 8, 'exact_selected_TXT_copies': 2,
        'new_HTML_archives': 0, 'new_TEX_archives': 0,
        'documentary_operations': 'Primary download/extraction and selected-source reading, paper draft/review, identities/links/controls, one-shot append/freeze. No mathematical producer imported or executed.'
    },
    'source_claim_policy': 'Root FR PDF1-6/19-20 and DR PDF1-6 complete selected texts only, independently read by C; not full27/20-page proof audits. A official p-adic course PDF20-22/26-28; C McMullen PDF182-188 and CDT23-27; B complete cached CDT ICM3-8/fixed-v2 selected statements. Original PDFs archived, no visual/full-PDF/Lean/current-cloud verification claimed.',
    'independent_review': {
        'A_fixed3_content_mero_cap': 'Root and B actual FULL independent paper PASS',
        'B_full_place_budget': 'Root actual FULL independent paper PASS after discrete Q3 sufficient-threshold correction',
        'C_leaf_counterexample_energy_cost': 'Root and A actual FULL independent paper PASS',
        'Root_route_and_primary_scope': 'C actual FULL independent PASS with complete FR/DR selected statements',
        'report': 'C actual FULL independent PASS at final pinned identity'
    },
    'predecessor': {'manifest': identity(PREVIOUS), 'immutable_pins_checked': len(old_checked),
                    'mutable_main_excluded_from_old_final_hash': True},
    'main_append': {'preserved_prefix_bytes': len(prefix), 'preserved_prefix_sha256': sha256(prefix).hexdigest(),
                    'append_separator_hex': '0a0a', 'appended_report': identity(REPORT), 'final': identity(MAIN)},
    'verification': {'control_character_documents': len(new_mds), 'controls': 'PASS',
                     'local_links': links, 'links': 'PASS including planned manifest after creation'},
    'pins': sorted(pins.values(), key=lambda p: p['path'])
}
(ROOT / OUTPUT).write_text(json.dumps(record, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
for link in links:
    assert (ROOT / link['target']).is_file(), link
for item in record['pins']:
    require(item['path'], item['bytes'], item['sha256'])
require(PREVIOUS, 54068, '3499c408deda00975b3f434cb8f9eab7c797a3fb9d1c0ded89277ae5d4359305')
print(json.dumps({'manifest': identity(OUTPUT), 'main': identity(MAIN), 'pins': len(record['pins']),
                  'local_links': len(links), 'controls_md': len(new_mds),
                  'predecessor_immutable_pins': len(old_checked), 'checks': 'PASS'}, ensure_ascii=False))
