"""Preserve two selected original PDFs and render an identity contact sheet."""
import concurrent.futures
import json
from datetime import datetime, timezone
from pathlib import Path
import fitz
from PIL import Image, ImageDraw
import archive_global_literature_20261004 as base

ROOT = Path(__file__).resolve().parents[1]
CONFIG = ROOT / 'literature/period_holonomy_sources_20261005.json'
MANIFEST = ROOT / 'literature/manifest_period_holonomy_20261005.json'
base.PREVIOUS = ({r['file']: r for r in json.loads(MANIFEST.read_text(encoding='utf-8'))['sources']}
                 if MANIFEST.exists() else {})

def main():
    config = json.loads(CONFIG.read_text(encoding='utf-8'))
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
        records = list(pool.map(base.archive, config['sources']))
    assert all(r['archive_status'] != 'failed' for r in records), records
    thumbs = []
    outdir = ROOT / 'research/period_holonomy_source_identity_20261005'
    outdir.mkdir(exist_ok=True)
    for r in records:
        doc = fitz.open(ROOT / 'literature' / r['file'])
        pix = doc[0].get_pixmap(matrix=fitz.Matrix(0.8,0.8), alpha=False)
        im = Image.frombytes('RGB', [pix.width,pix.height], pix.samples)
        im.thumbnail((630,840))
        panel=Image.new('RGB',(680,920),'white')
        panel.paste(im, ((680-im.width)//2, 45))
        ImageDraw.Draw(panel).text((12,10),r['file'],fill='black')
        thumbs.append(panel)
    contact = Image.new('RGB',(680*len(thumbs),920),'#dddddd')
    for i,im in enumerate(thumbs): contact.paste(im,(680*i,0))
    rel=Path('research/period_holonomy_source_identity_20261005/contact.png')
    contact.save(ROOT/rel)
    for r in records:
        old=base.PREVIOUS.get(r['file'],{})
        r['first_page_identity_visually_checked'] = bool(old.get('sha256')==r['sha256'] and old.get('first_page_identity_visually_checked'))
        r['visual_identity_contact_sheet']=rel.as_posix()
    data={'as_of':'2026-10-05','created_at_utc':datetime.now(timezone.utc).isoformat(),
          'validation':'Original bytes; PDF signature; pypdf pages; SHA-256; rendered first pages',
          'sources':records}
    MANIFEST.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps([{'file':r['file'],'status':r['archive_status'],'pages':r['pages'],'sha256':r['sha256']} for r in records],ensure_ascii=False))

if __name__ == '__main__': main()
