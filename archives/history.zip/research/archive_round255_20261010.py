"""One-shot documentary archive255. No mathematical computation or external Git writes."""
from pathlib import Path
import hashlib
import json

ROOT = Path(__file__).resolve().parents[1]
assert ROOT == Path(r"E:\kimi-build\zeta5").resolve()
MANIFEST = ROOT / "literature/manifest_architecture_round255_20261010.json"
assert not MANIFEST.exists(), "Completed255 archive must not be rerun"
PREVIOUS = ROOT / "literature/manifest_rv_chi8_budget_round254_20261010.json"
MAIN = ROOT / "research/cdt_odd_background_progress_20261006.md"
POLICY = ROOT / "research/research_global_review_policy.md"
REPORT = ROOT / "research/research_architecture_progress_round255_20261010.md"
REVIEW = ROOT / "research/research_round255_architecture_review_20261010.md"
SOURCES = ROOT / "literature/architecture_sources_round255_20261010"


def digest(data):
    return hashlib.sha256(data).hexdigest()


def pin(path):
    data = path.read_bytes()
    return {"path": path.relative_to(ROOT).as_posix(), "bytes": len(data), "sha256": digest(data)}


def verify(path, size, sha):
    data = path.read_bytes()
    assert len(data) == size and digest(data) == sha, str(path)
    return data


previous_data = verify(PREVIOUS, 17208, "cf327bff398ba07f22e763a61dfab6bfb89e3a84d53e5ddd3f45f063c900fdb1")
previous = json.loads(previous_data)
assert previous["round"] == 254 and len(previous["files"]) == 60
assert previous["formal_global_review"]["last"] == 252
for item in previous["files"]:
    verify(ROOT / item["path"], item["bytes"], item["sha256"])
old_main = verify(MAIN, 735227, "70b730d22f73f2d42f921ba3528615996ad5ca3ecc617c40da842e74888963e1")
old_policy = verify(POLICY, 25806, "eb61f46892987fc7dd514222ca38ff146e19dae06514994d32b3a895904c3b87")
report_data = verify(REPORT, 7056, "cf025fee62053dcfe5ed80c080a6bbe471f3f19982781f66a67f778542f01534")
authors = [
    ("research_architecture_gate_round255_20261010.md", 8654, "1c5820cce52ef6bfa36ebaaaaf018662ab9d743ea5ad3432aac6808b6004e1f3"),
    ("research_catalan_architecture_round255_20261010.md", 14434, "4f4d47ae4ca25aa7317d42ed15a0032e1d56bbb7dbe66ab368ab6740a3efa8bd"),
    ("research_holonomy_architecture_round255_20261010.md", 13378, "0f0d5651d857ac07a137defe629286658ea151a81e8ca52fe940383dd6c60324"),
    ("research_nonfricke_architecture_round255_20261010.md", 10350, "f5c9d5dab5b514e9e37abafe4792c6e5d9567f56a7dd6e73a4d445b8398339cc"),
]
review_data = verify(REVIEW, 8381, "fda89d31b8b079c7012c503bcb84e8fca0beb29cc7f5edb2026967bf9b255cb0")
review_text = review_data.decode("utf-8-sig")
assert "PASS" in review_text and "256" in review_text and "255" in review_text
for name, size, sha in authors:
    verify(ROOT / "research" / name, size, sha)
    assert sha in review_text
assert digest(report_data) in review_text
for name, size, sha in [
    ("root", 2940, "df52451d96a66f46d8a9322810840a293260fa5aa32d1409d8ec892e3fe89a85"),
    ("alternative", 4458, "1d7ed6aa1acee616654dd4111dfb20fdbab9878d68bab1c7e94381003991bc07"),
    ("packet", 6424, "afea24a5689aeef223d835791ac80c538b60ce670d9a4703064fd896a4df0817"),
    ("dual", 3110, "004fa4dc52ac3ffeaae442c3849c5044036f6b40e33d103c405966fba0501030"),
]:
    verify(SOURCES / f"{name}_reading_scope.md", size, sha)
root_scope = (SOURCES / "root_reading_scope.md").read_text(encoding="utf-8")
assert authors[2][2] in root_scope and "独立数学复核" in root_scope
assert "## 第255轮".encode("utf-8") not in old_policy
assert report_data not in old_main

policy_append = """

## 第255轮跨架构结算与完整有理两sheet候选

每4轮默认作正式全局回顾、最迟8轮、连续2轮核心停滞提前回顾的规则保持。本轮比较同一实际出口的period、完整整数格、关系点无界非零、全finite费用及全real能量；不把新增局部引理数量当延窗理由，也不把所选upper失败当actual lower。没有新的数值ζ/L定理，goal active。

旧fixed RV adj(R)e0/v4=0、Fricke、naive χ−8 rank-one Gram、截区重复mixed及旧K5/β4等局部窗口不因此重开。K5/β4有完整目标与关系点无界非零资产但本轮无新宏观净费定理；χ−7两个对象的接口不得拼接；原M0,10相对类到全Padé匹配未付。多源相位Sρ<k为真实代数独立k源的条件工具，不给微分jets免费k；UDClevelraising需finite-index modular、有界分母和原group条件。

本轮真正新增：完整Catalan矩、参数a=1/√2的Cauchy核1−ats，绕+1一次实际monodromy T及3+T组合，三个完整starts16Y、0、9ζ2，Y=L2χ−8；原生N(i,j)=a^i(3+T)M(i,j)的全数组heads在Q。整数接触xP/√(1−2x²)−D=O(x^L)使所有raw j<L在Q+QY。固定prototype P_r=2^n x2r及其<2n companion jet为整数，选even j=2s时目标Y系数det=(16·2^n)^n≠0，ALL n≥1。此目标可见rank不是关系点actualdet非零，也不继承Catalanprime seeds/energystrict。

唯一下一256首关冻结同a/3+T/nativeN/prototype及完整raw pool：双变量actual生成芽/合法contour匹配，所有规模与全部头的Z-prefix整数模型、log q_H=O(H)，完整行尺度费用。通用factorial的O(HlogH)清整upper不作为quadratic总费准入。若未匹配实际contour或全prefix/行尺度未付，结束候选默认投入；不自动扫prime/参数/maps/sheetwords。通过后仍须另付关系点无界非零、足够强全finite费及同两sheet real能量。

last正式252，完成本轮后计数3，下一正式256；255跨架构比较不reset。四最终数学稿、主报告、四actual scopes及唯一独审后仅归档一次；254全部60pins先验证，59非policy旧files与main/policy旧bytes前缀保留。数学程序/有限n头/CAS/区间/Lean/prime/parameter/map/word扫描/外Git写/旧producer0；仅文档页段提取、来源复制和散列。Root两web六queries（一个错误string展开未采用，一个metadata），C一web三queries及两primary摘要页，团队新PDF/HTML下载0；不声称全球新颖性核定。
""".encode("utf-8")

# Mutations start only after all previous-state, author and independent-review checks.
POLICY.write_bytes(old_policy + policy_append)
MAIN.write_bytes(old_main + b"\n\n" + report_data)
assert POLICY.read_bytes()[:len(old_policy)] == old_policy
assert MAIN.read_bytes()[:len(old_main)] == old_main
assert MAIN.read_bytes().count(report_data) == 1
for item in previous["files"]:
    if item["path"] != "research/research_global_review_policy.md":
        verify(ROOT / item["path"], item["bytes"], item["sha256"])
paths = {ROOT / item["path"] for item in previous["files"] if item["path"] != "research/research_global_review_policy.md"}
paths.add(PREVIOUS)
paths.update((ROOT / "research").glob("*round255*20261010*"))
paths.update(SOURCES.iterdir())
paths.add(POLICY)
manifest = {
    "round": 255,
    "date_completed": "2026-10-10",
    "classification": "progress",
    "goal_status": "active",
    "progress_kind": "Cross-architecture investment settlement; full parameter-monodromy period projection; native rational array; integer contact and all-scale target coefficient rank; conditional multisource phase",
    "new_numerical_irrationality_or_independence_theorem": False,
    "global_novelty_or_full_lean_audit": False,
    "formal_global_review": {"last": 252, "this_round_is_formal": False, "counter_reset_this_round": False, "completed_rounds_since_last": 3, "next_scheduled": 256, "early_core_stagnation_rounds": 2, "maximum_interval": 8},
    "paid_this_round": ["Full Cauchy parameter source and actual three starts", "Actual 3+T sheet identity eliminates pi*log and pi channels", "Native N=a^i barM all-head rational array", "Full raw contact to Q+QY", "Integer n-row prototype and target coefficient determinant (16*2^n)^n for all n>=1", "Conditional multisource exact prefix flag and S*rho<k phase", "UDC direct Li_s local-monodromy obstruction"],
    "strict_status": {"actual_numeric_nonzero_paid_for_new_source": False, "complete_prefix_integer_budget_paid_for_new_source": False, "complete_net_energy_paid_for_new_source": False, "target_coefficient_rank_is_numeric_nonzero": False},
    "stopped_default_windows": previous["stopped_default_windows"],
    "next_unique_work": {"round": 256, "formal_global_review_also_required": True, "fixed_target": "Y=L(2,chi_-8)", "fixed_object": "a=1/sqrt2, actual parameter loop at +1, 3+T, N=a^i barM; integer monomial contact prototype; all raw j<2n", "scope": "Full bivariate generating germ/contour match and all-prefix Z integer model log(q_H)=O(H), including complete row scales", "stop_if": ["Only formal recurrence remains without actual common contour", "Complete raw prefix or row-scale fees unavailable", "Only generic factorial O(H log H) clearing certified"], "automatic_parameter_prime_map_or_sheet_extension": False},
    "runs": {"mathematics": 0, "finite_n_hand_heads_programs_or_certificates": 0, "cas_or_interval": 0, "prime_parameter_map_word_scans": 0, "lean": 0, "external_git_mutations": 0, "old_archive_producers": 0, "this_documentary_archive": 1},
    "sources": {"root_search_calls": 2, "root_search_queries": 6, "root_search_metadata_only": True, "root_one_result_string_expansion_truncated_and_not_adopted": True, "dual_search_calls": 1, "dual_search_queries": 3, "dual_primary_abstract_pages_opened": 2, "new_pdf_downloads_by_team": 0, "new_html_downloads_by_team": 0, "newly_adopted_theorem_from_search_metadata": False, "whole_paper_reading_claim": False, "precise_scope": "Four reading scopes; current Catalan full seven sections copied; exact UDC selected pages; existing ICM and CDT selected pages"},
    "previous_manifest": pin(PREVIOUS),
    "previous_manifest_nonpolicy_files_preserved": 59,
    "report": pin(REPORT),
    "independent_math_and_report_review": pin(REVIEW),
    "root_independent_holonomy_author_review": pin(SOURCES / "root_reading_scope.md"),
    "previous_policy": {"bytes": len(old_policy), "sha256": digest(old_policy)},
    "new_policy": pin(POLICY),
    "previous_main": {"bytes": len(old_main), "sha256": digest(old_main)},
    "new_main": pin(MAIN),
    "files": [pin(path) for path in sorted(paths) if path.is_file()],
}
MANIFEST.write_text(json.dumps(manifest, ensure_ascii=False, indent=2)+"\n", encoding="utf-8")
assert PREVIOUS.read_bytes() == previous_data
assert REVIEW.read_bytes() == review_data
print(json.dumps({"status": "PASS", "numeric_theorem": False, "next_formal_review": 256, "completed_since_formal": 3, "old_nonpolicy_files_preserved": 59, "files": len(manifest["files"]), "manifest": pin(MANIFEST), "main": pin(MAIN), "policy": pin(POLICY)}, ensure_ascii=False))
