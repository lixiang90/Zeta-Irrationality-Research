"""Archive primary inputs; retain original PDF bytes and source metadata."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, sys
import requests
import fitz

sys.stdout.reconfigure(encoding='utf-8')
ROOT = Path(__file__).resolve().parents[1]
ITEMS = [
 ('beukers2025_supercongruences_modular_v3.pdf',
  'https://arxiv.org/pdf/2403.03301v3',
  'Supercongruences using modular forms', ['Frits Beukers'],
  'arXiv:2403.03301v3', '2025-06-16', 0),
 ('beukers_tsai_ye2024_lucas_modular_v2.pdf',
  'https://arxiv.org/pdf/2408.16616v2',
  'Lucas congruences using modular forms',
  ['Frits Beukers', 'Wei-Lun Tsai', 'Dongxi Ye'],
  'arXiv:2408.16616v2', '2024-10-23', 0),
 ('katz1968_period_matrices.pdf',
  'https://web.math.princeton.edu/~nmk/old/DEsatPerMat.pdf',
  'On the differential equations satisfied by period matrices',
  ['Nicholas M. Katz'], 'Publications mathematiques IHES 35 (1968), 71-106',
  '1968', 1),
 ('katz1973_padic_modular_forms.pdf',
  'https://web.math.princeton.edu/~nmk/old/padicpropMFMS.pdf',
  'P-adic properties of modular schemes and modular forms',
  ['Nicholas M. Katz'], 'Antwerp 1972 lecture notes; published 1973',
  '1973', 0),
]

def main():
    entries = []
    for filename, url, title, authors, version, date, identity_page in ITEMS:
        path = ROOT/'literature'/filename
        if not path.exists():
            response = requests.get(url, timeout=50)
            response.raise_for_status()
            assert response.content.startswith(b'%PDF-'), (filename, response.headers)
            path.write_bytes(response.content)
        data = path.read_bytes()
        assert data.startswith(b'%PDF-')
        pdf = fitz.open(stream=data, filetype='pdf')
        text = pdf[identity_page].get_text()
        normalized = ' '.join(text.casefold().split())
        scanned_title = filename == 'katz1973_padic_modular_forms.pdf'
        if scanned_title:
            assert 'international summer school' in normalized and 'antwerp' in normalized
        else:
            assert all(word.casefold() in normalized for word in title.split() if len(word)>3), filename
            assert any(name.split()[-1].casefold() in normalized for name in authors), filename
        preview = ROOT/'tmp'/'pdfs'/(Path(filename).stem+'_identity.png')
        preview.parent.mkdir(parents=True, exist_ok=True)
        pdf[identity_page].get_pixmap(matrix=fitz.Matrix(1.25, 1.25)).save(preview)
        entries.append({
          'file': 'literature/'+filename, 'source_url': url,
          'title': title, 'authors': authors, 'version': version,
          'source_date': date, 'pages': len(pdf), 'bytes': len(data),
          'sha256': hashlib.sha256(data).hexdigest(),
          'pdf_signature_checked': True, 'identity_text_checked': not scanned_title,
          'identity_ocr_note': 'Scanned title requires visual author/title review.' if scanned_title else None,
          'identity_page_zero_based': identity_page,
          'identity_preview': str(preview.relative_to(ROOT)).replace('\\','/'),
          'identity_visual_checked': False,
        })
        print(json.dumps({k:entries[-1][k] for k in ['file','pages','sha256','identity_preview']}))
    manifest = {
      'archived_at_utc': datetime.now(timezone.utc).isoformat(),
      'purpose': 'Primary sources for prime-dependent Hasse relations and possible arithmetic-lattice refinement; no new numerical irrationality theorem asserted.',
      'entries': entries,
      'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    }
    (ROOT/'literature'/'manifest_cdt_odd_hasse_20261006.json').write_text(
      json.dumps(manifest, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')

if __name__ == '__main__':
    main()
