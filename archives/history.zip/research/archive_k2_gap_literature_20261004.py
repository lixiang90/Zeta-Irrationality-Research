"""Archive this round's explicitly selected original sources without modifying prior files."""
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
import json
from pathlib import Path
import archive_global_literature_20261004 as base

ROOT = Path(__file__).resolve().parents[1]
CONFIG = ROOT / 'literature/k2_gap_sources_20261004.json'
MANIFEST = ROOT / 'literature/manifest_k2_gap_20261004.json'

if __name__ == '__main__':
    config = json.loads(CONFIG.read_text(encoding='utf-8'))
    base.PREVIOUS = ({item['file']: item for item in json.loads(MANIFEST.read_text(encoding='utf-8'))['sources']}
                     if MANIFEST.exists() else {})
    with ThreadPoolExecutor(max_workers=3) as pool:
        results = list(pool.map(base.archive, config['sources']))
    for result in results:
        previous = base.PREVIOUS.get(result['file'], {})
        if previous.get('sha256') == result.get('sha256'):
            for field in ('first_page_identity_visually_checked', 'visual_identity_contact_sheet'):
                if field in previous:
                    result[field] = previous[field]
    manifest = {'as_of': config['as_of'], 'created_at_utc': datetime.now(timezone.utc).isoformat(),
                'validation': 'Original bytes; PDF signature, parse, pages, SHA-256; visual identity checked separately',
                'sources': results}
    MANIFEST.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    for result in results:
        print(result['file'], result['archive_status'], result.get('pages', ''), flush=True)
    failed = [item['file'] for item in results if item['archive_status'] == 'failed']
    print(json.dumps({'archived': len(results) - len(failed), 'failed': failed}, ensure_ascii=False), flush=True)
    raise SystemExit(bool(failed))
