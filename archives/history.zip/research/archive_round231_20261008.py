"""One-shot documentary archive; no mathematical producer calls."""
from pathlib import Path
import hashlib
import json
import re

root = Path(__file__).resolve().parent.parent
main = root / "research/cdt_odd_background_progress_20261006.md"
report = root / "research/research_boundary_structure_progress_round231_20261008.md"
previous = root / "literature/manifest_residue_projection_round230_20261008.json"
dest = root / "literature/manifest_boundary_structure_round231_20261008.json"
old_size = 577645
old_sha = "4ce1068eaab50ea366dfb09d05791b643e1e460e820fbba6b8902b6a22c5eb7e"
prev_sha = "3659e5d7df104e64edc97c5af0ee8db6904756f59c698f5c52c799559ec7cb94"
report_sha = "7f425fa613d028eaa04504ddfb5959a082c679faa34be5f4b858dec0c4c697ac"

def sha(data):
    return hashlib.sha256(data).hexdigest()

old, body = main.read_bytes(), report.read_bytes()
assert len(old) == old_size and sha(old) == old_sha, "Main prefix changed"
assert sha(previous.read_bytes()) == prev_sha, "Predecessor changed"
assert sha(body) == report_sha, "Report changed"
assert not dest.exists(), "Do not rerun a completed archive"

files = sorted({*root.joinpath("research").glob("*round231*20261008.*"),
                *root.joinpath("literature/finite_field_projection_sources_round231_20261008").glob("*")})
pins = []
for path in files:
    if not path.is_file():
        continue
    data = path.read_bytes()
    if path.suffix == ".md":
        text = data.decode("utf-8-sig")
        assert not any(ord(c) < 32 and c not in "\r\n\t" for c in text), path
    pins.append({"path": path.relative_to(root).as_posix(),
                 "bytes": len(data), "sha256": sha(data)})

links = []
for target in re.findall(r"\]\(([^)]+)\)", body.decode("utf-8-sig")):
    if target.startswith(("http:", "https:", "#")):
        continue
    assert (report.parent / target.split("#", 1)[0]).resolve().is_file(), target
    links.append(target)

combined = old + b"\n\n" + body
manifest = {
    "round": 231, "date": "2026-10-08", "status": "progress",
    "previous_goal_turn_classification": "progress",
    "mathematical_program_runs": 0, "mathematical_program_failures": 0,
    "git_mutations": 0, "lean_builds": 0,
    "mathematical_status": "Exact parameter reflection/Fermat condition, Gaudin/half-shift kernel and regularized complete Chebyshev matrix proved; original W unbounded nonzero and numerical irrationality remain unproved",
    "global_review_cadence": {"last_formal": 228, "default_next": 234,
                              "scheduled_next": 232, "window": [232, 236],
                              "reset_by_this_round": False,
                              "early_reason": "Hidden prime infinitude condition and coupled point-value gate require comparison with direct zeta/L targets"},
    "next_interface": "Formal global review in232: real target isolation, complete integral cost, analytic gain and actual unbounded nonzero; compare boundary arithmetic against fixed-tail/Christoffel and direct target source routes",
    "verification_scope": "New document identities, report local links, predecessor identity and main preserved prefix only; no old producers, archives or historical pins rerun",
    "predecessor": {"path": previous.relative_to(root).as_posix(), "bytes": previous.stat().st_size, "sha256": prev_sha},
    "main_preserved_prefix": {"bytes": old_size, "sha256": old_sha},
    "appended_report": {"path": report.relative_to(root).as_posix(), "bytes": len(body), "sha256": report_sha},
    "main_after_append": {"path": main.relative_to(root).as_posix(), "bytes": len(combined), "sha256": sha(combined)},
    "source_scope": "Primary PDFs and selected text saved; exact author/Root reading boundaries in four new source records; no full-paper or all-2026-literature certification",
    "report_links_checked": links, "new_pins": pins,
}
dest.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
main.write_bytes(combined)
assert main.read_bytes() == combined
print(json.dumps({"status": "PASS", "round": 231, "pins": len(pins),
                  "report_links": len(links), "mathematical_runs": 0,
                  "main_bytes": len(combined), "main_sha256": sha(combined),
                  "manifest_bytes": dest.stat().st_size, "manifest_sha256": sha(dest.read_bytes())}, ensure_ascii=False))
