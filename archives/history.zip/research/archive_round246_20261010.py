"""One-shot documentary archive of round246; executes no mathematics."""
from pathlib import Path
import hashlib
import json

root = Path(__file__).resolve().parent.parent
assert root == Path('E:/kimi-build/zeta5').resolve()
main = root / 'research/cdt_odd_background_progress_20261006.md'
report = root / 'research/research_forcing_recovery_progress_round246_20261010.md'
policy = root / 'research/research_global_review_policy.md'
previous = root / 'literature/manifest_cm_admission_recovery_round245_20261010.json'
sources = root / 'literature/forcing_recovery_sources_round246_20261010'
destination = root / 'literature/manifest_forcing_recovery_round246_20261010.json'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def pin(path):
    data = path.read_bytes()
    return {'path': path.relative_to(root).as_posix(),
            'bytes': len(data), 'sha256': sha(data)}


assert not destination.exists(), 'Do not rerun a completed documentary archive'
old = main.read_bytes()
assert len(old) == 681402
assert sha(old) == 'af4490bedb48ac46eda367d172a5a9319257a20e024a6986d48f4aede79c76a6'
assert sha(previous.read_bytes()) == 'f9b963953d65c757838668e5aa3d5b3b6b0cd19490044fa50d29f26d848f75a2'
previous_archive = json.loads(previous.read_text(encoding='utf-8'))
for record in previous_archive['files']:
    if record['path'] != policy.relative_to(root).as_posix():
        assert pin(root / record['path']) == record, record['path']
expected = {
    'research/dirichlet_chi7_eisenstein_source_round246_20261010.md':
        (10448, '544f1df14fc0bbac19756891f000a54961024fe2588b899b731c583ede531679'),
    'research/forcing_apery_primary_round246_20261010.md':
        (9499, '3723695b1ff8f0a4574f4d34f31fa8c7132f434f0cf70dcbe7418ddc391ed310'),
    'research/forcing_recovery_criterion_round246_20261010.md':
        (15495, '7527fb291f4f0b38e3992e5fdbc2e0841f07a4ecf460f2aacf4e806b5ad2f348'),
    'research/forcing_success_source_review_round246_20261010.md':
        (11325, 'c91cf368a62d142dcdb0603e85f107a803d86eb7a9b1936931838daffbd7b345'),
    'research/research_forcing_recovery_progress_round246_20261010.md':
        (5258, 'de818af53f0ebc6f0c2a0a3e5df9d34e6834912939c969cddb8660552a803b5f'),
}
for name, (length, digest) in expected.items():
    item = pin(root / name)
    assert (item['bytes'], item['sha256']) == (length, digest), name

target_digest = expected['research/dirichlet_chi7_eisenstein_source_round246_20261010.md'][1]
for receipt in ('research/research_round246_dirichlet_chi7_review_20261010.md',):
    text = (root / receipt).read_text(encoding='utf-8-sig')
    assert 'PASS' in text and target_digest in text, receipt
receipt = root / 'research/research_round246_forcing_report_review_20261010.md'
text = receipt.read_text(encoding='utf-8-sig')
assert 'PASS' in text and expected[report.relative_to(root).as_posix()][1] in text
assert target_digest in text

previous_policy = {'bytes': 9621,
                   'sha256': '14ed72aa8212641c945d46b1bd439348b49a00d89d6492f0ac34428ac89f7c14'}
policy_data = policy.read_bytes()
assert sha(policy_data[:9621]) == previous_policy['sha256']
assert '第246轮' in policy_data[9621:].decode('utf-8')
assert '248' in policy_data[9621:].decode('utf-8')
assert (sources / 'root_reading_scope.md').is_file()

records = set((root / 'research').glob('*round246*20261010.*'))
records.update(p for p in sources.rglob('*') if p.is_file())
records.add(policy)
pins = [pin(p) for p in sorted(records)]
body = report.read_bytes()
combined = old + b'\n\n' + body
manifest = {
    'round': 246, 'date_completed': '2026-10-10',
    'classification': 'progress', 'previous_goal_turn_classification': 'progress',
    'goal_status': 'active',
    'new_numerical_irrationality_or_independence_theorem': False,
    'formal_global_review': {
        'last': 244, 'this_round_is_formal': False,
        'completed_rounds_since_last': 2,
        'counter_reset_this_round': False, 'next_scheduled': 248,
    },
    'object': {
        'target': 'Y = L(2, chi_-7)',
        'coordinate': 'u = (eta(7 tau)/eta(tau))^4',
        'actual_source': 'B_chi = A sum(e_n q^n/n^2)',
        'forcing': 'L B_chi = u(1+13u+49u^2)(1+8u)',
        'numeric_bridge': 'finite part of E_chi(e^-a) minus L(3,chi)/a tends to -Y/2',
    },
    'paid': [
        'General actual simple-module recovery and nonsplit rational-forcing nonrecovery criteria.',
        'Precise CDT chi_-3 and Catalan source comparison within stated reader scopes.',
        'Rigidity of the fixed original Fricke holomorphic driving source.',
        'Exact double-cover modular-unit coordinate and F_chi = f(1+8u) identity.',
        'Actual rational inhomogeneous equation and all-prefix integer model with d_N squared.',
        'Real Dirichlet Y finite part by dominated convergence.',
        'Actual rank three and all-constant nonrecovery by irreducibility and absence of rational particular.',
        'Convergent full log-squared expansion and fixed rational differential filtering obstruction.',
        'Entire native-vanishing holomorphic two-source family classified; constant mixing cannot remove log-squared while retaining the Y direction.',
        'Independent full final-source paper reviews and final-report scope review.',
    ],
    'not_paid': [
        'Full rational-relation period projection or filled source, all-leaf map admission.',
        'Same-object infinite nonvanishing or strict arithmetic holonomy budget.',
        'New numerical irrationality or linear independence, or all odd zeta values.',
        'Full upstream modular proofs or Lean verification.',
        'All-method, all-coordinate, all-CM or all-CDT impossibility.',
    ],
    'resource_decision': {
        'old_CM_original_basic_entry': 'remains stopped',
        'chi7_single_source_fixed_filter': 'stop',
        'same_native_holomorphic_two_source_constant_mixing': 'stop',
        'next_round_gate': 'Canonical constant treatment of E_(3,1,chi); actual full dual-cusp period/log stack with native rational Taylor holonomicity, all Tate cancellation and nonzero Y projection.',
        'map_prime_or_lcd_tuning_before_gate': False,
        'failure_decision': 'Do not expand same parameters; compare growing mixed matrices and identified relative-period sources in formal round248 review.',
    },
    'runs': {
        'mathematics': 0, 'cas_or_interval': 0,
        'prime_parameter_or_map_scans': 0, 'lean': 0,
        'external_git_mutations': 0, 'old_archive_producers': 0,
        'this_documentary_archive': 1,
    },
    'source_reading_scope': 'Exact per-reader scopes; stored full carriers do not certify complete upstream proofs.',
    'previous_manifest': pin(previous), 'report': pin(report),
    'previous_policy': previous_policy, 'new_policy': pin(policy),
    'previous_main': {'bytes': len(old), 'sha256': sha(old)},
    'new_main': {'path': main.relative_to(root).as_posix(),
                 'bytes': len(combined), 'sha256': sha(combined)},
    'files': pins,
}
with destination.open('x', encoding='utf-8', newline='\n') as stream:
    json.dump(manifest, stream, ensure_ascii=False, indent=2)
    stream.write('\n')
main.write_bytes(combined)
assert main.read_bytes()[:len(old)] == old
assert main.read_bytes()[len(old):] == b'\n\n' + body
for record in pins:
    assert pin(root / record['path']) == record
print(json.dumps({'status': 'PASS', 'manifest': pin(destination),
                  'main': pin(main), 'pinned_files': len(pins),
                  'formal_review_next': 248}, ensure_ascii=False))
