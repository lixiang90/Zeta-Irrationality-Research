"""One-shot documentary round-224 freeze. Runs no mathematical producer."""
from pathlib import Path
from hashlib import sha256
import json
import re

ROOT = Path(__file__).resolve().parents[1]
MAIN = 'research/cdt_odd_background_progress_20261006.md'
REPORT = 'research/research_pade_nonvanishing_round224_20261008.md'
PREVIOUS = 'literature/manifest_cdt_pade_structure_round223_20261008.json'
OUTPUT = 'literature/manifest_cdt_pade_nonvanishing_round224_20261008.json'
REVIEW = 'research/research_round224_report_review_20261008.md'
REVIEW_BYTES = 8268  # Root actual FULL read of the final independent receipt.
REVIEW_SHA = 'f754ff100979550b09535d5fc45646a14f8b775ee07224859051a7b2f94640a6'
SOURCE_DIRS = [
    'literature/pade_nonvanishing_sources_round224_20261008',
    'literature/pade_operator_sources_round224_20261008',
    'literature/pade_direct_structure_sources_round224_20261008',
]


def identity(relative):
    data = (ROOT / relative).read_bytes()
    return {'path': relative, 'bytes': len(data), 'sha256': sha256(data).hexdigest()}


def require(relative, length, digest):
    item = identity(relative)
    assert (item['bytes'], item['sha256']) == (length, digest), item
    return item


assert not (ROOT / OUTPUT).exists(), 'Completed archive must not be rerun.'
assert REVIEW_BYTES is not None and REVIEW_SHA is not None, 'Review not yet frozen.'
require(PREVIOUS, 34591, '2b1b22375774410a6c7dec49579e651d1987af45057347184e204e87de8b377b')
previous = json.loads((ROOT / PREVIOUS).read_text(encoding='utf-8'))
old_checked = [require(p['path'], p['bytes'], p['sha256'])
               for p in previous['pins'] if p['path'] != MAIN]
assert len(old_checked) == 108
prefix = (ROOT / MAIN).read_bytes()
assert len(prefix) == 524758
assert sha256(prefix).hexdigest() == 'aaf5b1540461ab0827e9bcd79f6a96a89ead54e63e2f6c7fcc14587bbecfd25e'

expected = '''
research/pade_infinite_nonzero_residual_round224_20261008.md 10833 0c9fc5eece684d709e0d4a3ad787968b97af80b10f99e7b4b9f14d33fd7d039b
research/pade_centered_even_telescoper_round224_20261008.md 14482 32d41b069e688a3aa4e93c44721fe39a6f4ebe1ce646df7fe902bf660d507efd
research/pade_bilateral_period_model_round224_20261008.md 7816 7761ce036a9b31d6a6bdfd4e3cac6d0e4feba840e6b2dca23f4db7ff0d7996a4
research/pade_direct_fourier_kernel_round224_20261008.md 12032 16e84deee6e12c94da29cee38171b0f65fabb765b31bb5ac06dd7f9edf6b3530
research/certify_pade_residual_constants_round224_20261008.py 4698 b6cd01f1c99f63d6123b725efc01fbef78f48c1ae924aee7f4f3828d3b4ffac6
research/pade_residual_constants_round224_20261008.json 2994 59b76b4e0678d1c4c265c05c5310e55a0f804feddd84024c0c6eba9e25034beb
research/pade_residual_constants_ledger_round224_20261008.md 1664 96bc45b181877f10b6b984002d79de8a2f755f734cc03cc2e13bc23317e7ecdc
research/certify_pade_telescoper_residual_rank_round224_20261008.py 9628 b01275768fe9700cc7c3b21befa91bfd5ca1a97676d34f459112f3d3f8e2fd8f
research/pade_telescoper_residual_rank_certificate_round224_20261008.json 26796 a47a933aca74e035b49233d1f7cbd7106d770f679f5840934cdbfcfc69e4bbd0
research/verify_pade_telescoper_minors_leibniz_round224_20261008.py 2492 45fa26b45079430948d2fbeead723295ecee831ccf963128db0713099bc63e1c
research/pade_telescoper_leibniz_review_round224_20261008.json 751 23f7d47bb3f0c39580e7fb83bd9e21a43fbc9b95fc727108b6f7d019f5bc80cc
research/research_round224_infinite_nonzero_review_20261008.md 3861 7ee4559aafc874a296c81bc79db4564b8467bedbabea55502cbf09504cce37d9
research/research_round224_infinite_nonzero_second_review_20261008.md 6282 e7af301b18438eb7204b1cde2d35435b41f6ff32ed7da909581487004df2fb1f
research/research_round224_telescoper_review_20261008.md 4653 6ae1a126d501e8cee540e5c9724923d3283cdca9ef93a61d22acddb170d44608
research/research_round224_bilateral_period_review_20261008.md 4767 9442462cc1d8865a37801a3bbe14587b0e8ef984fdce676ed95c50163cd083b9
research/research_round224_fourier_kernel_review_20261008.md 4324 f87001259756b43cc0ddf866491d4d1247882ebacc0e6248a0c665fa3e412199
research/research_pade_nonvanishing_round224_20261008.md 8437 42be710464f3a705138b442a9cc57a30f12761ab10c5c6496eb6dc32edd80142
literature/pade_nonvanishing_sources_round224_20261008/root_reading_scope.md 6883 aa8398a21f4d9f0543feb7b5fc343ee261a24ef1529497fcdeb990e6f42f549c
literature/pade_nonvanishing_sources_round224_20261008/root_dlmf_4_22E5.tex 80 47271bb736a5a91ffa162162d7b7aa3e310ed69fc029507702ddf99d8b4460b7
literature/pade_operator_sources_round224_20261008/lambert_implementation_reading_scope.md 2886 1571af8b0ab250a196d3d7b65c3a5051a7a8b16375952d71531af25cdf847020
literature/pade_direct_structure_sources_round224_20261008/dual_reading_scope.md 3724 44745fd59547a3f29fb39be3ee0f192073bc336440fa6f848870931b531f6f9f
literature/pade_direct_structure_sources_round224_20261008/dual_dlmf_1_8.html 179059 64e7d4db21e893cb387996eba067d8a4e4de30cebc1b220e5d3f7a648794eabe
literature/pade_direct_structure_sources_round224_20261008/dual_dlmf_1_14.html 657223 16c38cf164a3f6103187f9e184226418bf335a475f11b6763e86dcbf7a114eca
literature/pade_direct_structure_sources_round224_20261008/dual_dlmf_5_12.html 133018 30cdb9e6c52c13532cdcd845e7f139b7f3d5454dc2927f88a28fc99849fd9f1c
literature/pade_direct_structure_sources_round224_20261008/dual_dlmf_1_8E4.tex 89 623e5ad0b99d84bd00705c66833464649be043c900ec7fd4f47011329debad05
literature/pade_direct_structure_sources_round224_20261008/dual_dlmf_1_8E14.tex 169 f86e19d6c0db94629592c5aef78c45805f1fe5985528f55c62e6e8b9794386ee
literature/pade_direct_structure_sources_round224_20261008/dual_dlmf_1_14E4.tex 101 0b6bf5bc52f4d030a8176b2b8219213259016ae88fafc2bd7d89544cdbd749a3
literature/pade_direct_structure_sources_round224_20261008/dual_dlmf_1_14E5.tex 81 2377b666a1f2e9858a35765a186769a0e6f5ce96f78594594d847b420d5b472f
literature/pade_direct_structure_sources_round224_20261008/dual_dlmf_5_12E5.tex 158 bbf976201943ab9b60724189970d864ebe16df9c8df55abc8e866ea228d0964e
'''
pins = {p['path']: p for p in old_checked}
pins[PREVIOUS] = identity(PREVIOUS)
new_paths = []
for line in expected.splitlines():
    if line.strip():
        relative, length, digest = line.split()
        pins[relative] = require(relative, int(length), digest)
        new_paths.append(relative)
pins[REVIEW] = require(REVIEW, REVIEW_BYTES, REVIEW_SHA)
new_paths.append(REVIEW)
for directory in SOURCE_DIRS:
    for file in sorted((ROOT / directory).rglob('*')):
        if file.is_file():
            relative = file.relative_to(ROOT).as_posix()
            pins[relative] = identity(relative)
            new_paths.append(relative)
new_paths = sorted(set(new_paths))
assert not any(p.endswith('.pdf') for p in new_paths)
assert len([p for p in new_paths if p.endswith('.html')]) == 3
assert len([p for p in new_paths if p.endswith('.tex')]) == 6

new_mds = [p for p in new_paths if p.endswith('.md')]
links = []
for relative in new_mds:
    content = (ROOT / relative).read_text(encoding='utf-8')
    assert not any(ord(c) < 32 and c not in '\n\r\t' or ord(c) == 127 for c in content), relative
    for target in re.findall(r'\[[^\]\n]*\]\(([^)\n]+)\)', content):
        target = target.strip().strip('<>').split('#', 1)[0]
        if re.match(r'^(?:https?://|app://)', target):
            continue
        if Path(target).suffix.lower() not in {'.md', '.pdf', '.json', '.txt', '.py', '.png', '.tex'}:
            continue
        resolved = ((ROOT / relative).parent / target).resolve()
        assert resolved.is_relative_to(ROOT), (relative, target)
        link_path = resolved.relative_to(ROOT).as_posix()
        assert resolved.is_file() or link_path == OUTPUT, (relative, target)
        links.append({'source': relative, 'target': link_path})
        if resolved.is_file() and link_path not in pins and link_path != MAIN:
            pins[link_path] = identity(link_path)

report = (ROOT / REPORT).read_bytes()
main_final = prefix + b'\n\n' + report
(ROOT / MAIN).write_bytes(main_final)
assert (ROOT / MAIN).read_bytes() == main_final
pins[MAIN] = identity(MAIN)
script = Path(__file__).relative_to(ROOT).as_posix()
pins[script] = identity(script)
record = {
    'round': 224, 'date': '2026-10-08', 'goal_status': 'active',
    'new_numerical_theorem': False,
    'round_outcome': 'Actual Delta infinite nonzero; explicit shared order-six recurrence of full A3/A5/A7/C; twenty-dimensional exterior difference system; exact three-frequency and compact real-kernel interfaces.',
    'navigation': {
        'last_formal_global_review': 222,
        'next_normal_global_review': 228, 'allowed_window': [226, 230],
        'early_triggers': ['structural counterexample/cap', 'two completed rounds without a core interface advance'],
        'this_round_has_core_interface_advance': True,
        'next_task': 'Actual generic dominant modes/singularities and relation-selective strict analytic gain; pay minimal differential model. Do not keep deepening prime residuals now that infinite Delta nonzero is proved.'
    },
    'completed_math': [
        'For every p>37 with p not dividing 7763789492179875: Delta_((p-1)/2)/p = 7763789492179875/4 mod p; v_p(Delta)=1. Hence infinitely many actual Delta_r are nonzero.',
        'Two exact integral shears remove unknown deep linear scalars while keeping the first cubic direction; full signed unit blocks, partial clusters and error germs paid.',
        'Centered principal-part reduction gives explicit nonzero common recurrence of A3,A5,A7,I and complete C; order6 in r=n/2, order12 in ordinary n-shift. Not minimal order.',
        'Explicit exterior companion system dimension20 for Delta/Xi/fixed rational-g H; scalar difference order at most20. Not differential/CDT micro-rank20.',
        'Exact three-cosine period transformation determinant1/64; actual Delta = (8505*pi^6/4) det B. General 2m-pole projection determinant2^(-m(m-1)). Not free rational/algebraic rank reduction.',
        'Actual compact C4 kernel K_r = product(a^2+d_t^2)^3 (w_r*6); B_j=4*pi*(-1)^r K_r(j*pi). U>=0 does not prove K positivity.',
    ],
    'remaining_gates': [
        'actual generic dominant singularity/growth data',
        'relation strict overconvergence and complete same-source strict comparison',
        'minimal differential/cyclic model and CDT arithmetic holonomy rank',
        'optimal complete arithmetic cost; Xi/J/H nonzero if required by selected criterion',
        'new numerical irrationality/linear-independence theorem'
    ],
    'execution_ledger': {
        'mathematical_program_runs': 3,
        'A_fixed_n6_principal_part_matrix_runs': 1,
        'B_fixed_m1_m3_fraction_constant_runs': 1,
        'Root_saved_matrix_independent_Leibniz_runs': 1,
        'CAS': 0, 'recurrence_guessing': 0, 'parameter_or_prime_scans': 0,
        'PSLQ': 0, 'numerical_integrations': 0, 'old_proof_producer_reruns': 0,
        'Lean_builds': 0, 'Git_mutations': 0, 'new_repository_status_check': False,
        'new_PDF_downloads': 0, 'new_DLMF_HTML_archives': 3, 'new_DLMF_short_TEX': 6,
        'documentary_operations': 'Actual reading, primary selected sections, formula downloads, metadata/hash/control/link checks and this one-shot append/archive. Archive executes/imports no mathematical producer.'
    },
    'source_claim_policy': 'Root actual DLMF4.22E5 formula/conditions and six short TEX formulas; C/B selected DLMF1.8/1.14/5.12 used formulas and full conditions, not FULL whole archived HTML chapters; A implementation scope only for Root. No new PDFs or current-cloud/Lean claims.',
    'independent_review': {
        'infinite_nonzero': 'Root FULL independent paper PASS plus A second FULL independent paper PASS',
        'shared_telescoper': 'Root FULL independent paper PASS plus one saved-matrix independent Leibniz run; limited to recurrence, not minimal differential rank',
        'bilateral_all_weight_period': 'C FULL independent PASS',
        'real_Fourier_kernel': 'B FULL independent PASS',
        'report_and_root_scope': 'C FULL independent PASS at final pinned identity'
    },
    'predecessor': {'manifest': identity(PREVIOUS), 'immutable_pins_checked': len(old_checked),
                    'mutable_main_excluded_from_old_final_hash': True},
    'main_append': {'preserved_prefix_bytes': len(prefix), 'preserved_prefix_sha256': sha256(prefix).hexdigest(),
                    'append_separator_hex': '0a0a', 'appended_report': identity(REPORT), 'final': identity(MAIN)},
    'verification': {'control_character_documents': len(new_mds), 'controls': 'PASS',
                     'local_links': links, 'links': 'PASS including the planned manifest checked after creation'},
    'pins': sorted(pins.values(), key=lambda p: p['path'])
}
(ROOT / OUTPUT).write_text(json.dumps(record, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
for link in links:
    assert (ROOT / link['target']).is_file(), link
for item in record['pins']:
    require(item['path'], item['bytes'], item['sha256'])
require(PREVIOUS, 34591, '2b1b22375774410a6c7dec49579e651d1987af45057347184e204e87de8b377b')
print(json.dumps({'manifest': identity(OUTPUT), 'main': identity(MAIN), 'pins': len(record['pins']),
                  'local_links': len(links), 'controls_md': len(new_mds),
                  'predecessor_immutable_pins': len(old_checked), 'checks': 'PASS'}, ensure_ascii=False))
