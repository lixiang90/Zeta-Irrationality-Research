"""Archive this round's primary sources; never overwrite an original."""
import sys, json, concurrent.futures
from pathlib import Path
from datetime import datetime, timezone
import fitz
from PIL import Image, ImageDraw
import archive_global_literature_20261004 as base
ROOT=Path(__file__).resolve().parents[1]
CONFIG=ROOT/'literature/cdt_odd_sources_20261005.json'
MANIFEST=ROOT/'literature/manifest_cdt_odd_20261005.json'
base.PREVIOUS={r['file']:r for r in json.loads(MANIFEST.read_text(encoding='utf-8'))['sources']} if MANIFEST.exists() else {}
def main():
    sources=json.loads(CONFIG.read_text(encoding='utf-8'))['sources']
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
        records=list(pool.map(base.archive,sources))
    assert all(r['archive_status']!='failed' for r in records),records
    out=ROOT/'research/cdt_odd_source_identity_20261005'
    out.mkdir(exist_ok=True)
    contact=Image.new('RGB',(1360,920*((len(records)+1)//2)),'#dddddd')
    for i,r in enumerate(records):
        doc=fitz.open(ROOT/'literature'/r['file'])
        pix=doc[0].get_pixmap(matrix=fitz.Matrix(.8,.8),alpha=False)
        im=Image.frombytes('RGB',(pix.width,pix.height),pix.samples)
        im.thumbnail((640,850))
        panel=Image.new('RGB',(680,920),'white')
        panel.paste(im,((680-im.width)//2,50))
        ImageDraw.Draw(panel).text((10,10),r['file'],fill='black')
        contact.paste(panel,((i%2)*680,(i//2)*920))
        old=base.PREVIOUS.get(r['file'],{})
        r['first_page_identity_visually_checked']=bool(old.get('sha256')==r['sha256'] and old.get('first_page_identity_visually_checked'))
        r['visual_identity_contact_sheet']='research/cdt_odd_source_identity_20261005/contact.png'
    contact.save(out/'contact.png')
    data={'as_of':'2026-10-05','created_at_utc':datetime.now(timezone.utc).isoformat(),'validation':'Original bytes, PDF signature, parsed pages, SHA-256 and rendered first pages','sources':records}
    MANIFEST.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps([{'file':r['file'],'status':r['archive_status'],'pages':r['pages'],'sha256':r['sha256']} for r in records],ensure_ascii=False))
if __name__=='__main__':main()

