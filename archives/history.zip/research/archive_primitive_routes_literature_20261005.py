"""Archive fixed primary versions for the primitive-budget and route audit."""
from datetime import datetime, timezone
from concurrent.futures import ThreadPoolExecutor
from hashlib import sha256
import json
import requests
import archive_global_literature_20261004 as base

CONFIG = base.LIBRARY / "primitive_routes_sources_20261005.json"
MANIFEST = base.LIBRARY / "manifest_primitive_routes_20261005.json"
HTML_MANIFEST = base.LIBRARY / "manifest_primitive_routes_web_20261005.json"
if MANIFEST.exists():
    base.PREVIOUS = {r["file"]:r for r in json.loads(MANIFEST.read_text(encoding="utf-8"))["sources"]}
else:
    base.PREVIOUS = {}

def main():
    sources=json.loads(CONFIG.read_text(encoding="utf-8"))["sources"]
    with ThreadPoolExecutor(max_workers=3) as pool:
        results=list(pool.map(base.archive,sources))
    for r in results:
        previous=base.PREVIOUS.get(r["file"],{})
        if r.get("sha256") and previous.get("sha256")==r["sha256"]:
            for field in ("first_page_identity_visually_checked","visual_identity_contact_sheet",
                          "internal_author_date","later_withdrawal"):
                if field in previous:
                    r[field]=previous[field]
    for r in results:
        print(r["file"],r["archive_status"],r.get("pages"),flush=True)
    MANIFEST.write_text(json.dumps({
        "as_of":"2026-10-05","created_at_utc":datetime.now(timezone.utc).isoformat(),
        "validation":"Original bytes; PDF signature; pypdf parse; page count; first-page excerpt; SHA-256",
        "withdrawal_record":"arXiv v4 has no PDF; original HTML is saved in manifest_primitive_routes_web_20261005.json. Its comments state that errors were uncorrected; no theorem from v2 is adopted.",
        "sources":results,
    },ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
    web_sources=[]
    for stem, url, token in [
        ("dlmf_2_4_saddle_20261005","https://dlmf.nist.gov/2.4","Saddle Points"),
        ("dlmf_5_11_stirling_20261005","https://dlmf.nist.gov/5.11","Asymptotic Expansions"),
        ("ghosh_ward_arxiv_v4_metadata_20261005","https://arxiv.org/abs/1601.06765v4","withdraw"),
    ]:
        path=base.LIBRARY/(stem+".html")
        if path.exists():
            data=path.read_bytes()
            status="existing_preserved"
            resolved=url
        else:
            response=requests.get(url,timeout=(15,45))
            response.raise_for_status()
            data=response.content
            assert token.lower() in data.decode("utf-8",errors="replace").lower(),stem
            path.write_bytes(data)
            status="downloaded"
            resolved=response.url
        web_sources.append({
            "file":path.name,"url":url,"resolved_url":resolved,
            "bytes":len(data),"sha256":sha256(data).hexdigest(),
            "identity_token":token,"archive_status":status,
        })
    HTML_MANIFEST.write_text(json.dumps({
        "as_of":"2026-10-05","sources":web_sources,
        "validation":"Original HTML bytes and identity text; SHA-256; do not execute HTML.",
    },ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
    failed=[r["file"] for r in results if r["archive_status"]=="failed"]
    if failed:
        raise RuntimeError(failed)
if __name__=="__main__":
    main()

