"""One-shot documentary archive. No mathematical computation or Git mutation."""
from pathlib import Path
import hashlib
import json

root = Path(__file__).resolve().parent.parent
assert root == Path('E:/kimi-build/zeta5').resolve()
main = root / 'research/cdt_odd_background_progress_20261006.md'
report = root / 'research/research_global_review_round240_20261008.md'
policy = root / 'research/research_global_review_policy.md'
previous = root / 'literature/manifest_actual_cofactor_arithmetic_round239_20261008.json'
dest = root / 'literature/manifest_global_review_round240_20261008.json'
source_dir = root / 'literature/global_review_sources_round240_20261008'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def pin(path):
    data = path.read_bytes()
    return {'path': path.relative_to(root).as_posix(),
            'bytes': len(data), 'sha256': sha(data)}


assert not dest.exists(), 'Completed documentary archive must never be rerun'
old, body = main.read_bytes(), report.read_bytes()
assert len(old) == 641602
assert sha(old) == '65d6b13bf860a328fa594a85fdf883ff0a6f3ae74504a50cd7326b581b4a5c25'
assert len(body) == 9393
assert sha(body) == '113f8824e39953d7ce1f89c5c839c10c59708a2ca8a8b5a4671d53d30ff21d48'
assert sha(policy.read_bytes()) == '1d0734fe99cdaaa92fa2430493e4eda19899e2e292a6ffc8b9dc908cac01e5af'
assert sha(previous.read_bytes()) == '9b5015b50b2539c37081be9735af2d6cc353a77f59c22b2218def1617b86fac0'

frozen = {
    'global_logistic_whole_functional_bridge_round240_20261008.md':
        (9796, 'a655168bbd86afbacecf29bd91d396c7ce848bd5ea418a3300b71de36a5e316c'),
    'global_direct_holonomy_review_round240_20261008.md':
        (11398, 'b4d7d8d8ce37223ef1237d2b62c0bfbc58d30d94c7eee83b3578d03cbeac23a2'),
    'global_period_projection_review_round240_20261008.md':
        (9494, '48e480e4529bc5c7132f20a1b7661056a93c7c63200ebfed77f94ec2310897a1'),
    'global_repository_route_review_round240_20261008.md':
        (12192, '913c7493cb6055dcb8eefd49c3bdebdcb2d36e391114d0c2f04ba8f3fd7db39e'),
}
for name, (size, digest) in frozen.items():
    data = (root / 'research' / name).read_bytes()
    assert len(data) == size and sha(data) == digest, name

reviews = {
    'research_round240_global_report_review_20261008.md': sha(body),
    'research_round240_logistic_functional_bridge_review_20261008.md':
        frozen['global_logistic_whole_functional_bridge_round240_20261008.md'][1],
    'research_round240_period_projection_check_20261008.md':
        frozen['global_period_projection_review_round240_20261008.md'][1],
}
for name, digest in reviews.items():
    receipt = (root / 'research' / name).read_text(encoding='utf-8-sig')
    assert 'PASS' in receipt and digest in receipt, name

scopes = {
    'root_reading_scope.md': '3909e70e346a9aee97c7858fe00a840b5c723bc06e97be30e74508f6790d7a88',
    'packet_reading_scope.md': '4dfb6def7c1a047541448983a351f8dd2d1534dd10416ce445aa4806de8f7192',
    'dual_reading_scope.md': '396f73f1055f60cdcdf46bedae86ede487858b16d60fc809d1adada42e6bc876',
    'alternative_reading_scope.md': '827e38d894e0089759b274b027af255623d6b91180b6cb2a8113bc0c200aa82b',
}
for name, digest in scopes.items():
    assert sha((source_dir / name).read_bytes()) == digest, name

commit = json.loads((source_dir / 'root_zeta23/commit.json').read_text(encoding='utf-8-sig'))
assert commit['sha'] == '669c92bf7a3728e0de9ad80c373bc29fb5ca3d58'
new_pdfs = [pin(source_dir / name) for name in [
    'dual_tosi2026_cellular_v2.pdf', 'root_lai2026_zeta3_zeta4_v1.pdf']]
assert new_pdfs[0]['sha256'] == '91fa8a63db8c51d61e17268d46af2aa8672ea0a79d79072c358c3af44aab135e'
assert new_pdfs[1]['sha256'] == '838c0331efb1ea249b60308e00e1fbc2ae8771c55da4eaf22e7beb0243250a58'

files = set((root / 'research').glob('*round240*20261008.*'))
files.update(p for p in source_dir.rglob('*') if p.is_file())
files.add(policy)
records = [pin(p) for p in sorted(files) if p.is_file()]
combined = old + b'\n\n' + body
manifest = {
    'round': 240, 'date': '2026-10-08', 'classification': 'progress',
    'goal_status': 'active', 'numerical_irrationality_or_independence_theorem': False,
    'formal_global_review': {'previous': 236, 'current': 240, 'interval': 4,
                             'next_default': 246, 'allowed_window': [244, 248],
                             'this_round_resets_counter': True},
    'paid': [
        'Complete actual logistic whole-functional projection for every fixed finite odd-zeta combination with optional zeta2, including polynomial quotient and every simple pole.',
        'Self-contained Fourier/Laplace proof of all logistic moments, fixed-order integration-by-parts kernel bounded by a fixed constant times rho.',
        'Same absolute Heine leading-quadratic envelope under fixed finite combinations; external -6 FstarInput certification remains conditional.',
        'Full-scale target-coefficient Hankel rank at least n-1 by the anti-triangular block; not a full-rank or actual nonzero claim.',
        'Complete safe all-prime/all-power/all-coefficient integral model for 3 zeta3 + zeta5: (24 S_n d_(5n)^5)^(3n) Q in Z[T].',
        'Exact original cellular cubical formula and exclusion of the fixed diagonal-Euler constant-eigenform mechanism, without refuting the general D3 relative projection.',
        'Backup 2G-(pi/2)log2 actual native filling and full-prime-power d_N d_floor(N/2) model; two existing scaled maps fail its safe necessary threshold.',
        'Fresh read-only external repository local/cloud HEAD match and clean status; no newer commit than round236 baseline.',
        'Independent logistic-bridge and original-Euler paper audits, plus final global-report audit.',
    ],
    'not_paid': [
        'A new numerical irrationality or linear-independence theorem, target global novelty, or completion of the research objective.',
        'Primitive coefficient Gauss cost below the same actual analytic threshold, every-fixed-rational-point infinite nonzero certificate, or full rank 3n.',
        'Full independent FstarInput/-6 certificate, Lean/Comparator build, or all-source proof certification.',
        'Original cellular all-n D3/relative-boundary six-channel projection and projected asymptotic/arithmetic budget.',
        'Optimal actual old cofactor cost or an all-CDT no-go.',
    ],
    'route_decision': {
        'pause': 'Blind prime/map optimization of the old rank-three fixed common-BC source.',
        'sole_bounded_main': 'Fixed logistic whole-functional matrix for 3 zeta3 + zeta5, rounds241-244.',
        'first_gate': 'Full fixed-source prime-edge/local reduction at n=p-1, preserving quotient, heads, all residues, and boundaries.',
        'next_gate': 'Same primitive all-coefficient Gauss cost and actual infinite nonzero certificate before parameter or weight extension.',
        'reserves': 'zeta7 higher-weight variant; original M0,10 only with new all-n relative projection certificate; low-weight Catalan-log2 only with paid all-leaf map.',
        'stop_rule': 'Two rounds without shrinking actual nonzero or primitive-cost gap trigger early direction check; no local-search extension after244 without a new core certificate.',
    },
    'repository_snapshot': {
        'path': 'E:/codex-build/math', 'origin': 'https://github.com/openai/math',
        'local_and_public_main_head': 'fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb',
        'status_short': '', 'read_only_git_calls_by_agent': 5,
        'fetch_reset_checkout_or_external_write': 0,
        'scope': 'Targeted source/readme/history reading, not full-repository proof or Lean certification.'},
    'new_primary_snapshot': {'tang_commit': commit['sha'], 'new_pdfs': new_pdfs,
                             'tang_saved_selected_original_files': 14,
                             'lai_pdf_read_scope': 'Metadata and selected HTML, not full 25-page PDF proof.'},
    'mathematical_program_runs': 0, 'parameter_scans': 0, 'git_mutations': 0,
    'lean_builds': 0, 'new_saved_pdf_downloads': 2, 'old_producer_reruns': 0,
    'documentary_archive_attempts': 1,
    'corrections': 'B clarified p>N/a=0 boundary before freezing; Root corrected two LaTeX control-character escapes before report audit. No mathematical theorem was announced; no approval rejection.',
    'previous_manifest': pin(previous), 'previous_main': pin(main),
    'report': pin(report), 'policy': pin(policy), 'files': records,
    'main_after': {'path': main.relative_to(root).as_posix(),
                   'bytes': len(combined), 'sha256': sha(combined)},
}
serialized = (json.dumps(manifest, ensure_ascii=False, indent=2) + '\n').encode('utf-8')
main.write_bytes(combined)
dest.write_bytes(serialized)
assert main.read_bytes()[:len(old)] == old
assert sha(main.read_bytes()) == manifest['main_after']['sha256']
assert json.loads(dest.read_text(encoding='utf-8'))['main_after'] == manifest['main_after']
print(json.dumps({'status': 'PASS', 'round': 240, 'file_pins': len(records),
                  'main_after': manifest['main_after'], 'manifest': pin(dest)}, ensure_ascii=False))
