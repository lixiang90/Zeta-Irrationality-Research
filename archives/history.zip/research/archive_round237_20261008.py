"""One-shot documentary archive. No mathematical computation or Git mutation."""
from pathlib import Path
import hashlib
import json

root = Path(__file__).resolve().parent.parent
assert root == Path('E:/kimi-build/zeta5').resolve()
main = root / 'research/cdt_odd_background_progress_20261006.md'
report = root / 'research/research_joint_metric_bridge_round237_20261008.md'
previous = root / 'literature/manifest_global_review_round236_20261008.json'
dest = root / 'literature/manifest_joint_lattice_metric_bridge_round237_20261008.json'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def pin(path):
    data = path.read_bytes()
    return {'path': path.relative_to(root).as_posix(),
            'bytes': len(data), 'sha256': sha(data)}


old = main.read_bytes()
body = report.read_bytes()
assert len(old) == 617314
assert sha(old) == '1165b8afc609c31b43624915be44b5532a173da2dbd217f3693491acc7926b6d'
assert len(body) == 8880
assert sha(body) == 'c02c196eb7c1dc3b3343bad658d25ca0078ef19d060e6ea2c19558d85d884121'
assert sha(previous.read_bytes()) == '5c570dfdceeb12c576d0556b5d921555dce919145d6340fbc05e47fa1747cfab'
assert not dest.exists(), 'Archive already exists; never rerun a completed producer'

frozen = {
    'joint_lattice_metric_bridge_round237_20261008.md':
        (9821, 'cf2550e55910f6feceff0652aa38b5a102749aed7479c67540a4a80bc7e190a8'),
    'joint_lattice_metric_independent_round237_20261008.md':
        (10822, '4af1493bec05bd98ce370ebbfca6c502566779ca05f789700b36b0c5b794dc9c'),
    'cellular_projection_bridge_preparation_round237_20261008.md':
        (8483, 'a1ee6f1cc33bac6ccb860b8759320d39186c8e04b27fdcd4237f8193ee30bb40'),
    'research_round237_report_review_20261008.md':
        (2930, '5047dd893f991e5caf4dfaf2f53b361b2bc074ba95c2898a0b4e1cb408c78319'),
    'research_round237_metric_bridge_review_20261008.md':
        (2859, '8c04f1e0c92c6a98ae61508216be24e4e80dc46977b693513d00cf650cb4c64b'),
}
for name, (size, digest) in frozen.items():
    data = (root / 'research' / name).read_bytes()
    assert len(data) == size and sha(data) == digest, name

report_review = (root / 'research/research_round237_report_review_20261008.md').read_text(encoding='utf-8-sig')
assert 'PASS' in report_review and sha(body) in report_review
independent_review = root / 'research/research_round237_independent_check_20261008.md'
review_text = independent_review.read_text(encoding='utf-8-sig')
assert 'PASS' in review_text
assert frozen['joint_lattice_metric_independent_round237_20261008.md'][1] in review_text

files = set((root / 'research').glob('*round237*20261008.*'))
files.update((root / 'literature/joint_lattice_metric_sources_round237_20261008').glob('*'))
records = [pin(p) for p in sorted(files) if p.is_file()]
primary_paths = [
    'literature/global_review_sources_round228_20261008/packet_cdt_L2chi_current_author.pdf',
    'literature/brown2014_irrationality_moduli.pdf',
    'literature/brown2012_mixed_tate_motives.pdf',
    'literature/brown_zudilin_cellular.pdf',
]
primaries = [pin(root / p) for p in primary_paths]
assert primaries[0]['sha256'] == '9d778fc22f82fb064371722ff457d54a2fc787608b8493ed9893a8fd39929a1c'
combined = old + b'\n\n' + body
manifest = {
    'round': 237, 'date': '2026-10-08', 'classification': 'progress',
    'goal_status': 'active', 'previous_goal_turn_classification': 'progress',
    'numerical_irrationality_or_independence_theorem': False,
    'paid': [
        'Direct same-metric full-jet BC filtered bridge: upper fee 2*kappa/m^2; rank three 2*kappa/9.',
        'Exact source-lattice index and graded finite heights cancel for a fixed complete rational flag.',
        'Intrinsic arithmetic defect A_D=-log|det T_actual-jumps|; safe full integrality gives A_D<=log index.',
        'Alternative fixed M0,10 actual all-n eleven-channel ambient input; six-channel uniform projection remains unpaid.',
    ],
    'not_paid': [
        'All-scale actual-jump determinant/graded finite-height bound beating the same analytic budget.',
        'Strict arithmetic-analytic margin or new numerical theorem.',
        'Global novelty, full-repository proof verification, six-channel cellular projection or rank-four certification.',
    ],
    'safe_crt_model': {'kappa_upper': '45/4', 'rank3_fee_upper': '5/2',
                       'interpretation': 'A sufficient upper, not an intrinsic lower or a no-go.'},
    'next_action': 'Round238: all-scale actual-jump determinant or equivalent full graded arithmetic defect, then same-map basic/convex strict comparison. Stop blind CRT/Smith optimization.',
    'formal_global_review': {'last': 236, 'next_default': 242, 'window': [240, 244]},
    'mathematical_program_runs': 0, 'parameter_scans': 0,
    'new_saved_pdf_downloads': 0, 'git_mutations': 0, 'lean_builds': 0,
    'documentary_archive_attempts': 1,
    'documentary_errors': 'Read-only sandbox helper ACL startup failure was resolved with narrow escalation; agent text/patch parsing errors are recorded in reading scopes. No approval rejection.',
    'previous_manifest': pin(previous), 'previous_main': pin(main),
    'report': pin(report), 'files': records, 'reused_primary_files': primaries,
    'main_after': {'path': main.relative_to(root).as_posix(),
                   'bytes': len(combined), 'sha256': sha(combined)},
}
serialized = (json.dumps(manifest, ensure_ascii=False, indent=2) + '\n').encode('utf-8')
main.write_bytes(combined)
dest.write_bytes(serialized)
assert main.read_bytes()[:len(old)] == old
assert sha(main.read_bytes()) == manifest['main_after']['sha256']
assert json.loads(dest.read_text(encoding='utf-8'))['main_after'] == manifest['main_after']
print(json.dumps({'status': 'PASS', 'round': 237, 'file_pins': len(records),
                  'main_after': manifest['main_after'], 'manifest': pin(dest)}, ensure_ascii=False))
