"""One-shot documentary archive of formal global review260; never rerun."""
from pathlib import Path
import hashlib
import json

ROOT = Path(__file__).resolve().parents[1]
assert ROOT == Path(r"E:\kimi-build\zeta5").resolve()
PREVIOUS = ROOT / "literature/manifest_source_selection_round259_20261010.json"
MANIFEST = ROOT / "literature/manifest_global_review_round260_20261010.json"
MAIN = ROOT / "research/cdt_odd_background_progress_20261006.md"
POLICY = ROOT / "research/research_global_review_policy.md"
REPORT = ROOT / "research/research_global_review_progress_round260_20261010.md"
REVIEW = ROOT / "research/research_round260_global_review_20261010.md"
SOURCES = ROOT / "literature/global_review_round260_20261010"
REVIEW_SHA = "413a772d2cadb84a3d548d0b9f6bdbd1ff741cd32f2980c20fa030ca5439626c"
MATH = [ROOT / "research" / name for name in [
    "research_global_review_round260_20261010.md",
    "global_review_mixed_analytic_round260_20261010.md",
    "global_review_mixed_arithmetic_round260_20261010.md",
    "global_review_architecture_round260_20261010.md",
]]
SCOPES = [SOURCES / f"{name}_reading_scope.md" for name in ["root", "analytic", "arithmetic", "architecture"]]


def digest(data):
    return hashlib.sha256(data).hexdigest()


def pin(path):
    data = path.read_bytes()
    return {"path": path.relative_to(ROOT).as_posix(), "bytes": len(data), "sha256": digest(data)}


def verify(path, size, sha):
    data = path.read_bytes()
    assert len(data) == size and digest(data) == sha, str(path)
    return data


assert not MANIFEST.exists(), "260 already archived; do not rerun"
previous_data = verify(PREVIOUS, 46123, "41036e78bc72e0e55c34fbdecb16b4b66dee5a0748ee7da4da8ff0019d2eadc2")
previous = json.loads(previous_data)
assert previous["round"] == 259 and len(previous["files"]) == 193
assert previous["formal_global_review"]["last"] == 256
assert previous["formal_global_review"]["completed_rounds_since_last"] == 3
for item in previous["files"]:
    verify(ROOT / item["path"], item["bytes"], item["sha256"])
old_main = verify(MAIN, 768449, "1b49490523075dc6c1e87d717e1caa5f35944a31669df7cd77c47db04282e0d0")
old_policy = verify(POLICY, 41073, "0d394b8b006ea756f45743bf5d61653ffe22c2150765d69b2e397c3d8a921e2c")
review_data = REVIEW.read_bytes()
assert REVIEW_SHA != "PENDING" and digest(review_data) == REVIEW_SHA
review_text = review_data.decode("utf-8-sig").lower()
assert "pass" in review_text
for path in MATH + SCOPES + [REPORT]:
    assert path.is_file() and pin(path)["sha256"] in review_text, str(path)
root_scope = SCOPES[0].read_text(encoding="utf-8-sig").lower()
assert "独立数学复核" in root_scope
for path in MATH[2:]:
    assert pin(path)["sha256"] in root_scope, str(path)
report_data = REPORT.read_bytes()
assert report_data not in old_main
assert "## 第260轮".encode("utf-8") not in old_policy
paths = {ROOT / item["path"] for item in previous["files"] if item["path"] != "research/research_global_review_policy.md"}
paths.update([PREVIOUS, POLICY, REPORT, REVIEW, Path(__file__)])
paths.update(MATH)
paths.update(SOURCES.iterdir())
assert all(path.is_file() for path in paths)

policy_append = """

## 第260轮：正式全局复盘与两个安全入口的停止

落实用户每4–8完成轮俯瞰全局：默认4，最迟8，连续2轮核心准入或净可行性不推进提前。实际完成256之后257–260四轮，本轮是正式复盘并reset：last260、previous256、count0、next264、latest268。局部引理、稿件与归档数量不算数值成功或停滞时钟的抵消。总目标active，新数值定理false。

固定mixed来源的r=±i全部到达叶含首系数−d r0/32的log²t；有限ramification不能取消。bare rank3 holomorphic共同图必避s=(1±i)/2。原文factor2 Landau与Gamma严格积分界给φ′<35/4，未精化safe τ16/9要求λ>8/3，故关闭该具体入口；无需继续其全cusp分类或图扫描。解析代理三次transport断流后Root接手，独立审阅发现不足Taylor0–4截断并已改0–5，不改变strict决定。

CDT pure7沿实际degree4整数s拉回的独立性、与mixed SL2模块交集仅1、actual rank9及每N全部prime powers三列safe τ173/81付清。pure log在四个t∞fiber不能meromorphic填；实两点已给φ′<11/2，故λ<τ，正denominator都不能满足。该safe9扩充入口停止。原14/17族不能借其rank/type/map；更多辅助行不免费。holomorphic φ条件由CDT7.0.1明文支付，不把两有限省略值界扩给meromorphic φ。

跨架构没有发现足以重开固定native χ8、RV、χ7 Fricke、classic Li2、weight≤7 KZ或重复level14窗口的新whole-object机制。各架构按自身非零/整模型/几何账本结算，不把product-formula Δn无界非零强加给已付bare holonomy。Deligne–Drinfeld代数自由性没有直接数值独立结论。新ζ7 Lean仓库固定commit只有示例Basic定义，coverage为MAPPED，不算新的证明；不重跑旧审计，不声称全部ζ7文章失败或全球尚无其它证明。

261唯一允许首证书：固定bare3来源的原文refined联合预算。先核全前缀实际降费δ与合法同图convexity correction Cφ能否超过必要门槛3δ+Cφ>16/3−2log(35/4)，同时有正denominator。只换到§8不自动降两嵌套列τ16/9。pure9若作对照必须先实际降低费用超过173/81−log(11/2)，光convexity不能满足当前size；不准入其默认实现。261一次有界纸面审查，无图/参数/prime/Padé扫描；没有已证足够new core就停止该同源实现默认投入，在下一正式复盘选择不同完整来源，不能通过坐标改名、加行、局部lemma延长窗口。上述门槛只是必要，不是已获充分预算或所有refined criterion的no-go。

四数学稿、report、四精确scope与唯一独审后单次归档；Root独核arithmetic与architecture，不把自身analytic/gate称独审，reviewer核其它稿与report且不自审architecture。259全部193 pins先核，192非policy旧输入、旧main/policy字节前缀保留。本轮团队数学程序、CAS、数值/interval、map/parameter/prime/word扫描、Padé、Lean、外Git写、旧producer均0；文档提取/渲染/下载/hash与单次归档另记，不冒称全网络0、整篇PDF/全仓库数学或Lean认证、全球新颖性、与云端最新一致。
""".encode("utf-8")

POLICY.write_bytes(old_policy + policy_append)
MAIN.write_bytes(old_main + b"\n\n" + report_data)
assert MAIN.read_bytes()[:len(old_main)] == old_main
assert POLICY.read_bytes()[:len(old_policy)] == old_policy
assert MAIN.read_bytes().count(report_data) == 1
for item in previous["files"]:
    if item["path"] != "research/research_global_review_policy.md":
        verify(ROOT / item["path"], item["bytes"], item["sha256"])
manifest = {
    "round": 260, "date_completed": "2026-10-10", "classification": "progress", "goal_status": "active",
    "new_numerical_irrationality_or_independence_theorem": False,
    "global_novelty_or_full_lean_audit": False,
    "formal_global_review": {"last": 260, "previous_formal": 256, "this_round_is_formal": True, "counter_reset_this_round": True, "completed_rounds_since_last": 0, "next_scheduled": 264, "latest_required": 268, "default_interval": 4, "maximum_interval": 8, "early_core_stagnation_rounds": 2},
    "paid_this_round": ["All arriving leaves nonzero log-square at two mixed fibers", "Primary-certified holomorphic Landau derivative cap", "Fixed bare safe/unrefined entry exclusion", "Actual pure7 independence on minimal forcing field", "Actual expanded rank9 and whole-prefix safe type173/81", "Pure logarithmic fiber omissions and derivative cap11/2", "Fixed safe9 positive-denominator entry exclusion", "Architecture-specific opportunity-cost review and fixed primary claim audit"],
    "admission": {"bare_safe_unrefined": "stopped by derivative cap", "pure9_safe_unrefined": "stopped even before positive denominator", "refined_interface": "not admitted; bounded necessary-budget certificate only", "implementation_admitted": False, "strict_same_object_budget_paid": False, "general_method_impossibility": False},
    "stopped_default_windows": previous["stopped_default_windows"] + ["Fixed mixed bare rank3 safe16/9 holomorphic unrefined entry", "Fixed same-source pure7+mixed rank9 safe173/81 holomorphic unrefined entry"],
    "next_unique_work": {"round": 261, "scope": "Single bounded paper audit of fixed bare rank3 refined joint arithmetic and convexity budget before any implementation", "necessary_gain": "3 delta + C_phi > 16/3 - 2 log(35/4), and positive denominator", "pure9_comparison": "Must first pay actual whole-prefix fee cut beyond173/81-log(11/2)", "automatic_implementation_or_scan": False, "stop_condition": "No certified sufficient same-object refined fee/correction mechanism in this bounded audit; close default fixed-source implementation window"},
    "runs": {"team_math_programs": 0, "cas": 0, "finite_n_numerical_or_interval": 0, "prime_parameter_map_word_scans": 0, "pade_matrix_implementation": 0, "lean": 0, "external_git_mutations": 0, "old_archive_producers": 0, "this_documentary_archive": 1},
    "sources": {"precise_scopes": [pin(path) for path in SCOPES], "whole_primary_paper_reading_claim": False, "fresh_cloud_repository_equality_claim": False, "mathematics_not_inferred_from_hashes": True},
    "previous_manifest": pin(PREVIOUS), "previous_manifest_nonpolicy_files_preserved": 192,
    "report": pin(REPORT), "independent_math_and_report_review": pin(REVIEW),
    "previous_policy": {"bytes": len(old_policy), "sha256": digest(old_policy)}, "new_policy": pin(POLICY),
    "previous_main": {"bytes": len(old_main), "sha256": digest(old_main)}, "new_main": pin(MAIN),
    "files": [pin(path) for path in sorted(paths)],
}
MANIFEST.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
assert PREVIOUS.read_bytes() == previous_data and REVIEW.read_bytes() == review_data
print(json.dumps({"status": "PASS", "files": len(paths), "old_nonpolicy_preserved": 192, "numeric_theorem": False, "count": 0, "next_formal": 264, "latest_formal": 268, "manifest": pin(MANIFEST), "main": pin(MAIN), "policy": pin(POLICY)}, ensure_ascii=False))
