"""Archive the fixed primary versions selected for the 2026-10-05 log-moment research."""
from datetime import datetime, timezone
from concurrent.futures import ThreadPoolExecutor
import json
import archive_global_literature_20261004 as base
CONFIG = base.LIBRARY / "log_moment_sources_20261005.json"
MANIFEST = base.LIBRARY / "manifest_log_moment_20261005.json"
if MANIFEST.exists():
    base.PREVIOUS = {r["file"]:r for r in json.loads(MANIFEST.read_text(encoding="utf-8"))["sources"]}
else:
    base.PREVIOUS = {}
def main():
    sources=json.loads(CONFIG.read_text(encoding="utf-8"))["sources"]
    with ThreadPoolExecutor(max_workers=2) as pool:
        results=list(pool.map(base.archive,sources))
    for record in results:
        print(record["file"],record["archive_status"],record.get("pages"),flush=True)
    MANIFEST.write_text(json.dumps({
        "as_of":"2026-10-05","created_at_utc":datetime.now(timezone.utc).isoformat(),
        "validation":"Original bytes; PDF signature; pypdf parse; page count; first-page excerpt; SHA-256",
        "sources":results,
    },ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
    failed=[r["file"] for r in results if r["archive_status"]=="failed"]
    if failed:
        raise RuntimeError(failed)
if __name__=="__main__":
    main()

