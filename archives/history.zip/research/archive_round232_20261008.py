"""One-shot documentary archive; no mathematical producer calls."""
from pathlib import Path
import hashlib
import json
import re

root = Path(__file__).resolve().parent.parent
main = root / "research/cdt_odd_background_progress_20261006.md"
report = root / "research/research_global_review_round232_20261008.md"
previous = root / "literature/manifest_boundary_structure_round231_20261008.json"
dest = root / "literature/manifest_global_review_round232_20261008.json"
old_size = 584048
old_sha = "7608bd50d7c00d5b078ef3383cda40a5b971caa16dca1ee6305cbdb636561ab0"
prev_sha = "413e7b825320146fd418a5be7fa4566c15fc1509705a43c709099952ae7323b1"
report_sha = "bc76a5237ee5c64a053f502a6af3fb7772e63811dee036cd9458596c6e51f0b8"

def sha(data):
    return hashlib.sha256(data).hexdigest()

old, body = main.read_bytes(), report.read_bytes()
assert len(old) == old_size and sha(old) == old_sha, "Main prefix changed"
assert sha(previous.read_bytes()) == prev_sha, "Predecessor changed"
assert sha(body) == report_sha, "Report changed"
assert not dest.exists(), "Do not rerun a completed archive"

files = sorted({*root.joinpath("research").glob("*round232*20261008.*"),
                *root.joinpath("literature/global_review_sources_round232_20261008").glob("*")})
pins = []
for path in files:
    if not path.is_file():
        continue
    data = path.read_bytes()
    if path.suffix == ".md":
        text = data.decode("utf-8-sig")
        assert not any(ord(c) < 32 and c not in "\r\n\t" for c in text), path
    pins.append({"path": path.relative_to(root).as_posix(),
                 "bytes": len(data), "sha256": sha(data)})

links = []
for target in re.findall(r"\]\(([^)]+)\)", body.decode("utf-8-sig")):
    if target.startswith(("http:", "https:", "#")):
        continue
    assert (report.parent / target.split("#", 1)[0]).resolve().is_file(), target
    links.append(target)

combined = old + b"\n\n" + body
manifest = {
    "round": 232, "date": "2026-10-08", "status": "progress",
    "previous_goal_turn_classification": "progress",
    "mathematical_program_runs": 0, "mathematical_program_failures": 0,
    "git_mutations": 0, "lean_builds": 0,
    "mathematical_status": "Formal global review; same-W mixed Pade/Kronecker and actual evaluation denominator gates proved; direct truncated V source has complete period stack, all-scale rational projection and all-prime safe LCD; no new numerical irrationality theorem",
    "global_review_cadence": {"previous_formal": 228, "last_formal": 232,
                              "elapsed_rounds": 4, "default_next": 238,
                              "window": [236, 240], "reset_by_this_round": True,
                              "tactical_stop_check": "After two rounds without core-interface progress, stop/reassess locally without resetting formal cadence"},
    "next_interface": "One bounded round233 for the direct truncated V source: actual projected and conjugate nonzero, same-object complete arithmetic cost and support-sensitive real gain; no automatic six-round optimization",
    "verification_scope": "New document identities and current local report links; predecessor identity and main preserved prefix only; no old producer/archive or historical pin audits rerun",
    "predecessor": {"path": previous.relative_to(root).as_posix(), "bytes": previous.stat().st_size, "sha256": prev_sha},
    "main_preserved_prefix": {"bytes": old_size, "sha256": old_sha},
    "appended_report": {"path": report.relative_to(root).as_posix(), "bytes": len(body), "sha256": report_sha},
    "main_after_append": {"path": main.relative_to(root).as_posix(), "bytes": len(combined), "sha256": sha(combined)},
    "source_scope": "One new primary Kronecker PDF and selected texts; reused CDT and repository source scopes recorded separately; no full-paper/global novelty/whole-repository or Lean certification",
    "repository_state": "Readonly fresh remote main equals clean local HEAD fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb; zero Git mutations",
    "report_links_checked": links, "new_pins": pins,
}
dest.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
main.write_bytes(combined)
assert main.read_bytes() == combined
print(json.dumps({"status": "PASS", "round": 232, "pins": len(pins),
                  "report_links": len(links), "mathematical_runs": 0,
                  "main_bytes": len(combined), "main_sha256": sha(combined),
                  "manifest_bytes": dest.stat().st_size, "manifest_sha256": sha(dest.read_bytes())}, ensure_ascii=False))
