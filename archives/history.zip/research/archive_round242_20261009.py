"""One-shot documentary archive: byte identities only, no mathematical execution."""
from pathlib import Path
import hashlib
import json

root = Path(__file__).resolve().parent.parent
assert root == Path('E:/kimi-build/zeta5').resolve()
main = root / 'research/cdt_odd_background_progress_20261006.md'
report = root / 'research/research_logistic_gauss_progress_round242_20261009.md'
proof = root / 'research/logistic_gauss_graded_head_round242_20261009.md'
rate = root / 'research/logistic_gauss_rate_round242_20261009.md'
policy = root / 'research/research_global_review_policy.md'
previous = root / 'literature/manifest_logistic_prime_edge_round241_20261008.json'
source_dir = root / 'literature/logistic_gauss_budget_round242_20261009'
destination = root / 'literature/manifest_logistic_gauss_budget_round242_20261009.json'


def digest(data):
    return hashlib.sha256(data).hexdigest()


def pin(path):
    data = path.read_bytes()
    return {'path': path.relative_to(root).as_posix(), 'bytes': len(data),
            'sha256': digest(data)}


assert not destination.exists(), 'Do not rerun a completed producer'
old = main.read_bytes()
assert len(old) == 654733
assert digest(old) == '43cf5b7f45b6991b3c5c21515eaab48cfd6cfd672032b05b89baa5dc283e1ad7'
assert digest(previous.read_bytes()) == '1422d90cdb98d92c882e02d675e761a778fdeabcaa3dcd1bca88dac71030e107'
assert pin(proof)['sha256'] == '1daeea8510afa88179d877bbd1a68481ea225d06b4020156411120fd09d46ca5'
assert pin(report)['sha256'] == 'b82eb3821dd08a2084243aaf1e833c00f47c2a6038c790e6a4e42f1177cf26ae'
assert pin(rate)['sha256'] == '30b39e40c5581e495cc96e18a903b36ea46354fd7c6cba3d658a48092f2b4631'

review_targets = {
    'research/research_round242_graded_head_review_20261009.md': proof,
    'research/logistic_gauss_outer_strong_head_round242_20261009.md': proof,
    'research/research_round242_gauss_rate_review_20261009.md': rate,
    'research/research_round242_progress_review_20261009.md': report,
}
for review, target in review_targets.items():
    receipt = (root / review).read_text(encoding='utf-8-sig')
    assert 'PASS' in receipt and digest(target.read_bytes()) in receipt, review

files = set((root / 'research').glob('*round242*20261009.*'))
files.update(p for p in source_dir.rglob('*') if p.is_file())
files.add(policy)
records = [pin(p) for p in sorted(files)]
body = report.read_bytes()
combined = old + b'\n\n' + body
manifest = {
    'round': 242, 'date': '2026-10-09', 'classification': 'progress',
    'goal_status': 'active', 'new_numerical_irrationality_or_independence_theorem': False,
    'formal_global_review': {'last': 240, 'counter_reset_this_round': False,
                            'next_scheduled': 244, 'interval': 4,
                            'reason': 'Align global review with the bounded 241-244 main window.'},
    'object': {'target': '3 zeta(3) + zeta(5)', 'kernel': 'D_n^4 / D_(5n)',
               'matrix_size': '3n', 'normalization': 'Qtilde = S_n^(3n) Q_n / F_n',
               'primitive_ratio': 'P_n = d_n Qtilde, positive rational d_n'},
    'paid': [
        'Whole-coefficient greedy CRT lower bound for p^2>5n, all pairs and other residue classes.',
        'Whole binomial basis preserves F_n and bounds all small prime powers by o(n^2).',
        'All integer-polynomial residue moments are multiples of S_n; class moments obtained by integer Euler indicators.',
        'All non-p harmonic heads have graded polynomial expansions giving weighted head valuation at least floor(5n/p) for n<p<=5n, p>=11.',
        'Complete remainder W_p(T) is divisible by p^max(1,floor(5n/p)-1), including quotient and parameter coefficients.',
        'Whole-coefficient double-minor/Vandermonde bound preserves S_n and F_n and gives signed outer leading upper 12.',
        'Whole-prime net upper log d_n <= (1009/40+o(1)) n^2 on Q_n nonzero scales, with inherited unbounded scales from round241.',
        'Independent full paper reviews of the strong head, macroscopic rate, and final progress report.',
    ],
    'not_paid': [
        'Strict same-object whole-prime rate below 6.',
        'Complete independent certification of the original -6 analytic FstarInput.',
        'A new numerical irrationality or linear independence theorem.',
        'Lean kernel verification, complete import/repository audit, remote freshness, or global novelty.',
    ],
    'arithmetic_upper': {'inner': '529/40', 'outer': '12', 'whole': '1009/40',
                         'outer_3_to_5': '0', 'dominant_outer_2_to_3': '53/8',
                         'selected_upper_profile_integral_lower': '36/5',
                         'selected_profile_lower_is_actual_fee_lower': False},
    'correction': 'The proposed s=3 total-rank saving was withdrawn: negative-slot count is 4n-p<h; final profile retains 2+2x.',
    'bounded_main_window': [241, 244],
    'next_gate': 'Round243: same complete filtered residual determinant, all coefficients, extra macroscopic Gauss content especially on 2n<p<3n; no extra prime sampling.',
    'sources': {'pinned_repository': 'dtq1997/zeta2-zeta3-linear-independence',
                'pinned_commit': '669c92bf7a3728e0de9ad80c373bc29fb5ca3d58',
                'root_new_downloads': 0,
                'scope_records': [pin(source_dir / name) for name in
                    ['root_reading_scope.md', 'alternative_reading_scope.md',
                     'dual_reading_scope.md', 'dual_strong_head_reading_scope.md',
                     'packet_reading_scope.md']]},
    'runs': {'mathematics': 0, 'cas_or_interval': 0, 'prime_or_parameter_scans': 0,
             'lean': 0, 'git_mutations': 0, 'old_archive_producers': 0,
             'this_documentary_archive': 1},
    'previous_manifest': pin(previous),
    'previous_main': {'bytes': len(old), 'sha256': digest(old)},
    'report': pin(report), 'strong_certificate': pin(proof), 'rate': pin(rate),
    'new_main': {'path': main.relative_to(root).as_posix(),
                 'bytes': len(combined), 'sha256': digest(combined)},
    'files': records,
}
main.write_bytes(combined)
destination.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
assert main.read_bytes()[:len(old)] == old
assert main.read_bytes()[len(old):] == b'\n\n' + body
for entry in records:
    assert pin(root / entry['path']) == entry
print(json.dumps({'status': 'PASS', 'manifest': pin(destination),
                  'main': pin(main), 'pinned_files': len(records)}, ensure_ascii=False))
