"""NEW primary archive utility for one exact Bailey confluence input.

No frozen or peer mathematical producer is executed or imported.
"""
from pathlib import Path
import hashlib
import json
import subprocess
import fitz

root=Path(__file__).resolve().parents[1]
name='mccrorie2020_pearson_vwp_bailey_published_20261006.pdf'
url='https://link.springer.com/content/pdf/10.1007/s13571-020-00230-1.pdf'
target=root/'literature'/name
if target.exists():
    raise RuntimeError('Do not overwrite a primary snapshot.')
subprocess.run(['curl.exe','--fail','--location','--silent','--show-error',
                '--max-time','45','--output',str(target),url],check=True)
data=target.read_bytes()
if not data.startswith(b'%PDF-'):
    raise RuntimeError('Primary download is not PDF.')
with fitz.open(target) as doc:
    pages=len(doc)
    first=doc[0].get_text()
    if 'McCrorie' not in first:
        raise RuntimeError('Author identity not verified; retain snapshot for investigation.')
    marked=[]
    for i in range(len(doc)):
        txt=doc[i].get_text()
        if '(A.1)' in txt or '(A.2)' in txt:
            marked.append((i+1,txt))
manifest={
    'date':'2026-10-06',
    'scope':'One primary published PDF for Bailey nonterminating 7F6 decomposition. A formula input, not a new irrationality theorem or integral comparison.',
    'resources':[{
        'file':'literature/'+name,'source_url':url,
        'title':"Moments in Pearson's Four-Step Uniform Random Walk Problem and Other Applications of Very Well-Poised Generalized Hypergeometric Series",
        'author':'J. Roderick McCrorie','doi':'10.1007/s13571-020-00230-1',
        'version':'Publisher PDF downloaded 2026-10-06; title-page publication metadata checked.',
        'pages':pages,'sha256':hashlib.sha256(data).hexdigest(),
        'actual_read':'Primary publisher web Appendix A.1/A.2; local title page and listed formula pages emitted for actual review, not full-PDF reading.',
        'local_formula_pages_emitted':[p for p,_ in marked],
    }],
    'execution_history':'First run failed at urllib TLS issuer verification before writing a snapshot. Second run uses native Windows curl/Schannel with certificate verification retained; no old or peer research producer run/imported.',
}
path=root/'literature'/'manifest_cdt_odd_bailey_confluence_20261006.json'
if path.exists():
    raise RuntimeError('Do not replace an existing manifest.')
path.write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'file':name,'pages':pages,'sha256':manifest['resources'][0]['sha256']}))
print(first)
for page,txt in marked:
    print('PDF PAGE',page)
    print(txt)
