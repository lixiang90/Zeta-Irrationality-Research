"""One-shot documentary archive for formal review 248; no math or Git runs."""
from pathlib import Path
import hashlib
import json

ROOT = Path(__file__).resolve().parents[1]
assert ROOT == Path(r"E:\kimi-build\zeta5").resolve()
MANIFEST = ROOT / "literature/manifest_global_review_round248_20261010.json"
assert not MANIFEST.exists(), "Completed archive must not be rerun"
PREVIOUS = ROOT / "literature/manifest_dyadic_period_round247_20261010.json"
MAIN = ROOT / "research/cdt_odd_background_progress_20261006.md"
POLICY = ROOT / "research/research_global_review_policy.md"
REPORT = ROOT / "research/research_global_review_round248_20261010.md"
REVIEW = ROOT / "research/research_round248_elliptic_quotient_review_20261010.md"


def digest(data):
    return hashlib.sha256(data).hexdigest()


def pin(path):
    data = path.read_bytes()
    return {"path": path.relative_to(ROOT).as_posix(), "bytes": len(data), "sha256": digest(data)}


def verify(path, size, sha):
    data = path.read_bytes()
    assert len(data) == size and digest(data) == sha, str(path)
    return data


previous_data = verify(PREVIOUS, 9316, "1e65ee84f5b8e4de67802ede8bb6e00b2d527966e12f8534ac3a177f6fd916cd")
previous = json.loads(previous_data)
for item in previous["files"]:
    verify(ROOT / item["path"], item["bytes"], item["sha256"])
old_main = verify(MAIN, 691687, "49e4c242efab1840304f07d76ce976e44de22b3c695cc6446341d28c39b7f5c7")
old_policy = verify(POLICY, 12674, "8bb1c5a65b9b930a49b1c1aedea56b4bb34b74ddc0e9638a5c535013ba392ff8")
report_data = verify(REPORT, 7851, "0efe88842e82a1b6cec326a9d753ace0187ebc53a6b049b399e42879b9a825c1")

for name, size, sha in [
    ("dyadic_elliptic_uniform_cap_round248_20261010.md", 8699, "ae596e99d2d477a766746c0392ff6938070d70fcc5fff85acc066ec5c947d72c"),
    ("chi7_fricke_quotient_source_round248_20261010.md", 12413, "a95eda931df3fcf8042376b5a49d66bb60f8622f2772e3548178a176a853912b"),
    ("dyadic_field_lift_energy_gate_round248_20261010.md", 8082, "6013b87cf706b9aab3227fd994ff56230f12956673492f609b4f1d7f7126b603"),
    ("global_growth_period_comparison_round248_20261010.md", 7892, "98595cf9a440d808022acc167f28603ceef89f98038643fe34adb5c832c7aee3"),
]:
    verify(ROOT / "research" / name, size, sha)

# Exactly one combined final math/report review, tied to the frozen sources.
verify(REVIEW, 7723, "88cc45c474283714c6851735043ab69d265f2a72e0b5551e97e77900b6756cac")
review_text = REVIEW.read_text(encoding="utf-8-sig")
for sha in [
    "ae596e99d2d477a766746c0392ff6938070d70fcc5fff85acc066ec5c947d72c",
    "a95eda931df3fcf8042376b5a49d66bb60f8622f2772e3548178a176a853912b",
    "0efe88842e82a1b6cec326a9d753ace0187ebc53a6b049b399e42879b9a825c1",
]:
    assert sha in review_text, "Final review must cover this source/report"
assert "PASS" in review_text and "252" in review_text

policy_append = """

## 第248轮正式复盘：全图止损与唯一新源准入

248正式俯瞰，距244四个完成轮次。原level14全五行源的三行整数field强制J≥3λ；完整d_N²数组为5×2、两列(0,0,0,1,1)，行和(0,0,0,2,2)，τ32/25。严格基本入口必要λ>16/5，而真实eta微分、精确Weierstrass桥、闭周期积分界与Bloch引理证明所有共同合法图|φ′(0)|<20，故λ<3。立即停止原x、当前安全数组、基本单实处的地图/prime/参数优化。范围不外推到最优joint整型、新商坐标、多place或增长矩阵；247“单列”记法在新稿澄清，旧稿冻结。

本轮另一实际进展是Q上Fricke Hauptmodul和K=Q√2上的有理二阶forcing、全三行rank3/nonrecovery、7b d_N²全prefix模型。完整系数共轭不把g+∈K变为bar g=g−；双方指定canonical叶免费补点会推出π²代数，不能偷用。商genus0也不免费支付合法图或strict差额。

唯一有界准入249–250固定新商源及数值出口g+=L(2,χ−7)/2+√2π²/28∉Q√2。第一证书是实际Γ/W周期系数矩阵、四branchpoints/cusps的全部返回叶，以及同一源全数域CDT条件、所有嵌入和有限/实处费用的必要比较。未通过不做map/prime/参数/LCD扫描。结构失配立即停；连续两轮不缩小这些核心缺口，250结束窗口，不自动延长。真正改变strict比较的核心证书才允许在252复盘前有界完成剩余关。

K5、χ−7增长矩阵和原M₀,₁₀保持条件后备：前者1511/60是所选upper而非actual lower；外国Schur首关只有宏观线性内容才能改善n²费用；relative源须完整全n投影。形式Deligne–Drinfeld自由性不是数值period单射性。本轮官方HEAD与本地一致，目录未找到all-odd-ζ数值解决家族，未核全部论文/Lean或全球新颖性。

正式计数从248重置；下一次固定252，隔4完成轮次。连续两轮无核心进展提前方向检查，最迟8轮规则不变。每轮报告核心缺口变化与数值结果，不把重新包装源或新计划计为数值成功。详细正式报告research_global_review_round248_20261010.md；总目标active，无新数值无理性/线性无关性定理。
""".encode("utf-8")

assert "## 第248轮".encode("utf-8") not in old_policy
assert report_data not in old_main
new_policy = old_policy + policy_append
new_main = old_main + b"\n\n" + report_data

# All prerequisites are checked before touching either append-only authority.
POLICY.write_bytes(new_policy)
MAIN.write_bytes(new_main)
assert POLICY.read_bytes()[:len(old_policy)] == old_policy
assert MAIN.read_bytes()[:len(old_main)] == old_main
assert MAIN.read_bytes().count(report_data) == 1

paths = set((ROOT / "research").glob("*round248*20261010*"))
paths.update((ROOT / "literature/global_review_sources_round248_20261010").iterdir())
paths.add(POLICY)
files = [pin(path) for path in sorted(paths) if path.is_file()]
manifest = {
    "round": 248,
    "date_completed": "2026-10-10",
    "classification": "progress",
    "progress_kind": "New structural cap/source/Schur proofs; no numerical theorem",
    "previous_goal_turn_classification": "progress",
    "goal_status": "active",
    "new_numerical_irrationality_or_independence_theorem": False,
    "formal_global_review": {"last": 244, "this_round_is_formal": True, "completed_rounds_since_last": 4, "counter_reset_this_round": True, "new_last": 248, "next_scheduled": 252},
    "closed_entry": {"coordinate": "x=u/(1+7u)", "frame": ["1", "Z", "Z^2", "H", "delta H"], "rank": 5, "lcm_array": [[0, 0], [0, 0], [0, 0], [1, 1], [1, 1]], "row_sums": [0, 0, 0, 2, 2], "safe_tau": "32/25", "required_log_derivative": ">16/5", "proved_all_map_cap": "|phi'(0)|<20, log derivative<3", "scope": "Original coordinate, paid safe complete array, basic single-real-place criterion; not optimal joint types or all methods"},
    "new_source": {"field": "K=Q(sqrt(2))", "coordinate": "t=(eta1 eta14/(eta2 eta7))^4", "source": "B_g=A_+(I_+-g)", "frame": ["1", "B_g", "delta B_g"], "actual_rank": 3, "numerical_target": "L(2,chi_-7)/2 + sqrt(2) pi^2/28 not in K", "safe_prefix": "7b d_N^2 over O_K; fixed bg integral", "operator": "Explicit second-order K(t) rational forcing", "full_period_projection_paid": False, "strict_budget_paid": False},
    "paid": [
        "Uniform cap for every legal old-field map from exact eta/Weierstrass differential and closed-period integral bounds plus elementary Bloch lemma",
        "Integer field energy lower and correct full LCM array with strict necessary threshold",
        "Actual genus-zero Fricke quotient, quadratic curve, explicit gauge/forcing, full rank three and nonrecovery",
        "Complete arithmetic prefixes and actual coefficient-conjugate response distinction",
        "Same-object foreign-window Gauss Schur saturation criterion and correct Gram comparison direction",
        "Fresh official cloud HEAD matching clean local repository and normalized fixed text",
        "Formal cross-route stop/admission decision and next review date"
    ],
    "not_paid": ["New numerical irrationality or independence", "Complete transported period coefficients/leaves for the new source", "All embeddings' legal maps and same-object strict number-field budget", "Optimal joint integral model", "Macroscopic Schur content or relative all-n projection", "Global novelty or full upstream proof/Lean certification", "All-method impossibility"],
    "resource_decision": {"old_five_row_basic_entry": "stop", "old_CM_entry": "remains stopped", "unique_admission_window": [249, 250], "source": "New rank-three Fricke quotient over Q(sqrt(2))", "first_certificate": "Whole period/leaves and conjugate functions, full number-field criterion and necessary budget", "two_core_stagnant_rounds": "End window and reconsider direction", "map_prime_parameter_or_lcd_scans_now": False, "conditional_reserves": ["K5 growing integer matrices", "chi_-7 growing integer matrices", "original M0,10 relative projector"]},
    "public_repository": {"commit": "fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb", "committer_date": "2026-10-08T05:20:00Z", "local_head_same": True, "local_tracked_clean": True, "four_texts_normalized_equal": True, "full_catalogue_or_papers_read": False, "all_odd_zeta_numeric_solution_found_in_selected_catalogue": False, "lean_run": False},
    "runs": {"mathematics": 0, "cas_or_interval": 0, "prime_parameter_or_map_scans": 0, "lean": 0, "external_git_mutations": 0, "old_archive_producers": 0, "this_documentary_archive": 1},
    "new_primary_carriers": {"official_pdf_saved": 1, "root_official_api_success": 1, "root_official_raw_text_success": 4, "savitt_direct_pdf_failures_403": 2, "scope": "Explicit per-reader theorem pages and catalogue entries; no full upstream proof or Lean claim"},
    "previous_manifest": pin(PREVIOUS),
    "previous_manifest_files_preserved": len(previous["files"])-1,
    "report": pin(REPORT),
    "independent_math_and_report_review": pin(REVIEW),
    "previous_policy": {"bytes": len(old_policy), "sha256": digest(old_policy)},
    "new_policy": pin(POLICY),
    "previous_main": {"bytes": len(old_main), "sha256": digest(old_main)},
    "new_main": pin(MAIN),
    "files": files,
}
MANIFEST.write_text(json.dumps(manifest, ensure_ascii=False, indent=2)+"\n", encoding="utf-8")
assert PREVIOUS.read_bytes() == previous_data
for item in previous["files"]:
    if item["path"] != "research/research_global_review_policy.md":
        verify(ROOT / item["path"], item["bytes"], item["sha256"])
print(json.dumps({"status": "PASS", "classification": "progress", "numeric_theorem": False, "goal": "active", "next_formal_review": 252, "files": len(files), "report": pin(REPORT), "main": pin(MAIN), "policy": pin(POLICY), "manifest": pin(MANIFEST)}, ensure_ascii=False))
