"""Archive two author-hosted references; never executes mathematical producers."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import fitz

root = Path(__file__).resolve().parents[1]
folder = root / 'literature'
items = [
    {
        'title': 'Algebraic Groups', 'author': 'J. S. Milne',
        'version': 'author-hosted corrected CUP2022 manuscript',
        'url': 'https://www.jmilne.org/math/Books/iAG2022.pdf',
        'filename': 'milne2022_algebraic_groups_author_20261006.pdf',
        'expected_pages': 659,
        'read_scope': 'Theorem3.34 printed75/PDF86; Corollary14.33 printed289/PDF300; Theorem22.42 printed478-479/PDF489-490. Other pages not claimed read.',
    },
    {
        'title': 'Introduction to the Galois Theory of Linear Differential Equations',
        'author': 'Michael F. Singer',
        'version': 'author-hosted LMS lectures, published2009, fixed downloaded snapshot',
        'url': 'https://singer.math.ncsu.edu/papers/LMSlectures.pdf',
        'filename': 'singer2009_differential_galois_lms_author_20261006.pdf',
        'expected_pages': 82,
        'read_scope': 'PV definition and matrix action, Theorem1.3.9, Corollary1.3.21, monodromy inclusion and Proposition1.3.27, PDF10-20. Other sections not claimed read.',
    },
]
records = []
for item in items:
    path = folder / item['filename']
    # Initial Python HTTPS acquisition failed before any file write because
    # its trust chain lacked an issuer certificate. Native PowerShell HTTPS
    # subsequently downloaded both declared files using Windows trust.
    assert path.is_file(), str(path)
    data = path.read_bytes()
    assert data.startswith(b'%PDF-'), item['filename']
    with fitz.open(stream=data, filetype='pdf') as doc:
        pages = len(doc)
    assert pages == item['expected_pages'], (item['filename'], pages)
    records.append({**item, 'file': 'literature/' + item['filename'],
                    'download_method': 'PowerShell Invoke-WebRequest with Windows HTTPS trust',
                    'pages': pages, 'bytes': len(data),
                    'sha256': hashlib.sha256(data).hexdigest()})
manifest = {'as_of': '2026-10-06',
            'retrieved_at_utc': datetime.now(timezone.utc).isoformat(),
            'acquisition_note': 'Initial urllib certificate-chain failure wrote no files; acquired both files with native Windows HTTPS without disabling certificate validation. This utility only checks the acquired PDF bytes and writes the receipt.',
            'scope': 'Primary algebraic-group and differential-Galois inputs for the new actual two-period affine closure proof; not a new numerical odd-zeta/L theorem.',
            'items': records}
(folder / 'manifest_cdt_odd_affine_galois_20261006.json').write_text(
    json.dumps(manifest, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'files': len(records), 'pages': sum(r['pages'] for r in records),
                  'sha256': {r['filename']: r['sha256'] for r in records}}, ensure_ascii=False))
