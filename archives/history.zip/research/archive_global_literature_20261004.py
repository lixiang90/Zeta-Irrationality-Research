"""Archive explicitly selected open primary PDFs, preserving existing originals."""
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
from hashlib import sha256
from pathlib import Path
import io
import json
import logging
import sys

import requests
from pypdf import PdfReader

sys.stdout.reconfigure(encoding='utf-8')
logging.getLogger('pypdf').setLevel(logging.ERROR)
ROOT = Path(__file__).resolve().parents[1]
LIBRARY = (ROOT / 'literature').resolve()
CONFIG = LIBRARY / 'global_sources_20261004.json'
MANIFEST = LIBRARY / 'manifest_global_20261004.json'
PREVIOUS = ({item['file']: item for item in json.loads(MANIFEST.read_text(encoding='utf-8'))['sources']}
            if MANIFEST.exists() else {})


def inspect(data):
    if b'%PDF-' not in data[:1024]:
        raise ValueError('Response is not a PDF')
    reader = PdfReader(io.BytesIO(data))
    encrypted = reader.is_encrypted
    if encrypted and not reader.decrypt(''):
        raise ValueError('PDF requires an access password')
    if not reader.pages:
        raise ValueError('Empty PDF')
    first = (reader.pages[0].extract_text() or '').strip()
    return {'bytes': len(data), 'pages': len(reader.pages), 'encrypted_with_empty_open_password': encrypted,
            'sha256': sha256(data).hexdigest(),
            'pdf_metadata': {str(k): str(v) for k, v in (reader.metadata or {}).items()},
            'first_page_excerpt': ' '.join(first.split())[:360]}


def archive(source):
    result = dict(source)
    filename = source['file']
    path = (LIBRARY / filename).resolve()
    if path.parent != LIBRARY or path.suffix != '.pdf':
        raise ValueError('Unsafe library filename')
    result['checked_at_utc'] = datetime.now(timezone.utc).isoformat()
    if path.exists():
        result.update(inspect(path.read_bytes()))
        result['archive_status'] = 'existing_preserved'
        result['source_pdf_url'] = None
        previous = PREVIOUS.get(filename, {})
        if previous.get('sha256') == result['sha256']:
            for field in ('source_pdf_url', 'resolved_pdf_url', 'first_archived_at_utc', 'first_archive_status'):
                if field in previous:
                    result[field] = previous[field]
            result.setdefault('first_archived_at_utc', previous.get('checked_at_utc'))
            result.setdefault('first_archive_status', previous.get('archive_status'))
        return result
    errors = []
    for url in source['pdf_urls']:
        try:
            response = requests.get(url, timeout=(15, 45),
                                    headers={'User-Agent': 'ResearchLibrary/1.0 (open primary paper archival)'})
            response.raise_for_status()
            data = response.content
            details = inspect(data)
            part = path.with_suffix('.pdf.part')
            part.write_bytes(data)
            if path.exists():
                raise FileExistsError('Refusing to overwrite existing original')
            part.rename(path)
            result.update(details)
            result.update(archive_status='downloaded', source_pdf_url=url,
                          resolved_pdf_url=response.url)
            result['first_archived_at_utc'] = result['checked_at_utc']
            result['first_archive_status'] = 'downloaded'
            return result
        except Exception as exc:
            errors.append({'url': url, 'error': str(exc)[:300]})
    result.update(archive_status='failed', errors=errors)
    return result


if __name__ == '__main__':
    config = json.loads(CONFIG.read_text(encoding='utf-8'))
    sources = config['sources']
    completed = {}
    with ThreadPoolExecutor(max_workers=3) as pool:
        futures = {pool.submit(archive, source): source['file'] for source in sources}
        for future in as_completed(futures):
            filename = futures[future]
            try:
                result = future.result()
            except Exception as exc:
                result = {'file': filename, 'archive_status': 'failed', 'error': str(exc)}
            completed[filename] = result
            print(filename, result['archive_status'], result.get('pages', ''), flush=True)
    manifest = {'as_of': config['as_of'], 'created_at_utc': datetime.now(timezone.utc).isoformat(),
                'validation': 'PDF signature, pypdf parse, page count, first-page excerpt, SHA-256',
                'sources': [completed[source['file']] for source in sources]}
    MANIFEST.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    failed = [item['file'] for item in manifest['sources'] if item['archive_status'] == 'failed']
    print(json.dumps({'downloaded': sum(item['archive_status'] == 'downloaded' for item in manifest['sources']),
                      'existing': sum(item['archive_status'] == 'existing_preserved' for item in manifest['sources']),
                      'failed': failed}, ensure_ascii=False), flush=True)
    raise SystemExit(bool(failed))
