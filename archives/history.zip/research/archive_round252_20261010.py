"""One-shot documentary archive for formal global review 252. No mathematics."""
from pathlib import Path
import hashlib
import json

ROOT = Path(__file__).resolve().parents[1]
assert ROOT == Path(r"E:\kimi-build\zeta5").resolve()
MANIFEST = ROOT / "literature/manifest_global_review_round252_20261010.json"
assert not MANIFEST.exists(), "Completed archive must not be rerun"
PREVIOUS = ROOT / "literature/manifest_fricke_positive_round251_20261010.json"
MAIN = ROOT / "research/cdt_odd_background_progress_20261006.md"
POLICY = ROOT / "research/research_global_review_policy.md"
REPORT = ROOT / "research/research_global_review_round252_20261010.md"
MATH = ROOT / "research/global_power_type_growth_gate_round252_20261010.md"
REVIEW = ROOT / "research/research_round252_global_review_20261010.md"
SOURCES = ROOT / "literature/global_review_sources_round252_20261010"


def digest(data):
    return hashlib.sha256(data).hexdigest()


def pin(path):
    data = path.read_bytes()
    return {"path": path.relative_to(ROOT).as_posix(), "bytes": len(data), "sha256": digest(data)}


def verify(path, size, sha):
    data = path.read_bytes()
    assert len(data) == size and digest(data) == sha, str(path)
    return data


previous_data = verify(PREVIOUS, 7768, "822bfc0d4a45334923f39d780c5161a5dec7218478178b9102237d18f6922e82")
previous = json.loads(previous_data)
assert previous["round"] == 251 and len(previous["files"]) == 12
for item in previous["files"]:
    verify(ROOT / item["path"], item["bytes"], item["sha256"])
old_main = verify(MAIN, 715993, "97c91e823e14213151937f0e126358cba4d44129b34daa5bc90a43989bfc5a02")
old_policy = verify(POLICY, 19451, "d6f7ab27540f9beb7d4664e245a6ca3c7706d43eb828c1f359614de660d8e8ac")
report_data = verify(REPORT, 7740, "5a7f813d82a615067de5697aa5939ee38f5174f3d8adf67f1359ee493736c832")
review_data = REVIEW.read_bytes()
review_text = review_data.decode("utf-8-sig")
assert "PASS" in review_text and "256" in review_text and "253" in review_text
authors = [
    MATH,
    ROOT / "research/public_repository_global_review_round252_20261010.md",
    ROOT / "research/research_candidate_budget_review_round252_20261010.md",
    ROOT / "research/research_nonfricke_exit_review_round252_20261010.md",
    REPORT,
]
for path in authors:
    assert pin(path)["sha256"] in review_text, "Independent review must bind every final mathematics/report file"
for name in ["root", "alternative", "packet", "dual"]:
    assert (SOURCES / f"{name}_reading_scope.md").is_file()

policy_append = """

## 第252轮正式全局复盘与唯一下一首证书

按用户4–8轮宏观要求，本轮在248之后四完成轮次作正式复盘，计数从252重置，下一固定256；连续两轮核心停滞提前复盘，最迟八轮。仍无新ζ/L数值无理性或线性无关性定理，goal active。停止当前安全χ−7 Fricke默认窗口，不因251子引理继续map/word/prime/参数优化；全部已付证书留作条件资产，不认作全图no-go。

新完整幂旗标由full prefix D_N=prod d_floor(beta_a N)直接传给固定幂，费用τ_m=S(H_(m−1)−(m−1)/(2m))。同一实际全图能量J≤CR^rho+C0下，S rho<1才自动大幂成功；临界还需常数strict。真秩、整体meromorphic路径、闭盘条件另付，不从literal系数、部分lift或formal动机领取。新χ8外点−1正Gram下界包含所有完整共同约分，关闭D=O(m)的秩一严格二次预算；不排除其它χ8方法。

唯一253首关固定RV五列，n≥2、r0..4，tuple(10n+r,8n,8n,5n,10n)。已发表完整I=I0−logz I1经Λ_n=d_(13n+4)d_(12n+4)、z^(16n)(z−1)^(3n)清整，完整RHS无Li1/log。八次根Gauss trace输出A_n−c_n L(2,χ−8)，额外conductor因子1。但实际Q余数的4×5秩严格大于去constant行3×5秩在无界n上未付，五列多于三约束不代替c_n非零。

253只攻此固定全尺度intersection证书或其失败结构；没有可核推进则停止本包，不换参数或增包续窗。通过后先重新比较实际向量高度、primitive费用、无限非零及四复杂积分能量，不能以投影引理自动延长。K5、两χ7增长矩阵、原M0,10及magnetic整性工具仅在各自明确新定理匹配时重新准入。1511/60、175/4继续是upper，1/24微收益不当宏观通过。

本轮主报告research_global_review_round252_20261010.md及唯一独审冻结后文档归档一次；保存251清单、11非policy文件和旧main/policy字节前缀。新文献保存与读取范围按四scope记，不冒称整库/全文Lean或全球新颖性审计。数学程序、扫描、CAS/区间、Lean、外Git写、旧producer均0。
""".encode("utf-8")
assert "## 第252轮".encode("utf-8") not in old_policy
assert report_data not in old_main
POLICY.write_bytes(old_policy + policy_append)
MAIN.write_bytes(old_main + b"\n\n" + report_data)
assert POLICY.read_bytes()[:len(old_policy)] == old_policy
assert MAIN.read_bytes()[:len(old_main)] == old_main
assert MAIN.read_bytes().count(report_data) == 1
for item in previous["files"]:
    if item["path"] != "research/research_global_review_policy.md":
        verify(ROOT / item["path"], item["bytes"], item["sha256"])

paths = set((ROOT / "research").glob("*round252*20261010*"))
paths.update(SOURCES.iterdir())
paths.add(POLICY)
manifest = {
    "round": 252,
    "date_completed": "2026-10-10",
    "classification": "progress",
    "previous_goal_turn_classification": "progress",
    "progress_kind": "Formal global comparison; complete prefix power flag and growth gate; exterior rank-one Gram cap; exact conditional conductor-eight RV projection",
    "goal_status": "active",
    "new_numerical_irrationality_or_independence_theorem": False,
    "global_novelty_or_full_lean_audit": False,
    "formal_global_review": {"previous": 248, "completed_rounds_before_reset": 4, "last": 252, "this_round_is_formal": True, "counter_reset_this_round": True, "completed_rounds_since_last": 0, "next_scheduled": 256, "early_core_stagnation_rounds": 2, "maximum_interval": 8},
    "stopped_default_windows": ["Safe chi_-7 Fricke local source", "Naive rank-one positive chi_-8 Gram quadratic budget", "Renamed chi_-8 truncated mixed-moment architecture"],
    "next_unique_first_certificate": {
        "round": 253,
        "target": "L(2,chi_-8) irrationality, global novelty not yet certified",
        "fixed_parameters": "n>=2, r=0..4: (10n+r,8n,8n,5n,10n)",
        "paid": "Published pure RV identity; common integer normalization; exact Gauss trace A-cL with extra conductor factor 1",
        "unpaid": "Actual remainder rank 4x5 > rank nonconstant 3x5 on unbounded n; coefficient-vector height; full primitive content; actual nonzero and same-object complex-integral strict margin",
        "stop": "If fixed all-scale intersection has no checkable progress in253, stop this packet without parameter, map, prime or package extension",
        "automatic_extension": False,
    },
    "new_primary_carriers": {"new_pdf_downloads_by_team": 3, "new_html_downloads_by_team": 1, "root_downloads": 0, "root_new_documentary_pdf_selection": 1, "whole_paper_reading_claim": False, "precise_scope": "Four separately pinned reading scopes; saved complete carriers do not imply complete reading"},
    "repository": {"fresh_readonly_by_A": True, "local_and_remote_head": "fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb", "external_mutations": 0, "all_odd_zeta_absence_claim": False},
    "runs": {"mathematics": 0, "cas_or_interval": 0, "prime_parameter_map_word_scans": 0, "lean": 0, "external_git_mutations": 0, "old_archive_producers": 0, "this_documentary_archive": 1},
    "previous_manifest": pin(PREVIOUS),
    "previous_manifest_nonpolicy_files_preserved": 11,
    "report": pin(REPORT),
    "independent_math_and_report_review": pin(REVIEW),
    "previous_policy": {"bytes": len(old_policy), "sha256": digest(old_policy)},
    "new_policy": pin(POLICY),
    "previous_main": {"bytes": len(old_main), "sha256": digest(old_main)},
    "new_main": pin(MAIN),
    "files": [pin(p) for p in sorted(paths) if p.is_file()],
}
MANIFEST.write_text(json.dumps(manifest, ensure_ascii=False, indent=2)+"\n", encoding="utf-8")
assert PREVIOUS.read_bytes() == previous_data
assert REVIEW.read_bytes() == review_data
print(json.dumps({"status": "PASS", "numeric_theorem": False, "next_formal_review": 256, "first_certificate_round": 253, "fricke_window_extended": False, "files": len(manifest["files"]), "manifest": pin(MANIFEST), "main": pin(MAIN), "policy": pin(POLICY)}, ensure_ascii=False))
