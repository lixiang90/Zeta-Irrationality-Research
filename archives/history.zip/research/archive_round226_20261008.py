"""One-shot round-226 documentary freeze; imports no mathematical producer."""
from pathlib import Path
from hashlib import sha256
import json
import re

ROOT = Path(__file__).resolve().parents[1]
MAIN = 'research/cdt_odd_background_progress_20261006.md'
REPORT = 'research/research_pade_ramified_admission_round226_20261008.md'
PREVIOUS = 'literature/manifest_cdt_pade_actual_modes_round225_20261008.json'
OUTPUT = 'literature/manifest_cdt_pade_ramified_admission_round226_20261008.json'
REVIEW = 'research/research_round226_report_review_20261008.md'
REVIEW_BYTES = 7380  # Root actually FULL read final independent report receipt.
REVIEW_SHA = 'f1dbc1bebce110fb52babfc3cf7faabb112eeaf35e5fde145e7293db4b4ba7ec'
SOURCE_DIRS = [
    'literature/pade_rational_scale_sources_round226_20261008',
    'literature/pade_galois_normalization_sources_round226_20261008',
    'literature/pade_ramified_admission_sources_round226_20261008',
]


def identity(relative):
    data = (ROOT / relative).read_bytes()
    return {'path': relative, 'bytes': len(data), 'sha256': sha256(data).hexdigest()}


def require(relative, length, digest):
    item = identity(relative)
    assert (item['bytes'], item['sha256']) == (length, digest), item
    return item


assert not (ROOT / OUTPUT).exists(), 'Completed archive must not be rerun.'
assert REVIEW_BYTES is not None and REVIEW_SHA is not None, 'Final FULL receipt required.'
require(PREVIOUS, 49255, 'f2f89ce01ca7e9e56aca9a98185c0ced3c2594c60fe44f26af1fb9d535f79a42')
previous = json.loads((ROOT / PREVIOUS).read_text(encoding='utf-8'))
old_checked = [require(p['path'], p['bytes'], p['sha256'])
               for p in previous['pins'] if p['path'] != MAIN]
assert len(old_checked) == 167
prefix = (ROOT / MAIN).read_bytes()
assert len(prefix) == 542249
assert sha256(prefix).hexdigest() == '590c4323757ba9c9507350c9794b32c0853c56303ff6ec1a300d834280f64528'

expected = '''
research/pade_exterior_ramification_model_round226_20261008.md 9351 a981d3fa323ee30fd1408c280614cae10f0ef52797083673cd92cdeddab2ceae
research/pade_galois_normalization_gate_round226_20261008.md 13193 61c2a1d2890828c915af19427843abf778aee9c95c0f3fe5969df7e700fd7d93
research/pade_ramified_generating_operator_round226_20261008.md 13212 2bbe912ac345d5afa5c6a999c1ba05b8b79de83d27b58e0a44921490a3ed1772
research/pade_rational_scaling_admissibility_round226_20261008.md 10822 058dc89f3080ff18f2694ecd4dff85a31a1897e4005bcfa15fa49f002f4121a0
research/research_pade_ramified_admission_round226_20261008.md 8332 f0d977e7cde11c6247c675356bdddc20f7065e967c1ed09560ce217198734c68
research/research_round226_exterior_ramification_review_20261008.md 4796 8cd910c8b35cf24f85d9df6a146c6b0ed286b1954f4cb4cbc372b86d7290bdda
research/research_round226_galois_normalization_review_20261008.md 6148 75a636efb3430df7504d49e44b7def105efb946fc544d35d75c2970b76b3ef1d
research/research_round226_ramified_generating_operator_review_20261008.md 5687 a6cd843785261b4c1f3747f5c3326aca74712fb358ab08bff6d439fdb9cbe952
research/research_round226_rational_scaling_review_20261008.md 4319 704c7ed4a0394118a72610ec468399b528065a17d34cab2c9758deba04216a21
research/research_round226_root_math_review_20261008.md 5027 a448271afeadd30c4c0381dc97dd293bbac137d08ee7b89ee020a9e287a245f5
literature/pade_ramified_admission_sources_round226_20261008/root_reading_scope.md 4791 0b057f4d6836e026dc6b55a91f1fa4d893dab78953bd0cdfd42e10f4cb4b4ba3
literature/pade_ramified_admission_sources_round226_20261008/dual_reading_scope.md 7153 d03383dbe6aa00443d89594aeb06dd3611ec372a3a74a5c63dc28c72d7ba29d4
literature/pade_rational_scale_sources_round226_20261008/lambert_reading_scope.md 3386 84e212b4a91824b457d5559ba622843d2db7c1347a537a5991667f6188cd2c8d
literature/pade_galois_normalization_sources_round226_20261008/packet_reading_scope.md 4455 468e22ab2634d771dd055db1bed06b576d80b5d3a9debc07469113f8653978de
'''
pins = {p['path']: p for p in old_checked}
pins[PREVIOUS] = identity(PREVIOUS)
new_paths = []
for line in expected.splitlines():
    if line.strip():
        relative, length, digest = line.split()
        pins[relative] = require(relative, int(length), digest)
        new_paths.append(relative)
pins[REVIEW] = require(REVIEW, REVIEW_BYTES, REVIEW_SHA)
new_paths.append(REVIEW)
for directory in SOURCE_DIRS:
    for file in sorted((ROOT / directory).rglob('*')):
        if file.is_file():
            relative = file.relative_to(ROOT).as_posix()
            pins[relative] = identity(relative)
            new_paths.append(relative)
new_paths = sorted(set(new_paths))
assert len([p for p in new_paths if p.endswith('.pdf')]) == 2
assert len([p for p in new_paths if p.endswith('.html')]) == 2
assert len([p for p in new_paths if p.endswith('.txt')]) == 3
assert not any(p.endswith('.tex') for p in new_paths)

links = []
new_mds = [p for p in new_paths if p.endswith('.md')]
for relative in new_mds:
    content = (ROOT / relative).read_text(encoding='utf-8')
    assert not any(ord(c) < 32 and c not in '\n\r\t' or ord(c) == 127 for c in content), relative
    for target in re.findall(r'\[[^\]\n]*\]\(([^)\n]+)\)', content):
        target = target.strip().strip('<>').split('#', 1)[0]
        if re.match(r'^(?:https?://|app://)', target):
            continue
        if Path(target).suffix.lower() not in {'.md', '.pdf', '.json', '.txt', '.py', '.png', '.tex'}:
            continue
        resolved = ((ROOT / relative).parent / target).resolve()
        assert resolved.is_relative_to(ROOT), (relative, target)
        link_path = resolved.relative_to(ROOT).as_posix()
        assert resolved.is_file() or link_path == OUTPUT, (relative, target)
        links.append({'source': relative, 'target': link_path})
        if resolved.is_file() and link_path not in pins and link_path != MAIN:
            pins[link_path] = identity(link_path)

report = (ROOT / REPORT).read_bytes()
main_final = prefix + b'\n\n' + report
(ROOT / MAIN).write_bytes(main_final)
assert (ROOT / MAIN).read_bytes() == main_final
pins[MAIN] = identity(MAIN)
script = Path(__file__).relative_to(ROOT).as_posix()
pins[script] = identity(script)
record = {
    'round': 226, 'date': '2026-10-08', 'goal_status': 'active',
    'new_numerical_theorem': False,
    'round_outcome': 'Actual complete no-log finite local models and legal shared ramified disc; rational scaling full-jet necessary costs and scoped neutrality; natural Galois scales and specified all-place transport fail. No positive net entrance or numerical irrationality theorem.',
    'navigation': {
        'last_formal_global_review': 222, 'next_normal_global_review': 228,
        'allowed_window': [226, 230], 'default_review_interval_completed_rounds': 6,
        'user_review_interval_completed_rounds': [4, 8],
        'early_triggers': ['structural cap/counterexample', 'two completed rounds without a core interface advance'],
        'this_round_has_core_interface_advance': True,
        'this_round_is_not_a_comprehensive_global_literature_review': True,
        'next_task': 'One concrete larger same-leaf map or complete paid model with plausible positive net gain, or definitive total cap. Do not repeat raw-univalent optimization or safe166/9 refinements.',
        'stop_rule': 'If round227 supplies no concrete model/map with a positive-net prospect or decisive total bound, downgrade this packet to a structural tool at formal global review228 and compare other period sources/targets. Legal small-disc existence is not a numerical theorem or reason for indefinite extension.'
    },
    'completed_math': [
        'Original four A/C share an explicit all-r polynomial recurrence; actual scalar generating ODE includes every initial head term and has exact nonzero finite indices9/2.',
        'Simple-leading augmented rank-one residue has noninteger eigenvalue; explicit inverse recurrence and majorant pay convergent holomorphic gauge, analytic particular and complete no-log models despite repeated zero exponents.',
        'Actual general vector generating identity q(theta-1)I-zP(theta) retains q(-1)v0; q=p6 clears actual third-companion exterior minors at all integer exceptions without division.',
        'All20 exterior leading roots are simple by14 disjoint rational modulus classes and six internal nonreal conjugate pairs; no degree20 expansion/root computation.',
        'Every nonzero finite exterior operator point has complete analytic+t^(31/2)analytic local coordinates; local monodromy order at most2. Other leaves at0, infinity and global finite monodromy are not proved.',
        'Actual shared map phi(w)=rhoM*(3w-9w^2/4) fills the dominant point, avoids every other finite point and second0-fiber, and makes original D/X/Hg holomorphic. Its derivative3/M<1 fails even at zero cost.',
        'Rational scaling necessary fixed-prime linear coefficient content and exact full-frame jet identity; joint lattice index lower retains original minor content. Conditional normality metric neutrality is not optimal-cost no-go.',
        'All integers N<=24^9/4 fail target raw-univalent entrance; with D retained N<=144^9/4 fail. Larger scaling/ramified models not excluded.',
        'Two natural positive scales belong to degree3/6 fields, with normalized means12log3 and(21/2)log3 and exact finite3-valuations. Arch-only natural scales and specified finite linear transport have strictly negative entrance.',
        'A self-contained nonsplit difference extension disproves free leading-factor-to-rational-projector inference; actual packet projector/rightfactor and target membership remain unpaid.'
    ],
    'remaining_gates': [
        'positive legal analytic/arithmetical margin on the same complete source',
        'larger paid ramified map and actual energy',
        'actual fixed-prime/primitive joint content after normalization and effective nonzero cutoff',
        'actual descent/projector with full target relation and finite prefix',
        'minimum differential/cyclic model and applicable arithmetic holonomy rank',
        'new numerical irrationality/linear-independence theorem'
    ],
    'execution_ledger': {
        'mathematical_program_runs': 0, 'failed_mathematical_runs': 0,
        'CAS': 0, 'recurrence_guessing': 0, 'actual_sequence_samples': 0,
        'parameter_or_prime_scans': 0, 'PSLQ': 0, 'numerical_integrations': 0,
        'root_solver_or_degree20_expansion': 0, 'old_proof_producer_reruns': 0,
        'Lean_builds': 0, 'Git_mutations': 0, 'new_repository_status_check': False,
        'new_PDF_downloads': 2, 'new_HTML_archives': 2, 'new_primary_selected_TXT': 3,
        'new_TEX_archives': 0,
        'documentary_operations': 'Primary downloads/selected PDF extraction, actual FULL drafts/reviews and selected-source reading, metadata/links/controls, one-shot append/freeze. No mathematical producer imported or run.'
    },
    'source_claim_policy': 'Novikov-Yakovenko46pp PDF archived by C, only PDF33-38 actually read by C; Root uses independently checked self-contained majorant. Official current CDT ICM20pp PDF archived by B, complete PDF3-8 TXT read by B/Root/C. DLMF2.7 relevant second-order section only, not a high-order theorem. Abramov metadata not a proof or failed PDF read. A selected cached CDT2025pp3-4. No fresh cloud/Lean verification.',
    'independent_review': {
        'C_actual_scalar_vector_no_log_shared_disc': 'A FULL independent PASS plus Root FULL paper PASS',
        'Root_all20_exterior_finite_models': 'C FULL independent PASS after native0 loop clarified',
        'A_rational_scaling': 'B FULL independent PASS after plus sign and normality scope fixed; Root FULL final paper PASS',
        'B_natural_scales_all_place_transport': 'Root and C FULL independent PASS at final conjugate-field/content/observable clarified identity',
        'report_and_root_scope': 'C FULL independent PASS at final pinned identities'
    },
    'predecessor': {'manifest': identity(PREVIOUS), 'immutable_pins_checked': len(old_checked),
                    'mutable_main_excluded_from_old_final_hash': True},
    'main_append': {'preserved_prefix_bytes': len(prefix), 'preserved_prefix_sha256': sha256(prefix).hexdigest(),
                    'append_separator_hex': '0a0a', 'appended_report': identity(REPORT), 'final': identity(MAIN)},
    'verification': {'control_character_documents': len(new_mds), 'controls': 'PASS',
                     'local_links': links, 'links': 'PASS including planned manifest checked after creation'},
    'pins': sorted(pins.values(), key=lambda p: p['path'])
}
(ROOT / OUTPUT).write_text(json.dumps(record, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
for link in links:
    assert (ROOT / link['target']).is_file(), link
for item in record['pins']:
    require(item['path'], item['bytes'], item['sha256'])
require(PREVIOUS, 49255, 'f2f89ce01ca7e9e56aca9a98185c0ced3c2594c60fe44f26af1fb9d535f79a42')
print(json.dumps({'manifest': identity(OUTPUT), 'main': identity(MAIN), 'pins': len(record['pins']),
                  'local_links': len(links), 'controls_md': len(new_mds),
                  'predecessor_immutable_pins': len(old_checked), 'checks': 'PASS'}, ensure_ascii=False))
