"""One-shot documentary archive; no mathematical computation or Git operation."""
from pathlib import Path
import hashlib
import json

ROOT = Path(__file__).resolve().parents[1]
assert ROOT == Path(r"E:\kimi-build\zeta5").resolve()
MANIFEST = ROOT / "literature/manifest_dyadic_period_round247_20261010.json"
assert not MANIFEST.exists(), "Do not rerun a completed archive"
PREVIOUS = ROOT / "literature/manifest_forcing_recovery_round246_20261010.json"
MAIN = ROOT / "research/cdt_odd_background_progress_20261006.md"
POLICY = ROOT / "research/research_global_review_policy.md"
REPORT = ROOT / "research/research_dyadic_period_progress_round247_20261010.md"

def digest(data):
    return hashlib.sha256(data).hexdigest()

def pin(path):
    data = path.read_bytes()
    return {"path": path.relative_to(ROOT).as_posix(), "bytes": len(data), "sha256": digest(data)}

def verify(path, size, sha):
    data = path.read_bytes()
    assert len(data) == size and digest(data) == sha, str(path)
    return data

previous_data = verify(PREVIOUS, 9488, "add2461c80ff54ae4629bc31131482fa15c22986a7fa4958a2454544e26fc092")
previous = json.loads(previous_data)
for item in previous["files"]:
    verify(ROOT / item["path"], item["bytes"], item["sha256"])
old_main = verify(MAIN, 686662, "361dabf86744f8dad4615c22f4356b8c51e43a8cd2cd0eff8af5aac9c5b31914")
old_policy = verify(POLICY, 11092, "4417fbf86d6e91809b5acb74671653afc342004db2a848d7c85d820867ffcb4f")
report_data = verify(REPORT, 5023, "524c39395aaf4658c95a1dea59b0b966c263fa699870249b8bc7c7b37e84c450")
for name, size, sha in [
    ("canonical_eisenstein_nonholonomic_round247_20261010.md", 8583, "63956362354d4f1fb41fb166838bac80af30dc632521573c31f9f7a7133c2372"),
    ("chi7_dyadic_two_period_source_round247_20261010.md", 9308, "ed85200e7b75f24d0f7e7ffa523ba16a3196fd199012657567e15f8d90d04017"),
    ("dyadic_chi7_eisenstein_source_round247_20261010.md", 12786, "2cc22522b952f4b9c6587c9ebdf0e25d4a2a078afcf6221ff8dbf6f9b8c6079c"),
    ("chi7_mixed_relation_frame_round247_20261010.md", 6993, "15605545624b79b8f6b692d7c4451ec949daee3f349f6dac14876f58a243043f"),
    ("research_round247_canonical_eisenstein_review_20261010.md", 2555, "aa99fe541f0b9b111fd76977e92014761d425e08ee5b2733002534b1a6af667b"),
    ("research_round247_dyadic_source_review_20261010.md", 5457, "53379c45a2895174bbbd9866135ec98bfefaf329398848b79ec1202e4c567c2b"),
    ("research_round247_mixed_relation_dual_review_20261010.md", 3451, "6dab78db8fa34031e464ead338d84c90d82b59d401f8c08a6ae2ce37bffafd02"),
]:
    verify(ROOT / "research" / name, size, sha)

# Independent mixed-frame/report review must be saved before authority is changed.
mixed_reviews = []
for path in (ROOT / "research").glob("*round247*review*20261010.md"):
    value = path.read_text(encoding="utf-8-sig")
    if "15605545624b79b8f6b692d7c4451ec949daee3f349f6dac14876f58a243043f" in value:
        assert "PASS" in value and "524c39395aaf4658c95a1dea59b0b966c263fa699870249b8bc7c7b37e84c450" in value
        mixed_reviews.append(path)
assert len(mixed_reviews) == 1, "Require exactly one independent mixed-frame/report receipt"

policy_append = """

## 第247轮：改变层级支付关系投影，不延迟248复盘

247已严格关闭另一Eisenstein的canonical单方向：去常数forcing出现无限解析延拓轨道的A⁻³，固定常数A或非零有理微分均不能使该方向成为有限holonomic源。该限定障碍不外推到相关差分或所有CDT。

真实level14 dyadic差分绕过这项失配，已付两个完整Fricke响应Y/2、π²/8，degree3代数field、同坐标全prefixd_N²、实际五行rank5，以及任意有理关系σ=a+bY/2+cπ²/8在canonical二重cusp上的整个jump取消。即使包含完整field，该五行也不能恢复A；literal类型为(0,0,0,2,2)，τ32/25。它们是实质核心进展，数值定理仍未得。

b≠0时同值另一叶1/2保留非零log²，b=0,c≠0时坏cusp在1/7；指定cover填点不等于base普通填点或全叶准入。未付共同单值亚纯图及strict差额，不开展map/prime/parameter/LCD扫描。Fricke特征方向g±仅有真实响应/even性，尚无其完整代数整模型。

248必须按244既定计数正式俯瞰，与244相隔4个完成轮次；本轮不重置。按数值出口、完整关系投影、实际秩与全整模型、解析准入和strict可达性，比较当前rank5源、Fricke特征方向、增长整数矩阵及已识别相对周期，再选唯一有界窗口和首证书。不得把局部identity当自动延长搜寻的理由。连续两轮无核心进展仍提前方向检查，最迟8轮规则继续有效。详见research_dyadic_period_progress_round247_20261010.md；主goal active，无新数值定理。
""".encode("utf-8")

assert "## 第247轮".encode("utf-8") not in old_policy
assert report_data not in old_main
new_policy = old_policy + policy_append
new_main = old_main + b"\n\n" + report_data
POLICY.write_bytes(new_policy)
MAIN.write_bytes(new_main)
assert POLICY.read_bytes()[:len(old_policy)] == old_policy
assert MAIN.read_bytes()[:len(old_main)] == old_main
assert MAIN.read_bytes().count(report_data) == 1

paths = set((ROOT / "research").glob("*round247*20261010*"))
for folder in ["canonical_eisenstein_sources_round247_20261010", "dyadic_eisenstein_sources_round247_20261010"]:
    paths.update((ROOT / "literature" / folder).iterdir())
paths.add(POLICY)
files = [pin(path) for path in sorted(paths) if path.is_file()]
manifest = {
    "round": 247,
    "date_completed": "2026-10-10",
    "classification": "progress",
    "previous_goal_turn_classification": "progress",
    "goal_status": "active",
    "new_numerical_irrationality_or_independence_theorem": False,
    "formal_global_review": {"last": 244, "this_round_is_formal": False, "completed_rounds_since_last": 3, "counter_reset_this_round": False, "next_scheduled": 248},
    "object": {"target": "Q-linear relations among 1, L(2,chi_-7), pi^2", "source": "H=aA+bAR+cAD", "coordinate": "x=u/(1+7u)", "full_frame": ["1", "Z", "Z^2", "H", "delta H"], "actual_rank": 5, "literal_type": [0, 0, 0, 2, 2], "safe_tau": "32/25"},
    "paid": [
        "Canonical constant-deleted direction has an infinite actual continuation orbit; fixed nonzero rational differential filters cannot restore D-finiteness.",
        "Actual level14 correlated dyadic sources and all-prefix d_N squared model.",
        "Full coupled Fricke cocycle with identified Y/2 and pi^2/8 responses.",
        "Actual degree-three arithmetic function field and full rational five-row connection.",
        "Exact rank five for every nontrivial rational relation direction, and full-frame nonrecovery of A.",
        "Complete canonical ramified-cusp jump proportional to the actual numerical relation.",
        "Real remaining log-squared cusps and explicit boundaries of local filling.",
        "Independent final paper reviews with stated actual reading scopes."
    ],
    "not_paid": ["Common legal lifted analytic map or all-return-leaf cancellation", "Strict arithmetic holonomy budget", "New numerical irrationality or linear independence", "Complete explicit arithmetic model for the Fricke eigenperiod source", "Global novelty certificate or fresh cloud repository HEAD", "Full upstream proof or Lean certification", "All-method impossibility"],
    "resource_decision": {"canonical_single_direction": "stop", "old_closed_CM_entry": "remains stopped", "next": "Formal global review round248 before choosing a new bounded certificate window", "map_prime_parameter_or_lcd_scans_now": False},
    "runs": {"mathematics": 0, "cas_or_interval": 0, "prime_parameter_or_map_scans": 0, "lean": 0, "external_git_mutations": 0, "old_archive_producers": 0, "this_documentary_archive": 1},
    "new_primary_carriers": {"official_pdf": 1, "official_html": 2, "selection_scope": "Per-reader exact selected pages/formulas; stored carriers do not certify full upstream proofs."},
    "previous_manifest": pin(PREVIOUS),
    "report": pin(REPORT),
    "previous_policy": {"bytes": len(old_policy), "sha256": digest(old_policy)},
    "new_policy": pin(POLICY),
    "previous_main": {"bytes": len(old_main), "sha256": digest(old_main)},
    "new_main": pin(MAIN),
    "files": files,
}
MANIFEST.write_text(json.dumps(manifest, ensure_ascii=False, indent=2)+"\n", encoding="utf-8")
assert PREVIOUS.read_bytes() == previous_data
for item in previous["files"]:
    if item["path"] != "research/research_global_review_policy.md":
        verify(ROOT / item["path"], item["bytes"], item["sha256"])
print(json.dumps({"status": "PASS", "classification": "progress", "goal": "active", "next_formal_review": 248, "files": len(files), "report": pin(REPORT), "main": pin(MAIN), "policy": pin(POLICY), "manifest": pin(MANIFEST)}, ensure_ascii=False))
