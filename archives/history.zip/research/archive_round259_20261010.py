"""One-shot documentary archive for source selection259. Do not rerun."""
from pathlib import Path
import hashlib
import json

ROOT = Path(__file__).resolve().parents[1]
assert ROOT == Path(r"E:\kimi-build\zeta5").resolve()
PREVIOUS = ROOT / "literature/manifest_source_admission_round258_20261010.json"
MANIFEST = ROOT / "literature/manifest_source_selection_round259_20261010.json"
MAIN = ROOT / "research/cdt_odd_background_progress_20261006.md"
POLICY = ROOT / "research/research_global_review_policy.md"
REPORT = ROOT / "research/research_source_selection_progress_round259_20261010.md"
REVIEW = ROOT / "research/research_round259_source_selection_review_20261010.md"
SOURCES = ROOT / "literature/source_selection_round259_20261010"
# Fill only after Root actually reads the frozen independent review.
REVIEW_SHA = "383451be95074450072dcb3ad15eca776145b9b1ddbcee1e43a2816964dd69b7"
MATH_NAMES = ["gate", "mixed12", "mixed_field", "log_products"]
MATH = [ROOT / f"research/source_selection_{name}_round259_20261010.md" for name in MATH_NAMES]
SCOPES = [SOURCES / f"{name}_reading_scope.md" for name in ["root", "mixed", "field", "log"]]


def digest(data):
    return hashlib.sha256(data).hexdigest()


def pin(path):
    data = path.read_bytes()
    return {"path": path.relative_to(ROOT).as_posix(), "bytes": len(data), "sha256": digest(data)}


def verify(path, size, sha):
    data = path.read_bytes()
    assert len(data) == size and digest(data) == sha, str(path)
    return data


assert not MANIFEST.exists(), "259 already archived; do not rerun"
previous_data = verify(PREVIOUS, 40150, "9d4cc7d8abc31bbbfefb2f04b1696789765bcd135567531f1368bdfa86ea2aca")
previous = json.loads(previous_data)
assert previous["round"] == 258 and len(previous["files"]) == 160
assert previous["formal_global_review"]["last"] == 256
assert previous["formal_global_review"]["completed_rounds_since_last"] == 2
for item in previous["files"]:
    verify(ROOT / item["path"], item["bytes"], item["sha256"])
old_main = verify(MAIN, 763510, "8fb4056bae41c6e8f10f63eff8f4a10ba85e60621c720ba144bcb5af00de6502")
old_policy = verify(POLICY, 38352, "5f8d45b158e6db7252be028b6ad36f5e7c8c590bba437d30a5867b633ca85a96")
review_data = REVIEW.read_bytes()
assert digest(review_data) == REVIEW_SHA and REVIEW_SHA != "PENDING"
review_text = review_data.decode("utf-8-sig")
assert "PASS" in review_text and "260" in review_text and "264" in review_text
for path in MATH + SCOPES + [REPORT]:
    assert path.is_file() and pin(path)["sha256"] in review_text.lower(), str(path)
root_scope = SCOPES[0].read_text(encoding="utf-8-sig")
assert "独立数学复核" in root_scope
for path in MATH[1:]:
    assert pin(path)["sha256"] in root_scope.lower(), str(path)
report_data = REPORT.read_bytes()
assert report_data not in old_main
assert "## 第259轮".encode("utf-8") not in old_policy
paths = {ROOT / p["path"] for p in previous["files"] if p["path"] != "research/research_global_review_policy.md"}
paths.update([PREVIOUS, POLICY, REPORT, REVIEW, Path(__file__)])
paths.update(MATH)
paths.update(SOURCES.iterdir())
assert all(path.is_file() for path in paths)

policy_append = """

## 第259轮：真实混合来源、最小场与下一全局必要条件比较

落实用户最新每4–8轮俯瞰全局要求：默认4个完成轮，最迟8轮；连续2轮核心准入或净可行性未推进则提前。复盘必须比较目标差距、关键缺口与跨架构机会成本，输出具体继续、停止局部投入或转向的决定。文档、归档、局部引理数量、有限头与坐标改名不抵消停滞，也不reset。本轮不是正式回顾：last256，259完成后count3，next260、latest264。总目标active，新数值定理false。

固定A3/B3/C3+B4 dyadic χ−4来源在真实q0 cusp完整共享bad germ；H4−G/2 A3全纯，所有dual corrections保留。旧x6上仍恰4叶，q0³係数√3/2非零，不借CDT原图。自然共同level24 χ12 curve genus1完整degree8场付清，但forcing有额外ψ=χ12(d)(−1)^(c/12)半平移共轭；s=−u_old(−q)给真正Q(t,h)=Q(s)degree4 genus0且全阶整数反演。完整自然场不是该forcing最低费用。

同一反证关系载体d≠0的Bol/negative-weight/SL2不可约证书给bare实际rank3；三个forcing同在Q(s)，全N d_N²清H及θsH。两列(0,1,1)原始safe type算τ16/9，仅条件性同tuple holonomy账本，不是已付合法图或strict余量。九germ仅有限生成upper，不冒认全独立；CDT14、旧level14及其它实现的费用/能量不借用。

两log后备所选近参数目标已属CDTbaseline，depth-two拆和不能隔离新个别值，本轮不准入。混合来源虽通过首证书，本轮亦不准入Padé、maps/参数或其它实现扫描；canonical cusp的补点不自动支付其它返回叶及全域。

第260轮正式全局复盘先比较混合bare rank3、扩充纯族和已有product-formula资产。优先核完整算术费用要求的解析收益与剩余真实奇点允许的收益上限；先判断严格相容空间，再决定精修算术格、图或Padé。只选一个改变净可行性的首证书，给有界投入和停止条件。必要条件不匹配则停止该safe实现默认投入，保留结构资产，不把它说成全方法no-go。新数值定理仍是成功标准。

四数学稿、report、四scope和唯一独审后单次归档；Root独核mixed/log/field，mixed交叉核field，log独审其它稿与report但不自审自己的数学。258全部160 pins及旧main/policy先核，159非policy旧files和旧字节前缀保留。团队数学程序、CAS、有限n数值、interval、prime/parameter/map/word扫描、Lean、Padé实现、外Git写与旧producer均0；只有文档提取/渲染/读写/hash和单次归档。primary访问/下载/失败GET按实际scope记，不声称全网络0或全球novelty/全文Lean/最新云端一致。
""".encode("utf-8")

# Mutate only after every input and the independently reviewed identities pass.
POLICY.write_bytes(old_policy + policy_append)
MAIN.write_bytes(old_main + b"\n\n" + report_data)
assert MAIN.read_bytes()[:len(old_main)] == old_main
assert POLICY.read_bytes()[:len(old_policy)] == old_policy
assert MAIN.read_bytes().count(report_data) == 1
for item in previous["files"]:
    if item["path"] != "research/research_global_review_policy.md":
        verify(ROOT / item["path"], item["bytes"], item["sha256"])
manifest = {
    "round": 259, "date_completed": "2026-10-10", "classification": "progress", "goal_status": "active",
    "new_numerical_irrationality_or_independence_theorem": False,
    "global_novelty_or_full_lean_audit": False,
    "formal_global_review": {"last": 256, "previous_formal": 252, "this_round_is_formal": False, "counter_reset_this_round": False, "completed_rounds_since_last": 3, "next_scheduled": 260, "latest_required": 264, "default_interval": 4, "maximum_interval": 8, "early_core_stagnation_rounds": 2},
    "paid_this_round": ["Fixed mixed carrier full shared bad germ on actual cusp cover", "Exact old-base local ramification4", "Complete natural level24 character field degree8 genus1", "Actual halfshift character and genus0 minimal forcing field Q(s) degree4", "Explicit rational t(s), h(s), and all-order integral inverse", "Common rational order2 operator and forcing", "Actual bare relation-carrier rank3 by Bol and irreducibility", "All-prime-power d_N^2 safe prefix and original two-column type", "Two-log extension baseline rejection"],
    "admission": {"mixed_source_first_certificate": "passed; complete bad germ and minimal rational forcing entry", "implementation_admitted": False, "strict_same_object_budget_paid": False, "log_extension": "rejected for selected known target and absent new period isolation", "general_method_impossibility": False},
    "stopped_default_windows": previous["stopped_default_windows"],
    "next_unique_work": {"round": 260, "scope": "Formal global comparison of arithmetic necessary gain and allowable analytic gain before implementation", "compare": ["Mixed bare relation rank3", "Same-source expanded pure family with fully paid costs", "Previously paid product-formula assets"], "automatic_implementation_or_scan": False, "stop_condition": "No certified strictly compatible same-object necessary budget or genuinely changed core mechanism"},
    "runs": {"team_math_programs": 0, "cas": 0, "finite_n_numerical_or_interval": 0, "prime_parameter_map_word_scans": 0, "pade_matrix_implementation": 0, "lean": 0, "external_git_mutations": 0, "old_archive_producers": 0, "this_documentary_archive": 1},
    "sources": {"precise_scopes": [pin(p) for p in SCOPES], "whole_primary_paper_reading_claim": False, "fresh_cloud_repository_equality_claim": False, "mathematics_not_inferred_from_hashes": True},
    "previous_manifest": pin(PREVIOUS), "previous_manifest_nonpolicy_files_preserved": 159,
    "report": pin(REPORT), "independent_math_and_report_review": pin(REVIEW),
    "previous_policy": {"bytes": len(old_policy), "sha256": digest(old_policy)}, "new_policy": pin(POLICY),
    "previous_main": {"bytes": len(old_main), "sha256": digest(old_main)}, "new_main": pin(MAIN),
    "files": [pin(p) for p in sorted(paths)],
}
MANIFEST.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
assert PREVIOUS.read_bytes() == previous_data and REVIEW.read_bytes() == review_data
print(json.dumps({"status": "PASS", "files": len(paths), "old_nonpolicy_preserved": 159, "numeric_theorem": False, "count": 3, "next_formal": 260, "latest_formal": 264, "manifest": pin(MANIFEST), "main": pin(MAIN), "policy": pin(POLICY)}, ensure_ascii=False))
