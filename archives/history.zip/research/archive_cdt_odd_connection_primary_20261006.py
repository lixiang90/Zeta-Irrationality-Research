"""Archive one explicitly versioned primary PDF; record actual reading scope.

No frozen mathematical producer is imported or executed.
"""
from pathlib import Path
import hashlib
import json
import urllib.request
import fitz

root = Path(__file__).resolve().parent.parent
directory = root / 'literature'
name = 'rogers_wan_zucker2013_moments_elliptic_critical_l_values_v2.pdf'
url = 'https://arxiv.org/pdf/1303.2259v2'
target = directory / name
if target.exists():
    raise RuntimeError('Do not replace an existing literature snapshot.')
request = urllib.request.Request(url, headers={'User-Agent': 'MathematicalResearch/1.0'})
with urllib.request.urlopen(request, timeout=45) as response:
    data = response.read()
if not data.startswith(b'%PDF-'):
    raise RuntimeError('Primary response is not a PDF.')
target.write_bytes(data)
with fitz.open(target) as doc:
    pages = len(doc)
    first = doc[0].get_text()
    selected = '\n'.join(f'PDF PAGE {p}\n{doc[p-1].get_text()}' for p in (13,14))
if pages != 15 or 'ROGERS' not in first or 'ZUCKER' not in first:
    raise RuntimeError('Identity/page-count verification failed; retain snapshot for review.')
cy = directory / 'bonisch_klemm_scheidegger_zagier_periods_author_20261006.pdf'
cy_hash = hashlib.sha256(cy.read_bytes()).hexdigest()
if cy_hash != 'f124aab462ae953eff9a2c9df28cff63e1b63adad792a572a1c608226fdfac83':
    raise RuntimeError('Frozen CY primary PDF changed.')
manifest = {
    'date': '2026-10-06',
    'scope': 'One new versioned primary PDF plus additional reading of an existing frozen CY snapshot. Reading is page-specific, not a claim to have checked the complete papers or integral comparison.',
    'items': [{
        'title': 'Moments of elliptic integrals and critical L-values',
        'authors': ['M. Rogers', 'J. G. Wan', 'I. J. Zucker'],
        'arxiv_version': '1303.2259v2, 16 April 2013',
        'url': url, 'local_file': name, 'sha256': hashlib.sha256(data).hexdigest(),
        'pages': pages,
        'reading_scope': 'Web primary PDF pages 1-3 and 13-14; local text of pages 13-14 actually emitted for review. This exact local snapshot has not been read in full.',
    }],
    'existing_primary_reading': [{
        'local_file': cy.name, 'sha256': cy_hash, 'pages': 79,
        'new_actual_pdf_pages': [8,9,22,23,24,27,28,30,36,37],
        'version_scope': 'BONN-TH-2022-07 author snapshot; do not equate its bytes with the later published 2024 revision.',
        'comparison_gap': 'Equation (2.56) is explicitly conjectural. The complete matrix (3.11) is numerical; geometric correspondence in section 4 proves occurrence and comparison up to multiplicative constant, not a complete calibrated integral period comparison.',
    }],
    'execution_record': 'First execution of this NEW archive utility; no old or peer mathematical producer run or imported.',
}
out = directory / 'manifest_cdt_odd_connection_primary_20261006.json'
if out.exists():
    raise RuntimeError('Do not replace an existing literature manifest.')
out.write_text(json.dumps(manifest, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
print(json.dumps({'file':name,'pages':pages,'sha256':manifest['items'][0]['sha256']}))
print(selected)
