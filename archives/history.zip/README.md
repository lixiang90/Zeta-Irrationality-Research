# zeta5：ζ(5) 无理性的 Lean 4 形式化

**当前研究入口：[CDT 奇数权：真实 level20 周期与分层 Smith 收益](research/cdt_odd_background_progress_20261006.md)。** 本轮将 L(3,χ₅) 的真实周期、完整整模型与共同解析叶接到素数依赖的 Hasse/Frobenius 微分关系；在固定原 CDT 格上证明一变量累计评价高度的正收益，得到限定 rank4/rank7 的更强算术秩界。解析容量与分母成本仍未达到最终矛盾，尚无新的奇数 ζ/L 数值无理性定理，未新增 Lean 形式化。

**此前研究入口：[CDT 奇数权：真实 ζ(7) 模型及剩余解析预算](research/cdt_odd_progress_20261005.md)。** 此前闭合 level12 权8 Eichler 的纯 ζ(7) Fricke 触发器、双向整数模坐标、明确有理微分系统和实际循环秩8；完整七层分母与全部连续纯对数背景的成本已证明。一个特定覆盖／背景组合被全尺度排除。偶角色奇权反演中的低权周期污染也已明确。仍没有新的奇数 ζ/L 数值无理性定理，持久目标继续；未新增 Lean 形式化。

四份新技术稿及精确证书保存于研究入口；[本轮文献地图](literature/cdt_odd_reading_map_20261005.md)另存7份原始PDF、177页。此前研究正文、证书与原始文献保持冻结。

**此前研究入口：[真实周期、完整整模型与算术 holonomy](research/period_holonomy_progress_20261005.md)。** 本轮扩大到五项有理点 Li₂ 组合、对数乘积、全部六分点 trigamma 与有理对数积分，以及一般周期系数 polylog。由 CDT 已知定理，闭合证明一族五项组合无理与四项独立，并完整分类全部 trigamma/积分组合；没有声称独立于 CDT 的新单个 L 值无理性定理。另证明实际秩 3 投影与完整整数来源之间的秩 6 商、精确坏边界及全内容，并以真实三级整模型校准 fine 分母成本。

四份技术稿、五份精确证书及[书面复核](research/period_holonomy_review_20261005.md)已保存。新增[两份原始 PDF、234 页与三份官方 HTML](literature/period_holonomy_reading_map_20261005.md)；固定 CDT 218 页 v2 与当前作者 220 页快照分开保存。先前报告、证书与 64 份原始 PDF 保持冻结，未新增 Lean 形式化。

**上一轮研究入口：[本原缺层与正测度统一接口](research/odd_zeta_primitive_routes_progress_20261005.md)。** 本轮补上旧七log族的第二p-adic借位展开和真实约分根分母预算，恢复部分非单位的七层成本，并证明每个充分大的三行块实际根分母具有指数高度。逐项反射机制仅有O(log n)素数权重；固定有理移位与端点type-I转置的指数障碍已明确。另为ζ奇数值、Catalan及3ζ(3)+ζ(5)建立实际正测度Padé接口，全尺度正余项与裸指数已核，完整整数预算仍未闭合。四份新技术稿与精确证书经独立复核，尚无新无理性证明，未新增Lean形式化。

[本轮文献地图](literature/primitive_routes_reading_map_20261005.md)新增5份原始PDF、97页及3份HTML，涉及有限域超几何、partial Lucas、Dwork、mixed Nikishin及标准渐近输入。Ghosh–Ward后续撤稿已记录，旧版仅供历史审计，未采用其定理；固定版本与SHA-256见[归档清单](literature/manifest_primitive_routes_20261005.json)。[上一轮对数矩进展](research/odd_zeta_log_moment_progress_20261005.md)及全部既有证明、证书与原始PDF保持冻结。

[上一轮对数矩文献地图](literature/log_moment_reading_map_20261005.md)保留6份原始PDF，涉及合流多重正交、Cauchy分量、Riemann–Hilbert强渐近及Nikishin条件，版本和SHA-256见[归档清单](literature/manifest_log_moment_20261005.json)。[此前显式端点进展](research/odd_zeta_explicit_relative_progress_20261004.md)及其[5份文献](literature/explicit_relative_reading_map_20261004.md)保持冻结，保留整系数T=0、四项链与具体Mellin族的本原排除区间。[K₂进展](research/odd_zeta_k2_gap_progress_20261004.md)及其[8份文献](literature/k2_gap_reading_map_20261004.md)、[更早路线进展](research/odd_zeta_next_routes_progress_20261004.md)亦保持冻结。

[总体研究判断](research/odd_zeta_global_strategy_20261004.md)保留统一动机背景，[此前桥梁](research/odd_zeta_bridge_progress_20261004.md)保持冻结。[literature阅读地图](literature/reading_map_20261004.md)记载28份新增原始PDF及2份复用文件；[桥梁文献](literature/bridge_reading_map_20261004.md)另存3份；[前一轮文献](literature/next_route_reading_map_20261004.md)另存7份，含BB恒等式与其证明、椭圆K₂原始文献。旧报告与原始PDF保持原样。

以下为此前具体ζ(7)构造的进展及已完成ζ(5)形式化基线。

后续奇数 ζ 值研究的当前入口是 [2026-10-04 研究总览](research/research_overview_20261004.md) 与 [ζ(7) 最新研究进展](research/zeta7_research_progress_20261004.md)。ζ(7) 与 3ζ(3)+ζ(5) 的无理性尚未证明。最新研究完成一个固定双矩余类的全部整数参数优化，建立覆盖所有高位单位的必要保护界，并用完整饱和整数Padé格改善分子的高度及本原值。三个尺度的尾部修正已改善同维原基线，但均劣于头块；统一端点上界的头块障碍已明确证明，负净指数仍未得到。所有一般论证与有限证书的范围均在报告中标明。下文保留ζ(5)形式化基线的说明。

对论文 *ZETA5 IS IRRATIONAL*（Aabir Fauzan, 2026-09-17, `ZETA5_IS_IRRATIONAL.pdf`）的
Lean 4 + mathlib 形式化。**主要结果已被机器完全验证**：本仓库依赖
[mo271/Zeta5](https://github.com/mo271/Zeta5)（Apache-2.0，Lean `v4.33.1` +
mathlib `v4.33.1` + PrimeNumberTheoremAnd），其 `Apery.irrational_five` 无 sorry
完成全部证明；本仓库的 `zeta5_irrational_absolute` 经桥接定理直接继承该结果：

```
#print axioms Zeta5Irrational.zeta5_irrational_absolute
-- [propext, Classical.choice, Quot.sound]   （无 sorryAx、无自定义公理）
```

## 构建

```bash
lake exe cache get   # 拉取 mathlib v4.33.1 缓存（首次，可能耗时较长）
lake build           # 全量 8941 jobs；Windows 若见 Apery.Table.* 大量
                     # "failed to read file *.olean" 属并发资源问题，
                     # 对 .lake/packages/Apery/Apery/Table/*.lean 逐个
                     # `lake build "+Apery.Table.<名>"` 串行补建后重跑即可
```

- lean-toolchain：`leanprover/lean4:v4.33.1`（与 Apery 依赖对齐）
- mathlib：pin 在 tag `v4.33.1`；另依赖 `Apery`（mo271/Zeta5，rev `00c55bd`）
- 本仓库的 `Zeta5Irrational/` 骨架在 v4.33.1 下全部编译通过（原 v4.34.0 开发，
  集成时已做版本回退适配）

## 项目结构

| 文件 | 内容 |
| --- | --- |
| `Zeta5Irrational/Params.lean` | 参数 K/N/h/α/λ/H（式 2.1）、D_m、H_j⁽⁵⁾、S_K（式 2.2/2.5）、A_M/Ū/ϱ 等常数 |
| `Zeta5Irrational/Functional.lean` | μ_X 泛函（定义性数据 + Classical.choice）、G_K/Δ_K/F_K（式 2.4/2.5）、m_{K,M}（式 5.1–5.2 显式素数乘积）、Q_{K,M} |
| `Zeta5Irrational/Propositions.lean` | §2–§7 与 Appendix C 各中间结果的陈述 |
| `Zeta5Irrational/Numerics.lean` | 数值事实（式 5.18/5.20/7.2、Table 3/4、Appendix C 常数），全部 `norm_num` 严格验证 |
| `Zeta5Irrational/Main.lean` | Theorem 2.1 陈述、Theorem 1.1（条件版，由本骨架 theorem_2_1 归约）、**Theorem 1.1 绝对版 `zeta5_irrational_absolute`（经由 Apery，无 sorry）**、Corollary 1.2 陈述 |

## 两条证明轨道

1. **绝对轨道（已完成）**：`Apery` 依赖完整形式化论文的 Theorem 2.1（带其文档化的
   偏差：截断 M=400、秩损失 r 代替 min(r,z)、直证部分分式代替 Tate 代数）与
   Theorem 1.1，`zeta5_irrational_absolute` 直接继承，公理干净。
2. **论文忠实镜像轨道（骨架，20 个 sorry）**：`Zeta5Irrational/` 按论文原编号与
   原始常数陈述全部中间结果，其中装配链（Theorem 2.1 组装、两条衰减估计、
   Corollary 1.2、Theorem 1.1 条件版）已真证，只需分析输入成立即自动闭合；
   其余 sorry 对应论文 §2.4–§7 与附录 C 的深层估计。由于 mo271 的形式化在
   规范化器与局部估值上与论文有文档化偏差，这些镜像陈述不能逐字从 Apery 导出，
   保留作为对照论文原文的独立验证目标。

`Zeta5-mo271/` 为 Apery 上游源码的参考克隆（未构建；实际依赖由 lake 拉取）。

## 形式化状态

### 已完整证明（无 sorry）

- **`theorem_2_1` ⇒ `zeta5_irrational`（Theorem 1.1）**：经典归约。设 ζ(5) = a/b，
  取 Theorem 2.1（M = 200）的多项式列，则 b^{37n}·Q_n(a/b) 为正整数（`pow_mul_eval_int`：
  Q ∈ ℤ[X]、deg = 37n、值为正），但 < exp(37n·log b − (139/5)n²)，n 充分大时 < 1，矛盾。
- **`theorem_2_1`**（Theorem 2.1，M ≥ 40）：由 prop_5_1（整性）、`delta_natDegree`（次数）
  与 prop_6_3（正性）组装，已证。
- **两条衰减估计 `theorem_2_1_decay_200` / `theorem_2_1_decay_100000`**：由 (7.1)
  （`eq_7_1`）与 Numerics 的余量引理推出；其中 log Q/K² 的有界性用
  "反证 + `Real.sInf_empty`"（无界则 limsup 为 sInf ∅ = 0，与 (7.1) 的负上界矛盾）得到。
- **`corollary_1_2`**：由 prop_C_2（对充分大的 b 与任意 a：
  0 < b^{37⌈c log b/40⌉}·Q_{⌈c log b/40⌉,100000}(a/b) < 1）与整性
  （`theorem_2_1` + `pow_mul_eval_int`：该量为整数）矛盾，已证。
  依赖 `theorem_2_1` 与衰减估计 `theorem_2_1_decay_200` 的**陈述**（二者本身 sorry）。
- 数值事实：式 (7.2) 两条余量（`margin_200`/`margin_100000`，精确分数与论文
  Appendix B.3 一致）、C.2 常数（`rho_c_sub`、`eps_sub_lambda_div_c`、`lambda_rho_sub_eps`）、
  K²logK 系数相消（`k2logk_cancellation`）、R 二次系数相消（`quadratic_cancellation`）、
  Table 3 十七分数和（`table3_sum`）、Table 4 仿射积分和（`table4_sum`）、
  **∫d(y)dy = 9/640（`integral_rankCorr`，区间积分真证，分段 + 微积分基本定理）**。
- **`delta_leading_coeff` / `delta_natDegree`**（§2.3，式 (2.9)：Δ_K 的首项系数非零且
  deg Δ_K = h）：完整证明。路线：部分分式 `PF_decomp`（由
  `Polynomial.div_prod_eq_quo_add_sum_rem_div`，代入 ±r² 得系数公式）⟹
  `Gentry_coeff_one`（`[X](Gentry n i j)` 的显式求和，r ≤ N 的项消失）⟹
  `deltaK_coeff_eq_det`（det_apply + `coeff_prod_fin`）⟹ `det_B_ne_zero`
  （B = Vᵀ ⬝ (D ⬝ (Vᵀ)ᵀ)，Vandermonde 节点 −r² 单射、对角权重非零）。
  次数上界 `deltaK_natDegree_le` 由 `Gentry_natDegree_le`（每项 ≤ 1）+ 归纳给出。
- **`kappa_lt`**（式 (C.6)：κ < 6933/500）：完整证明。π 用 `Real.pi_lt_d6`，
  √3/√114 用 `Real.lt_sqrt`/`Real.sqrt_lt'` 有理夹逼，log 经
  `Real.log_lt_iff_lt_exp` 转化为 `Real.exp_bound` 的 Taylor 下界
  （`exp_ge_taylor_sub`：S_n − R_n ≤ exp x），逐项有理上界之和 13.86590515 ≤ 13.866。
- `eq_3_1`：μ 对部分分式分解的相容性（由 `IsMuFunctional` 的线性性直接推出）。
- **`vpSK_formula`（式 (5.3)）**：v_p(S_K) 的 Legendre 展开（`norm_num`/`push_cast`/
  `padicValRat` 分配 + `padicValNat_factorial` 截断，约 65 行）。
- `hparam_sub_one_bridge`：边界审计桥梁引理，n ≥ 1 时整数 (h−1) 与 ℕ 减法一致。
- `mKM_pos`：m_{K,M} > 0。
- `harm5_zero`、`bernoulli_one_eq`（B₁ = −1/2 约定，与 mathlib `bernoulli` 一致）。

### 陈述 + sorry（对应论文章节）

| 定理 | 论文位置 |
| --- | --- |
| `prop_2_2`、`prop_2_2_posdef` | §2.4，式 (2.10) 正积分表示与正定性 |
| `eq_3_2_poly`、`eq_3_3_poly` | §3 式 (3.2)/(3.3) 的多项式重述（Bernoulli 恒等式，原陈述已证伪并删除，见 `eq_3_3_false`） |
| `lemma_3_1`、`lemma_3_2`、`lemma_3_3`、`eq_3_12` | §3，式 (3.4)/(3.7)/(3.10)/(3.12) |
| `prop_4_1`、`lemma_4_2`、`prop_4_3_outer`、`prop_4_3_large` | §4，式 (4.1)–(4.14) |
| `prop_5_1`、`prop_5_2` | §5，式 (5.11)/(5.21) |
| `lemma_6_1`、`lemma_6_2`、`prop_6_3` | §6，式 (6.2)–(6.16) |
| `eq_7_1` | §7，式 (7.1) |
| `prop_C_1`、`prop_C_2` | Appendix C，式 (C.1)/(C.7) |
| `eq_7_1` | §7，式 (7.1)：limsup 次可加性的有界性条件是 §5 量级内容，保留 sorry（doc 注明） |

（已证不再列出：`muFunctional_exists`、`delta_leading_coeff`/`delta_natDegree`（式 2.9）、
`vpSK_formula`（式 5.3）、`kappa_lt`（式 C.6）、定理 1.1 全链路、Corollary 1.2、两条衰减估计。）

### 论文勘误（已在陈述中修正）

- 论文式 (3.2)/(3.3)（τ 泛函的反射/差分恒等式）被骨架移植到了 μ（t-世界）后
  **不成立**：反例 `eq_3_3_false`（g = RatFunc.X：g(x+1) − g(x) = 1，
  μ(1) = C(5/12) ≠ 0 = C(g⁽⁴⁾(0)/24)）。原因是 (3.2)/(3.3) 属于 x-世界的 τ 泛函。
  已删除原陈述并重述为多项式版 `eq_3_2_poly`/`eq_3_3_poly`（Bernoulli 恒等式，sorry）。
- 论文式 (2.8) 原文为 M = 10000，但系数 7907/100 与 Appendix B.3 的实际余量不符
  （M = 10000 只给出衰减系数 ≈ 78.146 < 79.07；M = 100000 才达到 79.078，且
  Appendix C.2 实际使用 M = 100000）。本骨架将 `theorem_2_1_decay_10000` 修正为
  `theorem_2_1_decay_100000`（数值余量 `margin_100000` 已精确验证）。

### 骨架的已知简化（doc comment 中注明）

- μ/τ 泛函：以 `IsMuFunctional` 结构给出定义性数据，`muX` 经 `Classical.choice` 选取；
  τ 的 Tate 代数（p-adic 完备化）构造未展开，§3 引理以 μ 为载体或以 Gauss 赋值陈述。
- `m_{K,M}`：按式 (5.2) 的显式素数乘积定义，`L_p` 的三个分支按式 (5.1)，其中 γ_p^in
  按 (4.4)–(4.8) 实现（ε_a 取 a < E，论文允许任意并列次序）。
- Theorem 2.1 中 Q ∈ ℤ[X] 以"∃ P : ℤ[X], map P = Q_{K,M}"呈现。

### "(h−1) 家族"边界审计（结论：论文无 bug）

对论文中所有"显然的"减法/取整/求和限表达逐一核对其使用范围：

| 表达 | 使用范围 | 结论 |
| --- | --- | --- |
| (5.3) 末项 (h−1)·v_p(4) 与 S_K 的 4^{h−1}、∏_{i=1}^{h−1} | h = 37n，n ≥ 1（Theorem 2.1 实际 n ≥ 200000） | 自然/整数减法一致 ✓ |
| Vandermonde 列数 K − N = h | 恒等式 40n − 3n = 37n | 精确 ✓ |
| (4.4) 被除数 h − L₀ + 3(N − m_N) | K ≥ 200M² ⟹ n ≥ 5M²，≥ 185M² − 4M − 10 > 0 | ✓ |
| (4.4) 后 L_a 非负性 2λx − 81/20 ≥ 3/2（x = K/p ≥ 3） | x = 3 处恰取等 3/2，配合严格不等式 T − b_a > 2λx − 81/20 | ✓ |
| (4.4) 的 (2L₀+6m_N)/(p−1) < 1/20 | 最坏处 M = 40、p = 200M−1：≈ 0.0455 < 0.05 | ✓ |
| Prop 4.1 次数界 ≤ (23/5)M + 2 ≤ p + 1 | p > 200M | ✓ |
| (5.10) 积分上限 2λ = 37/20 与 Table 4 端点 | 2λ = 37/20 精确一致 | ✓ |
| C.3 的 (j−N−1)!、(K−j)! 范围 | j ∈ [N+1, K] ⟹ 指数 ∈ [0, h−1] | ✓ |
| C.2 取整 K = 40⌈c·log b/40⌉ | c·log b ≤ K < c·log b + 40 显然 | ✓ |

**结论：论文本身没有 bug。** 之前发现的 (5.3) 末项问题出在形式化翻译：
骨架早期版本把 (h−1) 写成 ℕ 截断减法 `(hparam n - 1 : ℕ)`，它对 n = 0、p = 2 成假
（此时 S_K = 1/4，左边 = −v₂(4) ≠ 0）。已修正为整数减法 `((hparam n : ℤ) - 1)`，
并以 `hparam_sub_one_bridge` 固定两种读法在论文使用范围（n ≥ 1）内等价。

## 注意

`ZETA5_IS_IRRATIONAL.pdf` 与 `pages/` 为论文原件，未改动。
